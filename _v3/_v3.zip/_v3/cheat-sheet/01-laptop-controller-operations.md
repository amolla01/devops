# Laptop Controller Operations

## Objective
Run all _v3 playbooks from laptop controller to R620/R810 targets.

## Preconditions
- Laptop has Ansible, sshpass, and SSH key configured.
- R620/R810 reachable from laptop or via jump host.
- `inventory/group_vars/all.yml` has correct jump-host settings (now profile-driven via `AUTOMATION_PROFILE` env var).
- Set `export AUTOMATION_PROFILE=ubuntu_r810_kvm` (or `ubuntu_r620_kvm`, `win11_kvm`, `real_hardware`).
- SSH transport hardening is automatic per profile (`sonic_use_conservative_ssh_transport`).

## Inventory Layout (Consolidated SSOT)
- `inventory/hosts.yml` — Single source of truth for all hosts and group memberships.
- `inventory/group_vars/all.yml` — Global vars (profiles, ASN maps, subnets, BGP settings).
- `inventory/group_vars/<group>.yml` — Per-group vars (23 files).
- `inventory/host_vars/<host>.yml` — Per-host vars (22 files with full wiring/platform data).
- `reused_baseline/` — Historical reference only (not used at runtime).

## Commands

Preflight laptop to R620 and R810 connectivity and key-auth:

`bash ../deploy_lab_v3.sh --proxy-jump-host jump.example --ssh-key ~/.ssh/id_r620 --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 preflight`

Run deploy_lab_v13.sh on remote hypervisor from laptop:

`bash ../deploy_lab_v3.sh --remote-v13-host admin@10.1.1.20 --remote-v13-path /home/admin/apm0015564-kepler-ssot-cicd/data-center/_v3/deploy_lab_v13.sh --profile ubuntu_r810_kvm kvm-deploy`

Run KVM deploy directly by hypervisor target:

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 kvm-deploy-r620`

`bash ../deploy_lab_v3.sh --r810-host admin@10.1.1.21 kvm-deploy-r810`

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 kvm-deploy-both`

Remote virsh controls from laptop:

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 remote-status`

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 remote-virsh r620 start Spine_S1`

`bash ../deploy_lab_v3.sh --r810-host admin@10.1.1.21 remote-virsh r810 destroy Host34_2`

Inventory check:

`ansible-inventory -i ../inventory/hosts.yml --graph`

Ping fabric switches:

`ansible -i ../inventory/hosts.yml sonic_switches -m ping`

Ping Ubuntu server groups:

`ansible -i ../inventory/hosts.yml servers -m ping`

Dry-run deploy plan:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_full_environment.yml --check`
