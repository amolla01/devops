# Deployment Operations

## Profile Selection
Set the automation profile before running (defaults to `ubuntu_r810_kvm` if unset):
```
export AUTOMATION_PROFILE=ubuntu_r810_kvm   # or ubuntu_r620_kvm, win11_kvm, real_hardware
```
Or pass `--profile <name>` to deploy_lab_v3.sh.

## Full Environment Deployment

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_full_environment.yml`

Orchestrated KVM setup + full services:

`bash ../deploy_lab_v3.sh --profile ubuntu_r810_kvm full`

Phase-by-phase expansion:

`bash ../deploy_lab_v3.sh phase-r620`

`bash ../deploy_lab_v3.sh phase-r810`

`bash ../deploy_lab_v3.sh phased-full`

## Deploy by Category

Fabric and underlay:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/reused/deploy_day0.yml`

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/reused/deploy_day1.yml`

KVM topology only (initial build):

`bash ../deploy_lab_v3.sh --profile ubuntu_r810_kvm kvm-deploy`

KVM topology only on remote hypervisors:

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 kvm-deploy-r620`

`bash ../deploy_lab_v3.sh --r810-host admin@10.1.1.21 kvm-deploy-r810`

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 kvm-deploy-both`

OpenStack Gateway tier:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_openstack_gateways.yml`

Premium Firewall tier:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_premium_firewall.yml`

Service catalog deployment validation:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_service_catalog.yml`
