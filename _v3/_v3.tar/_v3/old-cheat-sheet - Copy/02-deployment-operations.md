# Deployment Operations

## Full Environment Deployment

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_full_environment.yml`

Orchestrated KVM setup + full services:

`bash ../deploy_lab_v3.sh --profile ubuntu_r620_kvm full`

Phase-by-phase expansion:

`bash ../deploy_lab_v3.sh phase-r620`

`bash ../deploy_lab_v3.sh phase-r810`

`bash ../deploy_lab_v3.sh phased-full`

## Deploy by Category

Fabric and underlay:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/reused/deploy_day0.yml`

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/reused/deploy_day1.yml`

KVM topology only (initial build):

`bash ../deploy_lab_v3.sh --profile ubuntu_r620_kvm kvm-deploy`

KVM topology only on remote hypervisors:

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 kvm-deploy-r620`

`bash ../deploy_lab_v3.sh --r810-host admin@10.1.1.21 kvm-deploy-r810`

`bash ../deploy_lab_v3.sh --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 kvm-deploy-both`

OpenStack Gateway tier:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_openstack_gateways.yml`

Premium Firewall tier:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_premium_firewall.yml`

Service catalog deployment validation:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_service_catalog.yml`
