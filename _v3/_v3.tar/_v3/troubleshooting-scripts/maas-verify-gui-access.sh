#!/bin/bash
# maas-verify-gui-access.sh
# End-to-end verification of MaaS GUI accessibility from WSL2/Windows.
#
# Tests the full chain:
#   Windows browser → WSL2 SSH tunnel → K8s ClusterIP → Pod nginx:5240 → regiond socket
#
# Usage: Run from WSL2
#   ./maas-verify-gui-access.sh
#
VM_IP="${VM_IP:-172.16.2.45}"
VM_USER="${VM_USER:-ubuntu}"
VM_PASS="${VM_PASS:-ubuntu}"
LOCAL_PORT="${LOCAL_PORT:-30240}"
NAMESPACE="${NAMESPACE:-maas-system}"

echo "=== MaaS GUI Access Verification ==="
echo ""

PASS=0
FAIL=0

check() {
  local desc="$1"
  local result="$2"
  if [ "$result" = "OK" ]; then
    echo "  ✓ ${desc}"
    PASS=$((PASS + 1))
  else
    echo "  ✗ ${desc} -- ${result}"
    FAIL=$((FAIL + 1))
  fi
}

# 1. SSH connectivity
echo "[1] SSH to K8s node..."
SSH_TEST=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  -o ConnectTimeout=5 "${VM_USER}@${VM_IP}" "echo OK" 2>/dev/null)
check "SSH to ${VM_IP}" "${SSH_TEST:-FAILED}"

# 2. Region pod running
echo "[2] Region pod status..."
POD_STATUS=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl get pods -n ${NAMESPACE} -l app=maas-region -o jsonpath='{.items[0].status.phase}'" 2>/dev/null)
check "Region pod phase=Running" "$([ "$POD_STATUS" = "Running" ] && echo OK || echo "Got: ${POD_STATUS}")"

# 3. Regiond process
echo "[3] Regiond process..."
REGIOND=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl exec -n ${NAMESPACE} deploy/maas-region -- pgrep -c regiond 2>/dev/null" 2>/dev/null)
check "regiond process count > 0" "$([ "${REGIOND:-0}" -gt 0 ] && echo OK || echo "Got: ${REGIOND}")"

# 4. Unix socket active
echo "[4] Webapp Unix socket..."
SOCK=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl exec -n ${NAMESPACE} deploy/maas-region -- ss -xlnp 2>/dev/null | grep 'maas-regiond-webapp'" 2>/dev/null)
check "regiond-webapp socket listening" "$([ -n "$SOCK" ] && echo OK || echo "No socket found")"

# 5. Nginx running in pod
echo "[5] Nginx in pod..."
NGINX=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl exec -n ${NAMESPACE} deploy/maas-region -- pgrep -c nginx 2>/dev/null" 2>/dev/null)
check "nginx process count > 0" "$([ "${NGINX:-0}" -gt 0 ] && echo OK || echo "Got: ${NGINX} (run maas-fix-nginx-socket.sh)")"

# 6. Port 5240 inside pod
echo "[6] Port 5240 in pod..."
HTTP_POD=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl exec -n ${NAMESPACE} deploy/maas-region -- curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:5240/MAAS/ 2>/dev/null" 2>/dev/null)
check "HTTP from pod localhost:5240/MAAS/ = 301" "$([ "$HTTP_POD" = "301" ] && echo OK || echo "Got: ${HTTP_POD}")"

# 7. ClusterIP reachable from node
echo "[7] ClusterIP from node..."
CLUSTER_IP=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl get svc -n ${NAMESPACE} maas-region-ui -o jsonpath='{.spec.clusterIP}'" 2>/dev/null)
HTTP_CLUSTER=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://${CLUSTER_IP}:5240/MAAS/ 2>/dev/null" 2>/dev/null)
check "HTTP from node to ClusterIP ${CLUSTER_IP}:5240 = 301" "$([ "$HTTP_CLUSTER" = "301" ] && echo OK || echo "Got: ${HTTP_CLUSTER}")"

# 8. SSH tunnel active
echo "[8] SSH tunnel on port ${LOCAL_PORT}..."
TUNNEL_PID=$(lsof -ti :${LOCAL_PORT} 2>/dev/null)
check "SSH tunnel on port ${LOCAL_PORT}" "$([ -n "$TUNNEL_PID" ] && echo OK || echo "Not found (run maas-setup-ssh-tunnel.sh)")"

# 9. End-to-end from WSL
echo "[9] End-to-end HTTP from WSL..."
HTTP_LOCAL=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://localhost:${LOCAL_PORT}/MAAS/ 2>/dev/null)
check "HTTP from localhost:${LOCAL_PORT}/MAAS/ = 301" "$([ "$HTTP_LOCAL" = "301" ] && echo OK || echo "Got: ${HTTP_LOCAL}")"

# 10. Full page load
echo "[10] Full page load (follow redirects)..."
HTTP_FULL=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -L http://localhost:${LOCAL_PORT}/MAAS/ 2>/dev/null)
check "Full page HTTP 200 (with redirects)" "$([ "$HTTP_FULL" = "200" ] && echo OK || echo "Got: ${HTTP_FULL}")"

echo ""
echo "=== Results: ${PASS} passed, ${FAIL} failed ==="
[ $FAIL -eq 0 ] && echo "MaaS GUI is accessible at http://localhost:${LOCAL_PORT}/MAAS/" || echo "Some checks failed. Review output above."
