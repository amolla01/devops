#!/bin/bash
# check_hostb12_1.sh — Check HostB12_1 boot status
CONSOLE_PTY=$(virsh ttyconsole HostB12_1 2>/dev/null)
echo "Console PTY: $CONSOLE_PTY"

# Try to read console output
if [ -n "$CONSOLE_PTY" ]; then
    timeout 3 cat "$CONSOLE_PTY" > /tmp/cc.txt 2>/dev/null &
    PID=$!
    sleep 1
    echo "" > "$CONSOLE_PTY" 2>/dev/null
    sleep 3
    kill $PID 2>/dev/null || true
    echo "=== Console output ==="
    strings /tmp/cc.txt 2>/dev/null | tail -30
fi

echo ""
echo "=== Port 22 check ==="
nc -zv 172.16.2.45 22 2>&1 || echo "port 22 CLOSED"

echo ""
echo "=== VM state ==="
virsh domstate HostB12_1

echo ""
echo "=== ARP entry ==="
ip neigh show 172.16.2.45 2>/dev/null
