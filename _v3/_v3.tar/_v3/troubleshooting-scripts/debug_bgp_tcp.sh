#!/bin/bash
# Quick TCP 179 connectivity test and BGP debug
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"

echo "=== Test TCP 179 from BL1 → ER1 (10.0.253.1) ==="
sshpass -p amolla01 ssh $SSH_OPTS admin@172.16.2.31 \
  'timeout 3 bash -c "echo >/dev/tcp/10.0.253.1/179" 2>&1 && echo "PORT_OPEN" || echo "PORT_CLOSED"'

echo ""
echo "=== Check ER1 routing table ==="
sshpass -p '' ssh $SSH_OPTS admin@172.16.2.98 '/ip route print'

echo ""
echo "=== Check ER1 BGP connection state ==="
sshpass -p '' ssh $SSH_OPTS admin@172.16.2.98 '/routing bgp session print detail'

echo ""
echo "=== Check BL1 BGP neighbor detail (last few lines) ==="
sshpass -p amolla01 ssh $SSH_OPTS admin@172.16.2.31 \
  'docker exec bgp vtysh -c "show bgp neighbors 10.0.253.1"' 2>/dev/null | tail -30
