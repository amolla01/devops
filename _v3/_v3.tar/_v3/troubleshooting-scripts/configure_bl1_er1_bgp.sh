#!/bin/bash
# =============================================================================
# configure_bl1_er1_bgp.sh
# Configure numbered eBGP peering between Border_Leaf1 and Exit_Router1
#
# Link: Border_Leaf1 Ethernet0 (eth1) ↔ Exit_Router1 ether2 (br-BL1-ER1)
# P2P:  10.0.253.0/31 (BL1) ↔ 10.0.253.1/31 (ER1)
# BGP:  BL1 AS 65021 ↔ ER1 AS 65253
# =============================================================================
set -euo pipefail

BL1_IP="172.16.2.31"
BL1_PASS="amolla01"
ER1_IP="172.16.2.98"

SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"

echo "═══════════════════════════════════════════════════════════════════"
echo " Step 1: Configure Border_Leaf1 (SONiC) — Ethernet0 IP + BGP"
echo "═══════════════════════════════════════════════════════════════════"

# Add IP address to Ethernet0 on Border_Leaf1 via SONiC config
sshpass -p "$BL1_PASS" ssh $SSH_OPTS admin@$BL1_IP \
  "sudo config interface ip add Ethernet0 10.0.253.0/31" 2>/dev/null || true

echo "[BL1] IP 10.0.253.0/31 added to Ethernet0"

# Ensure Ethernet0 is admin-up
sshpass -p "$BL1_PASS" ssh $SSH_OPTS admin@$BL1_IP \
  "sudo config interface startup Ethernet0" 2>/dev/null || true

echo "[BL1] Ethernet0 set admin-up"

# Add numbered BGP neighbor for Exit_Router1 via vtysh
sshpass -p "$BL1_PASS" ssh $SSH_OPTS admin@$BL1_IP \
  "docker exec bgp vtysh \
    -c 'conf t' \
    -c 'router bgp 65021' \
    -c 'neighbor 10.0.253.1 remote-as 65253' \
    -c 'neighbor 10.0.253.1 description Exit_Router1' \
    -c 'address-family ipv4 unicast' \
    -c 'neighbor 10.0.253.1 activate' \
    -c 'exit-address-family' \
    -c 'end' \
    -c 'write'" 2>/dev/null

echo "[BL1] BGP neighbor 10.0.253.1 (AS 65253, Exit_Router1) configured"
echo ""

echo "═══════════════════════════════════════════════════════════════════"
echo " Step 2: Configure Exit_Router1 (MikroTik CHR) — ether2 IP + BGP"
echo "═══════════════════════════════════════════════════════════════════"

# Add IP address to ether2 (the fabric-facing interface in KVM CHR)
sshpass -p '' ssh $SSH_OPTS admin@$ER1_IP \
  '/ip address add address=10.0.253.1/31 interface=ether2' 2>/dev/null || true

echo "[ER1] IP 10.0.253.1/31 added to ether2"

# Set router-id for BGP
sshpass -p '' ssh $SSH_OPTS admin@$ER1_IP \
  '/routing id add name=main id=10.0.99.1 disabled=no select-dynamic-id=""' 2>/dev/null || true

echo "[ER1] Router-ID 10.0.99.1 set"

# Create BGP connection to Border_Leaf1
sshpass -p '' ssh $SSH_OPTS admin@$ER1_IP \
  '/routing bgp connection add name=to-Border_Leaf1 remote.address=10.0.253.0/32 remote.as=65021 local.role=ebgp local.address=10.0.253.1 routing-table=main as=65253 router-id=main address-families=ip disabled=no templates=""' 2>/dev/null || true

echo "[ER1] BGP connection to Border_Leaf1 (10.0.253.0, AS 65021) configured"

# Add network advertisement for loopback
sshpass -p '' ssh $SSH_OPTS admin@$ER1_IP \
  '/routing bgp network add network=10.0.99.1/32 synchronize=no' 2>/dev/null || true

echo "[ER1] Network 10.0.99.1/32 advertised"
echo ""

echo "═══════════════════════════════════════════════════════════════════"
echo " Step 3: Verify connectivity"
echo "═══════════════════════════════════════════════════════════════════"

sleep 3

echo "--- Border_Leaf1: ping Exit_Router1 link address ---"
sshpass -p "$BL1_PASS" ssh $SSH_OPTS admin@$BL1_IP \
  "ping -c 3 10.0.253.1 -W 2" 2>/dev/null || echo "[WARN] Ping failed (may need a moment)"

echo ""
echo "--- Border_Leaf1: BGP summary ---"
sshpass -p "$BL1_PASS" ssh $SSH_OPTS admin@$BL1_IP \
  "docker exec bgp vtysh -c 'show ip bgp summary'" 2>/dev/null

echo ""
echo "--- Exit_Router1: BGP sessions ---"
sshpass -p '' ssh $SSH_OPTS admin@$ER1_IP \
  '/routing bgp session print detail' 2>/dev/null

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo " Done. BGP should establish within ~30 seconds."
echo "═══════════════════════════════════════════════════════════════════"
