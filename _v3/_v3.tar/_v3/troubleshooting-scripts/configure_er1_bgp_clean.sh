#!/bin/bash
# configure_er1_bgp_clean.sh — Configure Exit_Router1 BGP from scratch
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
ER1="admin@172.16.2.98"

echo "=== Step 1: Remove all existing BGP connections ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/routing bgp connection remove [find]' 2>/dev/null || true

echo "=== Step 2: Create BGP connection with explicit config ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/routing bgp connection add name=bgp-bl1 remote.address=10.0.253.0/32 remote.as=65021 local.address=10.0.253.1 local.role=ebgp connect=yes listen=yes routing-table=main router-id=main templates="" as=65253 address-families=ip input.filter=bgp_in output.filter-chain=bgp_out hold-time=90s keepalive-time=30s disabled=no'

echo "=== Step 3: Verify connection ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/routing bgp connection print detail'

echo ""
echo "=== Step 4: Wait 15s for session to establish ==="
sleep 15

echo "=== Step 5: Check session ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/routing bgp session print detail'

echo ""
echo "=== Step 6: Check TCP connections on port 179 ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/ip firewall connection print where dst-port=179 or src-port=179'
