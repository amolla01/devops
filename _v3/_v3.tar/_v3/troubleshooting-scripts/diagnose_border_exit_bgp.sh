#!/bin/bash
# =============================================================================
# diagnose_border_exit_bgp.sh — Generalized Border-Leaf <-> Exit-Router BGP diag
# =============================================================================
# Runs the existing TCP/BGP/iptables/port-bridge checks for a numbered
# Border_Leaf <-> Exit_Router pair without hard-coding BL1/ER1 values.
#
# Usage:
#   bash diagnose_border_exit_bgp.sh --profile bl1-er1
#   bash diagnose_border_exit_bgp.sh --profile bl2-er2
#
#   bash diagnose_border_exit_bgp.sh \
#     --bl-name Border_Leaf1 --bl-mgmt 172.16.2.31 \
#     --er-name Exit_Router1 --er-mgmt 172.16.2.98 \
#     --bl-port Ethernet0 --bl-ip 10.0.253.0 --er-ip 10.0.253.1
#
# Env overrides:
#   SONIC_PASS=amolla01
#   ROUTER_PASS=''
#   CAPTURE_SECONDS=5
# =============================================================================

set -u -o pipefail

SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
SONIC_PASS="${SONIC_PASS:-amolla01}"
ROUTER_PASS="${ROUTER_PASS:-}"
CAPTURE_SECONDS="${CAPTURE_SECONDS:-5}"

BL_NAME=""
BL_MGMT=""
ER_NAME=""
ER_MGMT=""
BL_PORT=""
BL_IP=""
ER_IP=""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
    cat <<'EOF'
Usage:
  bash diagnose_border_exit_bgp.sh --profile bl1-er1
  bash diagnose_border_exit_bgp.sh --profile bl2-er2

  bash diagnose_border_exit_bgp.sh \
    --bl-name Border_Leaf1 --bl-mgmt 172.16.2.31 \
    --er-name Exit_Router1 --er-mgmt 172.16.2.98 \
    --bl-port Ethernet0 --bl-ip 10.0.253.0 --er-ip 10.0.253.1

Options:
  --profile <bl1-er1|bl2-er2>
  --bl-name <name>
  --bl-mgmt <ip>
  --er-name <name>
  --er-mgmt <ip>
  --bl-port <sonic-port>
  --bl-ip <numbered-sonic-ip>
  --er-ip <numbered-routeros-ip>
  --capture-seconds <n>
  -h, --help

Env overrides:
  SONIC_PASS, ROUTER_PASS, CAPTURE_SECONDS
EOF
}

set_profile() {
    case "$1" in
        bl1-er1)
            BL_NAME="Border_Leaf1"
            BL_MGMT="172.16.2.31"
            ER_NAME="Exit_Router1"
            ER_MGMT="172.16.2.98"
            BL_PORT="Ethernet0"
            BL_IP="10.0.253.0"
            ER_IP="10.0.253.1"
            ;;
        bl2-er2)
            BL_NAME="Border_Leaf2"
            BL_MGMT="172.16.2.32"
            ER_NAME="Exit_Router2"
            ER_MGMT="172.16.2.99"
            BL_PORT="Ethernet0"
            BL_IP="10.0.253.2"
            ER_IP="10.0.253.3"
            ;;
        *)
            echo "Unknown profile: $1" >&2
            usage
            exit 1
            ;;
    esac
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile)
            [ "$#" -lt 2 ] && { usage; exit 1; }
            set_profile "$2"
            shift 2
            ;;
        --bl-name)
            BL_NAME="$2"
            shift 2
            ;;
        --bl-mgmt)
            BL_MGMT="$2"
            shift 2
            ;;
        --er-name)
            ER_NAME="$2"
            shift 2
            ;;
        --er-mgmt)
            ER_MGMT="$2"
            shift 2
            ;;
        --bl-port)
            BL_PORT="$2"
            shift 2
            ;;
        --bl-ip)
            BL_IP="$2"
            shift 2
            ;;
        --er-ip)
            ER_IP="$2"
            shift 2
            ;;
        --capture-seconds)
            CAPTURE_SECONDS="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            usage
            exit 1
            ;;
    esac
done

for required_var in BL_NAME BL_MGMT ER_NAME ER_MGMT BL_PORT BL_IP ER_IP; do
    if [ -z "${!required_var}" ]; then
        echo "Missing required value: $required_var" >&2
        usage
        exit 1
    fi
done

bl_ssh() {
    sshpass -p "$SONIC_PASS" ssh $SSH_OPTS "admin@${BL_MGMT}" "$@"
}

er_ssh() {
    sshpass -p "$ROUTER_PASS" ssh $SSH_OPTS "admin@${ER_MGMT}" "$@"
}

section() {
    echo ""
    echo "=== $1 ==="
}

echo "===================================================================="
echo " Border-Leaf <-> Exit-Router BGP Diagnosis"
echo " Border Leaf: ${BL_NAME} (${BL_MGMT})"
echo " Exit Router: ${ER_NAME} (${ER_MGMT})"
echo " Fabric Link: ${BL_PORT} | ${BL_IP} <-> ${ER_IP}"
echo " Capture:     ${CAPTURE_SECONDS}s"
echo "===================================================================="

section "TCP 179 from ${BL_NAME} -> ${ER_NAME} (${ER_IP}:179)"
echo "Note: a refusal here is informational if RouterOS is configured with listen=no."
bl_ssh "timeout 3 bash -c 'echo >/dev/tcp/${ER_IP}/179' 2>&1 && echo OPEN || echo CLOSED" 2>&1 || true

section "TCP probe from ${ER_NAME} -> ${BL_NAME} (${BL_IP}:179)"
er_ssh "/tool fetch url=\"http://${BL_IP}:179\" mode=http keep-result=no duration=3s" 2>&1 || true

section "Loopback TCP probe on ${ER_NAME} (informational)"
er_ssh '/tool fetch url="http://127.0.0.1:179" mode=http keep-result=no duration=3s' 2>&1 || true

section "${BL_NAME} BGP neighbor detail for ${ER_IP}"
bl_ssh "docker exec bgp vtysh -c 'show bgp neighbors ${ER_IP}'" 2>/dev/null | grep -E 'state|Connect|Last|Opens|host|FD used|Waiting for peer OPEN' || true

section "${ER_NAME} BGP template/connection/session detail"
er_ssh '/routing bgp template print detail; /routing bgp connection print detail; /routing bgp session print detail' 2>&1 || true

section "${BL_NAME} listening sockets on TCP/179"
bl_ssh 'sudo ss -tlnp | grep 179' 2>/dev/null || true

section "${BL_NAME} active connections involving 10.0.253.x"
bl_ssh 'sudo ss -tnp state all | grep "10.0.253"' 2>/dev/null || true

section "${BL_NAME} interface state for ${BL_PORT}"
bl_ssh "ip addr show ${BL_PORT}" 2>/dev/null || true
echo ""
bl_ssh "ip route show ${BL_IP}/31" 2>/dev/null || true
echo ""
echo "rp_filter(${BL_PORT}):"
bl_ssh "cat /proc/sys/net/ipv4/conf/${BL_PORT}/rp_filter" 2>/dev/null || true
echo "rp_filter(all):"
bl_ssh 'cat /proc/sys/net/ipv4/conf/all/rp_filter' 2>/dev/null || true

section "${BL_NAME} iptables port-179 view"
bl_ssh 'sudo iptables -L INPUT -n --line-numbers' 2>/dev/null || true
echo ""
bl_ssh 'sudo iptables -L -n | grep -i "179\|bgp"' 2>/dev/null || true

section "${BL_NAME} tcpdump on ${BL_PORT} for ${CAPTURE_SECONDS}s"
bl_ssh "sudo timeout ${CAPTURE_SECONDS} tcpdump -i ${BL_PORT} port 179 -nn -vv 2>&1" || true

section "${ER_NAME} route for ${BL_IP}/31"
er_ssh "/ip route print where dst-address=${BL_IP}/31" 2>&1 || true

if [ -x "${SCRIPT_DIR}/diagnose_port_bridge.sh" ]; then
    section "${BL_NAME} port-to-bridge trace for ${BL_PORT}"
    "${SCRIPT_DIR}/diagnose_port_bridge.sh" "${BL_NAME}" "${BL_PORT}" "${BL_MGMT}" || true
fi

echo ""
echo "Diagnosis complete."