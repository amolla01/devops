#!/bin/bash
# debug_bl1_tcpdump.sh — Full packet capture on Ethernet0 for BGP
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"

echo "=== BL1: Full tcpdump on Ethernet0 (port 179), 10 seconds ==="
echo "    Capturing ALL packets (SYN + SYN-ACK + RST + everything)"
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo timeout 10 tcpdump -i Ethernet0 port 179 -nn -vv 2>&1' || true

echo ""
echo "=== BL1: Also check any tcp RST on Ethernet0 ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo timeout 5 tcpdump -i Ethernet0 "tcp[tcpflags] & (tcp-rst) != 0" -nn 2>&1 | head -10' || true

echo ""
echo "=== BL1: netstat -s for tcp (listen drops, etc.) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'cat /proc/net/snmp | grep Tcp' 2>/dev/null
