#!/bin/bash
# test_tcp_direction.sh — Test exactly what's happening with TCP 179
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"
ER1="admin@172.16.2.98"

echo "=== Test: BL1 listening sockets (before) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo ss -tlnp | grep 179' 2>/dev/null

echo ""
echo "=== Test: BL1 all connections involving 10.0.253.x ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo ss -tnp state all | grep "10.0.253"' 2>/dev/null

echo ""
echo "=== Test: tcpdump on BL1 Ethernet0 for 5 seconds ==="
# Capture any BGP traffic on Ethernet0
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo timeout 5 tcpdump -i Ethernet0 port 179 -n -c 10 2>&1' || true

echo ""
echo "=== Test: ER1 routing table for 10.0.253.0 ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/ip route print where dst-address=10.0.253.0/31'
