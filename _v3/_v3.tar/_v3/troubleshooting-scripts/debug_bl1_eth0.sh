#!/bin/bash
# debug_bl1_eth0.sh — Check why BL1 isn't responding to SYN on Ethernet0
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"

echo "=== BL1: IP address on Ethernet0 ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'ip addr show Ethernet0' 2>/dev/null

echo ""
echo "=== BL1: ip route for 10.0.253.0/31 ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'ip route show 10.0.253.0/31' 2>/dev/null

echo ""
echo "=== BL1: rp_filter setting ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'cat /proc/sys/net/ipv4/conf/Ethernet0/rp_filter' 2>/dev/null
echo ""
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'cat /proc/sys/net/ipv4/conf/all/rp_filter' 2>/dev/null

echo ""
echo "=== BL1: iptables rules (INPUT chain) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -L INPUT -n --line-numbers' 2>/dev/null

echo ""
echo "=== BL1: iptables rules (all chains, port 179) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -L -n | grep -i "179\|bgp"' 2>/dev/null
echo "(end)"
