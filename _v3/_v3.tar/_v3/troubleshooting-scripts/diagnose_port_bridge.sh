#!/bin/bash
# =============================================================================
# diagnose_port_bridge.sh — Full port → ethN → NIC → OVS bridge diagnosis
# =============================================================================
# Run from KVM HOST. Traces the full path from a SONiC port through the
# kernel interface, VM NIC, TAP device, and OVS bridge to the remote peer.
#
# This script diagnoses the #1 cause of BGP Idle on SONiC VS:
# Port-to-ethN mapping mismatch due to sequential (not index-based) assignment.
#
# Usage:
#   bash diagnose_port_bridge.sh <vm_name> <sonic_port> <mgmt_ip>
#
# Examples:
#   bash diagnose_port_bridge.sh Border_Leaf1 Ethernet124 172.16.2.31
#   bash diagnose_port_bridge.sh Leaf_L1 Ethernet0 172.16.2.21
# =============================================================================

set -euo pipefail

# ---- Args ----
VM_NAME="${1:-}"
SONIC_PORT="${2:-}"
MGMT_IP="${3:-}"

if [ -z "$VM_NAME" ] || [ -z "$SONIC_PORT" ] || [ -z "$MGMT_IP" ]; then
    echo "Usage: $0 <vm_name> <sonic_port> <mgmt_ip>"
    echo ""
    echo "Examples:"
    echo "  $0 Border_Leaf1 Ethernet124 172.16.2.31"
    echo "  $0 Leaf_L1 Ethernet0 172.16.2.21"
    exit 1
fi

PASS="${SONIC_PASS:-amolla01}"
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5"

ssh_cmd() {
    sshpass -p "$PASS" ssh $SSH_OPTS "admin@${MGMT_IP}" "$@" 2>/dev/null
}

echo "═══════════════════════════════════════════════════════════════════════"
echo " Port-to-Bridge Diagnosis"
echo " VM: $VM_NAME | Port: $SONIC_PORT | IP: $MGMT_IP"
echo " Date: $(date -Iseconds)"
echo "═══════════════════════════════════════════════════════════════════════"
echo ""

# ---- Step 1: Get actual ethN mapping from syslog ----
echo "┌─── Step 1: Actual ethN Mapping (from syslog) ──────────────────────"
HOSTIF_LINE=$(ssh_cmd "sudo grep 'hostif_create_tap_veth_forwarding' /var/log/syslog | grep '$SONIC_PORT'" | tail -1)
if [ -n "$HOSTIF_LINE" ]; then
    ACTUAL_ETH=$(echo "$HOSTIF_LINE" | grep -oP 'eth\d+')
    ACTUAL_IDX=$(echo "$HOSTIF_LINE" | grep -oP 'interface index = \K\d+')
    echo "│ $SONIC_PORT → $ACTUAL_ETH (interface index = $ACTUAL_IDX)"
else
    echo "│ ⚠️  No hostif_create_tap_veth_forwarding entry found for $SONIC_PORT"
    echo "│    Port may not be configured or syslog rotated."
    ACTUAL_ETH=""
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

# ---- Step 2: Kernel interface state ----
echo "┌─── Step 2: Kernel Interface State ─────────────────────────────────"
if [ -n "$ACTUAL_ETH" ]; then
    ETH_STATE=$(ssh_cmd "ip -br link show $ACTUAL_ETH" 2>/dev/null)
    QDISC=$(ssh_cmd "tc qdisc show dev $ACTUAL_ETH" 2>/dev/null | head -1)
    echo "│ $ETH_STATE"
    echo "│ Qdisc: $QDISC"
    if echo "$QDISC" | grep -q "noop"; then
        echo "│ ⚠️  qdisc=noop means syncd NEVER initialized this interface!"
        echo "│    This port is NOT mapped to this ethN. Check mapping above."
    elif echo "$ETH_STATE" | grep -q "DOWN"; then
        echo "│ ⚠️  Interface DOWN but qdisc set — no carrier from OVS bridge"
    fi
else
    echo "│ Skipped (no ethN determined in Step 1)"
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

# ---- Step 3: SONiC port oper status ----
echo "┌─── Step 3: SONiC Port Oper Status ─────────────────────────────────"
OPER=$(ssh_cmd "sonic-db-cli APPL_DB hget 'PORT_TABLE:$SONIC_PORT' oper_status" 2>/dev/null)
ADMIN=$(ssh_cmd "sonic-db-cli CONFIG_DB hget 'PORT|$SONIC_PORT' admin_status" 2>/dev/null)
echo "│ admin_status: ${ADMIN:-unknown}"
echo "│ oper_status:  ${OPER:-unknown}"
if [ "$OPER" = "down" ]; then
    echo "│ ⚠️  Port is operationally DOWN — check ethN state and bridge wiring"
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

# ---- Step 4: VM NIC → OVS bridge mapping (from KVM host) ----
echo "┌─── Step 4: VM NIC → OVS Bridge (from KVM host) ───────────────────"
# Try to get domiflist
DOMIFLIST=$(sudo virsh domiflist "$VM_NAME" 2>/dev/null || echo "")
if [ -z "$DOMIFLIST" ]; then
    echo "│ ⚠️  Could not get domiflist for VM '$VM_NAME'"
    echo "│    Try: sudo virsh list --all | grep -i leaf"
else
    echo "│ NIC  TAP Device   Bridge"
    echo "│ ─────────────────────────────────────────────"
    echo "$DOMIFLIST" | tail -n +3 | nl -v0 | while read -r nic_num iface type source model mac; do
        echo "│ NIC$nic_num  $iface  $source"
    done
    # Find which NIC corresponds to our ethN
    if [ -n "$ACTUAL_ETH" ]; then
        ETH_NUM=${ACTUAL_ETH#eth}
        echo "│"
        echo "│ $SONIC_PORT → $ACTUAL_ETH → NIC$ETH_NUM"
        # Get the bridge for this NIC
        BRIDGE=$(echo "$DOMIFLIST" | tail -n +3 | sed -n "$((ETH_NUM+1))p" | awk '{print $3}')
        if [ -n "$BRIDGE" ]; then
            echo "│ NIC$ETH_NUM is connected to bridge: $BRIDGE"
        fi
    fi
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

# ---- Step 5: OVS bridge members ----
echo "┌─── Step 5: OVS Bridge Members ────────────────────────────────────"
if [ -n "${BRIDGE:-}" ]; then
    PORTS=$(sudo ovs-vsctl list-ports "$BRIDGE" 2>/dev/null | tr '\n' ' ')
    echo "│ Bridge: $BRIDGE"
    echo "│ Ports:  $PORTS"
    # Check each port state
    for port in $PORTS; do
        STATE=$(ip -br link show "$port" 2>/dev/null | awk '{print $2}')
        echo "│   $port: $STATE"
    done
else
    echo "│ No bridge determined from previous steps"
    echo "│ Listing all OVS bridges:"
    sudo ovs-vsctl list-br 2>/dev/null | while read -r br; do
        ports=$(sudo ovs-vsctl list-ports "$br" 2>/dev/null | tr '\n' ' ')
        echo "│   $br: $ports"
    done
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

# ---- Step 6: port_config.ini index info ----
echo "┌─── Step 6: port_config.ini Index ──────────────────────────────────"
PC_LINE=$(ssh_cmd "cat /usr/share/sonic/device/x86_64-kvm_x86_64-r0/*/port_config.ini 2>/dev/null | grep '^$SONIC_PORT '")
if [ -n "$PC_LINE" ]; then
    echo "│ $PC_LINE"
    PC_INDEX=$(echo "$PC_LINE" | awk '{print $(NF-1)}')
    FIRST_INDEX=$(ssh_cmd "tail -n +2 /usr/share/sonic/device/x86_64-kvm_x86_64-r0/*/port_config.ini 2>/dev/null | awk '{print \$NF}' | sort -n | head -1")
    EXPECTED_ETH="eth$((PC_INDEX - FIRST_INDEX + 1))"
    echo "│ Index in port_config.ini: $PC_INDEX"
    echo "│ First index in this hwsku: $FIRST_INDEX"
    echo "│ Expected ethN (formula): $EXPECTED_ETH"
    if [ -n "$ACTUAL_ETH" ] && [ "$ACTUAL_ETH" != "$EXPECTED_ETH" ]; then
        echo "│ ⚠️  MISMATCH: syslog says $ACTUAL_ETH, formula says $EXPECTED_ETH"
    elif [ -n "$ACTUAL_ETH" ]; then
        echo "│ ✓ Confirmed: syslog and formula agree → $ACTUAL_ETH"
    fi
else
    echo "│ ⚠️  Port '$SONIC_PORT' not found in port_config.ini"
fi
echo "└────────────────────────────────────────────────────────────────────"
echo ""

echo "═══════════════════════════════════════════════════════════════════════"
echo " Diagnosis Complete"
echo "═══════════════════════════════════════════════════════════════════════"
