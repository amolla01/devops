#!/bin/bash
# Quick BGP check on Border_Leaf1
sshpass -p amolla01 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null admin@172.16.2.31 \
  "docker exec bgp vtysh -c 'show bgp summary'"
