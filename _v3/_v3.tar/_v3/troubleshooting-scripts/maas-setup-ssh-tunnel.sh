#!/bin/bash
# maas-setup-ssh-tunnel.sh
# Create SSH tunnel from WSL2 to access MaaS GUI from Windows browser.
#
# Problem: IPVS-based kube-proxy only binds NodePort on specific IPs (node IP),
#   NOT on 127.0.0.1. An SSH tunnel to localhost:30240 fails.
#
# Solution: Forward directly to the ClusterIP:port (bypasses NodePort/IPVS).
#   Or use the node's actual IP in the -L target.
#
# Usage: Run from WSL2
#   ./maas-setup-ssh-tunnel.sh          # Uses defaults
#   VM_IP=172.16.2.45 ./maas-setup-ssh-tunnel.sh
#
# After running: Open http://localhost:30240/MAAS/ in Windows browser
#
VM_IP="${VM_IP:-172.16.2.45}"
VM_USER="${VM_USER:-ubuntu}"
VM_PASS="${VM_PASS:-ubuntu}"
LOCAL_PORT="${LOCAL_PORT:-30240}"
NAMESPACE="${NAMESPACE:-maas-system}"
SERVICE_NAME="${SERVICE_NAME:-maas-region-ui}"

echo "=== MaaS SSH Tunnel Setup ==="

# Kill any existing tunnel on the same port
EXISTING=$(lsof -ti :${LOCAL_PORT} 2>/dev/null)
if [ -n "$EXISTING" ]; then
  echo "Killing existing process on port ${LOCAL_PORT} (PID: ${EXISTING})"
  kill $EXISTING 2>/dev/null
  sleep 1
fi

# Get ClusterIP of the MaaS service
echo "Fetching ClusterIP for ${SERVICE_NAME}..."
CLUSTER_IP=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl get svc -n ${NAMESPACE} ${SERVICE_NAME} -o jsonpath='{.spec.clusterIP}'" 2>/dev/null)

SERVICE_PORT=$(sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "kubectl get svc -n ${NAMESPACE} ${SERVICE_NAME} -o jsonpath='{.spec.ports[0].port}'" 2>/dev/null)

if [ -z "$CLUSTER_IP" ] || [ "$CLUSTER_IP" = "None" ]; then
  echo "WARNING: Could not get ClusterIP. Falling back to node IP + NodePort."
  FORWARD_TARGET="${VM_IP}:${LOCAL_PORT}"
else
  echo "ClusterIP: ${CLUSTER_IP}:${SERVICE_PORT}"
  FORWARD_TARGET="${CLUSTER_IP}:${SERVICE_PORT}"
fi

# Create the SSH tunnel
echo "Creating tunnel: localhost:${LOCAL_PORT} -> ${FORWARD_TARGET} (via ${VM_IP})"
sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  -f -N -L "0.0.0.0:${LOCAL_PORT}:${FORWARD_TARGET}" "${VM_USER}@${VM_IP}"

RC=$?
if [ $RC -eq 0 ]; then
  NEW_PID=$(lsof -ti :${LOCAL_PORT} 2>/dev/null)
  echo ""
  echo "SUCCESS: Tunnel established (PID: ${NEW_PID})"
  echo "  Local:  http://localhost:${LOCAL_PORT}/MAAS/"
  echo "  Target: ${FORWARD_TARGET}"
  echo ""
  echo "To kill: kill ${NEW_PID}"
else
  echo "ERROR: SSH tunnel failed (exit code: ${RC})"
  exit 1
fi
