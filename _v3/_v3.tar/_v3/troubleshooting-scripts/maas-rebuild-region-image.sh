#!/bin/bash
# maas-rebuild-region-image.sh
# Rebuild MaaS region Docker image with all shims for running in K8s (no systemd).
#
# Problem: MaaS 3.4 regiond expects systemd services (bind9, maas-http, etc.).
#   Running in a K8s container requires shim scripts for:
#   - sudo (strip flags, exec remaining args)
#   - systemctl (fake active/running responses)
#   - systemd-detect-virt (return "container")
#   - nsupdate, rndc, named, chronyc (no-op)
#
# This script:
#   1. Creates a container from ubuntu:22.04
#   2. Installs maas-region-api + nginx
#   3. Adds entrypoint with all shims
#   4. Commits as maas-region:3.4
#   5. Imports into containerd k8s.io namespace
#
# Usage: Run via SSH on the K8s node (172.16.2.45)
#   SSH to VM, then: sudo bash maas-rebuild-region-image.sh
#
# Prerequisites: Docker must be running on the VM, proxy configured
#
set -e

IMAGE_NAME="maas-region:3.4"
CONTAINER_NAME="maas-build-region"
PROXY="http://172.16.2.1:3128"
MAAS_PPA="ppa:maas/3.4-next"

echo "=== MaaS Region Image Build ==="
echo "Image: ${IMAGE_NAME}"
echo ""

# Clean up any previous build container
docker rm -f ${CONTAINER_NAME} 2>/dev/null || true

# Step 1: Create build container
echo "--- Step 1: Creating container from ubuntu:22.04 ---"
docker run -d --name ${CONTAINER_NAME} \
  -e http_proxy=${PROXY} \
  -e https_proxy=${PROXY} \
  -e no_proxy=localhost,127.0.0.1,10.233.0.0/16,172.16.2.0/24 \
  ubuntu:22.04 sleep infinity

# Step 2: Install packages
echo "--- Step 2: Installing MaaS region packages ---"
docker exec ${CONTAINER_NAME} bash -c "
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y software-properties-common gpg curl netcat-openbsd postgresql-client nginx
add-apt-repository -y ${MAAS_PPA}
apt-get update
apt-get install -y maas-region-api
apt-get clean
rm -rf /var/lib/apt/lists/*
"

# Step 3: Create entrypoint script
echo "--- Step 3: Creating entrypoint ---"
cat > /tmp/maas-entrypoint.sh << 'ENTRYPOINT'
#!/bin/bash
set -e

# --- Shim: sudo (strip flags, exec args) ---
cat > /usr/bin/sudo << 'SHIM'
#!/bin/bash
while [ $# -gt 0 ]; do
  case "$1" in
    -u|--user|-g|--group|-C|-H|-P|-S|-E|-n) shift; [ "${1:0:1}" != "-" ] && shift ;;
    -*) shift ;;
    *) break ;;
  esac
done
exec "$@"
SHIM
chmod +x /usr/bin/sudo

# --- Shim: systemctl ---
cat > /usr/bin/systemctl << 'SHIM'
#!/bin/bash
case "$1" in
  show)
    shift
    while [ $# -gt 0 ]; do
      case "$1" in
        --property|--property=*) shift ;;
        -*) shift ;;
        *) break ;;
      esac
    done
    echo "ActiveState=active"
    echo "SubState=running"
    echo "LoadState=loaded"
    exit 0
    ;;
  start|stop|restart|reload|enable|disable) exit 0 ;;
  is-active) echo active; exit 0 ;;
  *) exit 0 ;;
esac
SHIM
chmod +x /usr/bin/systemctl

# --- Shim: systemd-detect-virt ---
cat > /usr/bin/systemd-detect-virt << 'SHIM'
#!/bin/bash
echo "container"
exit 0
SHIM
chmod +x /usr/bin/systemd-detect-virt

# --- Shim: no-op for DNS/NTP services ---
for cmd in nsupdate rndc named chronyc; do
  cat > /usr/bin/$cmd << 'SHIM'
#!/bin/bash
exit 0
SHIM
  chmod +x /usr/bin/$cmd
done

# --- Wait for PostgreSQL ---
echo "Waiting for PostgreSQL..."
until pg_isready -h ${MAAS_DB_HOST:-maas-postgresql.maas-system.svc.dc-lab-cluster} -p ${MAAS_DB_PORT:-5432} -U ${MAAS_DB_USER:-maas} 2>/dev/null; do
  sleep 2
done
echo "PostgreSQL is ready."

# --- Write regiond.conf ---
mkdir -p /etc/maas
cat > /etc/maas/regiond.conf << EOF
database_host: ${MAAS_DB_HOST:-maas-postgresql.maas-system.svc.dc-lab-cluster}
database_port: ${MAAS_DB_PORT:-5432}
database_name: ${MAAS_DB_NAME:-maasdb}
database_user: ${MAAS_DB_USER:-maas}
database_pass: ${MAAS_DB_PASS:-maas-pg-secret-2024}
maas_url: http://0.0.0.0:5240/MAAS
EOF

# --- Shared secret ---
mkdir -p /var/lib/maas
echo -n "${MAAS_SHARED_SECRET:-dc-lab-maas-shared-secret-2024x}" > /var/lib/maas/secret

# --- Run migrations ---
echo "Running database migrations..."
maas-region dbupgrade || echo "WARNING: dbupgrade had errors (may be OK on repeat runs)"

# --- Create admin (ignore if exists) ---
maas-region createadmin \
  --username "${MAAS_ADMIN_USER:-admin}" \
  --password "${MAAS_ADMIN_PASS:-maas-admin-2024}" \
  --email "${MAAS_ADMIN_EMAIL:-admin@dc-lab.local}" 2>/dev/null || true

# --- Create http directory and prep nginx ---
mkdir -p /var/lib/maas/http /var/log/nginx /run

# --- Start regiond ---
echo "Starting regiond..."
exec /usr/sbin/regiond --debug
ENTRYPOINT
chmod +x /tmp/maas-entrypoint.sh

docker cp /tmp/maas-entrypoint.sh ${CONTAINER_NAME}:/entrypoint.sh
docker exec ${CONTAINER_NAME} chmod +x /entrypoint.sh

# Step 4: Commit image
echo "--- Step 4: Committing image ---"
docker stop ${CONTAINER_NAME}
docker commit --change='ENTRYPOINT ["/entrypoint.sh"]' ${CONTAINER_NAME} ${IMAGE_NAME}
docker rm ${CONTAINER_NAME}

echo "Docker image built: ${IMAGE_NAME}"

# Step 5: Import to containerd
echo "--- Step 5: Importing to containerd ---"
docker save ${IMAGE_NAME} | ctr -n k8s.io images import -
echo ""
echo "=== Build Complete ==="
echo "Image available in containerd: docker.io/library/${IMAGE_NAME}"
echo ""
echo "To deploy:"
echo "  kubectl set image -n maas-system deployment/maas-region maas-region=docker.io/library/${IMAGE_NAME}"
echo "  kubectl rollout restart -n maas-system deployment/maas-region"
