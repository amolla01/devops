#!/bin/bash
# Remove stale Ethernet108 BGP neighbor from Border_Leaf1
sshpass -p amolla01 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null admin@172.16.2.31 \
  "docker exec bgp vtysh -c 'conf t' -c 'router bgp 65021' -c 'no neighbor Ethernet108' -c 'end' -c 'write memory'"
