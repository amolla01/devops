#!/bin/bash
# verify_checksum_fix.sh — Check if vnet147 tx off fixed checksums
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"

echo "=== Hypervisor: Check vnet147 TX offload setting ==="
sudo ethtool -k vnet147 2>/dev/null | grep "tx-checksumming"

echo ""
echo "=== BL1: tcpdump on Ethernet0 (5 seconds, verbose) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo timeout 5 tcpdump -i Ethernet0 port 179 -nn -v 2>&1' || true

echo ""
echo "=== BL1: TCP InCsumErrors counter ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'cat /proc/net/snmp | grep Tcp' 2>/dev/null | awk '{print "InCsumErrors: " $NF}'
