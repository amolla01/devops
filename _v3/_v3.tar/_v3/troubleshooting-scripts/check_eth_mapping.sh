#!/bin/bash
# =============================================================================
# check_eth_mapping.sh — Show actual SONiC VS hostif ethN → port mapping
# =============================================================================
# Run INSIDE a SONiC VM to see the definitive ethN mapping from syslog.
# This is the ONLY authoritative source for which ethN a SONiC port uses.
#
# Usage: bash check_eth_mapping.sh [port_name]
#   No args  → show all ports
#   With arg → filter for specific port (e.g., "Ethernet108")
# =============================================================================

set -euo pipefail

FILTER="${1:-}"

echo "═══════════════════════════════════════════════════════════════════════"
echo " SONiC VS — hostif ethN Mapping (from syslog)"
echo " Host: $(hostname)"
echo " Date: $(date -Iseconds)"
echo "═══════════════════════════════════════════════════════════════════════"
echo ""

# Check syslog for hostif_create_tap_veth_forwarding messages
SYSLOG="/var/log/syslog"
if [ ! -f "$SYSLOG" ]; then
    echo "ERROR: $SYSLOG not found. Try /var/log/messages or journalctl."
    exit 1
fi

if [ -n "$FILTER" ]; then
    echo "Filtering for: $FILTER"
    echo ""
    sudo grep "hostif_create_tap_veth_forwarding" "$SYSLOG" | grep "$FILTER" | tail -5
else
    echo "Port Name       → ethN (from syslog hostif_create_tap_veth_forwarding)"
    echo "───────────────────────────────────────────────────────────────────────"
    sudo grep "hostif_create_tap_veth_forwarding" "$SYSLOG" | \
        grep -oP 'name: \K\S+|interface index = \d+, eth\d+' | \
        paste - - | \
        sort -t'h' -k2 -n | \
        awk '{printf "%-16s → %s\n", $1, $2}'
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════════"
echo " ethN Interface States (kernel)"
echo "═══════════════════════════════════════════════════════════════════════"
echo ""
echo "Interface    State     Qdisc          MAC"
echo "───────────────────────────────────────────────────────────────────────"
ip -br link show | grep "^eth" | while read -r iface state mac; do
    qdisc=$(tc qdisc show dev "$iface" 2>/dev/null | head -1 | awk '{print $2}')
    printf "%-12s %-9s %-14s %s\n" "$iface" "$state" "${qdisc:-unknown}" "$mac"
done

echo ""
echo "═══════════════════════════════════════════════════════════════════════"
echo " Platform Info"
echo "═══════════════════════════════════════════════════════════════════════"
echo ""
echo "HWSKU: $(sonic-db-cli CONFIG_DB hget 'DEVICE_METADATA|localhost' hwsku 2>/dev/null || echo 'unknown')"
echo "Platform: $(sonic-db-cli CONFIG_DB hget 'DEVICE_METADATA|localhost' platform 2>/dev/null || echo 'unknown')"

# Show port_config.ini location and index range
PC=$(find /usr/share/sonic/device/x86_64-kvm_x86_64-r0/ -name "port_config.ini" 2>/dev/null | head -1)
if [ -n "$PC" ]; then
    FIRST_IDX=$(tail -n +2 "$PC" | awk '{print $NF}' | sort -n | head -1)
    LAST_IDX=$(tail -n +2 "$PC" | awk '{print $NF}' | sort -n | tail -1)
    NUM_PORTS=$(tail -n +2 "$PC" | wc -l)
    echo "port_config.ini: $PC"
    echo "Index range: $FIRST_IDX – $LAST_IDX ($NUM_PORTS ports)"
    echo "Formula: ethN = index - ($FIRST_IDX - 1)"
fi
