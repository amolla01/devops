#!/bin/bash
# test_tcp179.sh — Test TCP 179 from BL1 and check why MikroTik isn't connecting
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"
ER1="admin@172.16.2.98"

echo "=== Test 1: TCP 179 from BL1 → ER1 (10.0.253.1:179) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'timeout 3 bash -c "echo >/dev/tcp/10.0.253.1/179" 2>&1 && echo "OPEN" || echo "CLOSED"'

echo ""
echo "=== Test 2: TCP 179 from ER1 → BL1 (10.0.253.0:179) ==="
sshpass -p '' ssh $SSH_OPTS $ER1 '/tool fetch url="http://10.0.253.0:179" mode=http keep-result=no duration=3s' 2>&1 || true

echo ""
echo "=== Test 3: Check what's listening on ER1 ==="
# MikroTik doesn't have netstat, use tool/fetch to see if 179 works locally
sshpass -p '' ssh $SSH_OPTS $ER1 '/tool fetch url="http://127.0.0.1:179" mode=http keep-result=no duration=3s' 2>&1 || true

echo ""
echo "=== Test 4: BL1 — FRR BGP neighbor detail for 10.0.253.1 ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'docker exec bgp vtysh -c "show bgp neighbors 10.0.253.1"' 2>/dev/null | grep -E "state|Connect|Last|Opens|host"

echo ""
echo "=== Test 5: BL1 — ss for port 179 connections ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo ss -tnp | grep 179' 2>/dev/null
