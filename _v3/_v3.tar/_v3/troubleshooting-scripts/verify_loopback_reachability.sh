#!/bin/bash
# =============================================================================
# verify_loopback_reachability.sh — Test loopback-to-loopback ping across fabric
# =============================================================================
# Run from KVM HOST. For each SONiC switch, pings all other loopback addresses
# using the local Loopback0 as the source. This verifies end-to-end BGP routing.
#
# Usage: bash verify_loopback_reachability.sh
# =============================================================================

set -euo pipefail

PASS="${SONIC_PASS:-amolla01}"
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5"

# Define fabric hosts: name IP loopback_ip
declare -A HOSTS=(
    ["Spine_S1"]="172.16.2.11"
    ["Spine_S2"]="172.16.2.12"
    ["Leaf_L1"]="172.16.2.21"
    ["Leaf_L2"]="172.16.2.22"
    ["Leaf_L3"]="172.16.2.23"
    ["Border_Leaf1"]="172.16.2.31"
    ["Border_Leaf2"]="172.16.2.32"
)

declare -A LOOPBACKS=(
    ["Spine_S1"]="10.0.0.1"
    ["Spine_S2"]="10.0.0.2"
    ["Leaf_L1"]="10.0.1.1"
    ["Leaf_L2"]="10.0.1.2"
    ["Leaf_L3"]="10.0.1.3"
    ["Border_Leaf1"]="10.0.2.1"
    ["Border_Leaf2"]="10.0.2.2"
)

ssh_cmd() {
    local ip="$1"
    shift
    sshpass -p "$PASS" ssh $SSH_OPTS "admin@${ip}" "$@" 2>/dev/null
}

echo "╔═══════════════════════════════════════════════════════════════════════╗"
echo "║  SONiC Fabric — Loopback Reachability Test                          ║"
echo "║  Date: $(date -Iseconds)                              ║"
echo "╚═══════════════════════════════════════════════════════════════════════╝"
echo ""

# Check sshpass is available
if ! command -v sshpass &>/dev/null; then
    echo "ERROR: sshpass not installed. Run: sudo apt install sshpass"
    exit 1
fi

PASS_COUNT=0
FAIL_COUNT=0
SKIP_COUNT=0

for src_name in Spine_S1 Spine_S2 Leaf_L1 Leaf_L2 Leaf_L3 Border_Leaf1 Border_Leaf2; do
    src_ip="${HOSTS[$src_name]:-}"
    src_lo="${LOOPBACKS[$src_name]:-}"

    if [ -z "$src_ip" ] || [ -z "$src_lo" ]; then
        continue
    fi

    # Check if reachable
    if ! ping -c1 -W2 "$src_ip" &>/dev/null; then
        echo "⚠️  $src_name ($src_ip) — UNREACHABLE, skipping"
        ((SKIP_COUNT++))
        continue
    fi

    echo "═══════════════════════════════════════════════════════════════════════"
    echo " From: $src_name (lo: $src_lo)"
    echo "───────────────────────────────────────────────────────────────────────"

    for dst_name in Spine_S1 Spine_S2 Leaf_L1 Leaf_L2 Leaf_L3 Border_Leaf1 Border_Leaf2; do
        # Skip self
        if [ "$src_name" = "$dst_name" ]; then
            continue
        fi

        dst_lo="${LOOPBACKS[$dst_name]:-}"
        if [ -z "$dst_lo" ]; then
            continue
        fi

        # Ping from source loopback to destination loopback
        RESULT=$(ssh_cmd "$src_ip" "ping -c2 -W2 -I Loopback0 $dst_lo" 2>/dev/null | tail -2)
        if echo "$RESULT" | grep -q "0% packet loss\|0.0% packet loss"; then
            RTT=$(echo "$RESULT" | grep "rtt\|round-trip" | grep -oP '[\d.]+/[\d.]+/[\d.]+' | head -1)
            printf "  ✓ → %-14s (%s) — OK (rtt: %s ms)\n" "$dst_name" "$dst_lo" "${RTT:-?}"
            ((PASS_COUNT++))
        else
            printf "  ✗ → %-14s (%s) — FAILED\n" "$dst_name" "$dst_lo"
            ((FAIL_COUNT++))
        fi
    done
    echo ""
done

echo "═══════════════════════════════════════════════════════════════════════"
echo " Results: ✓ $PASS_COUNT passed | ✗ $FAIL_COUNT failed | ⚠️  $SKIP_COUNT skipped"
echo "═══════════════════════════════════════════════════════════════════════"

if [ "$FAIL_COUNT" -gt 0 ]; then
    echo ""
    echo "💡 Troubleshooting tips for failed pings:"
    echo "   1. Check BGP state: docker exec bgp vtysh -c 'show bgp summary'"
    echo "   2. Check route to dest: docker exec bgp vtysh -c 'show ip route <dest_lo>'"
    echo "   3. Verify port-to-ethN mapping: bash check_eth_mapping.sh"
    echo "   4. Run full diagnosis: bash diagnose_port_bridge.sh <vm> <port> <ip>"
    exit 1
fi
