#!/bin/bash
# debug_bl1_bgp_ns.sh — Check BGP namespace and Docker networking on BL1
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"

echo "=== BL1: Docker bgp container network mode ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'docker inspect bgp --format="{{.HostConfig.NetworkMode}}"' 2>/dev/null

echo ""
echo "=== BL1: Check if bgpd PID is in host namespace ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo ls -la /proc/9423/ns/net 2>/dev/null' 2>/dev/null
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo ls -la /proc/1/ns/net 2>/dev/null' 2>/dev/null

echo ""
echo "=== BL1: iptables -L INPUT -v (with counters) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -L INPUT -nv' 2>/dev/null

echo ""
echo "=== BL1: Check DOCKER-related chains ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -t nat -L -n 2>/dev/null | head -30' 2>/dev/null

echo ""
echo "=== BL1: FRR neighbor config ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'docker exec bgp vtysh -c "show run" 2>/dev/null | grep -A2 "neighbor 10"'
