#!/bin/bash
# =============================================================================
# check_bgp_fabric.sh — Check BGP state across all SONiC fabric switches
# =============================================================================
# Run from KVM HOST. SSHs into each SONiC VM and checks:
#   - BGP summary (peer state, AS, prefixes)
#   - FRR running config (router bgp section)
#   - Interface oper status for uplink ports
#
# Usage: bash check_bgp_fabric.sh
# =============================================================================

set -euo pipefail

# ---- Configuration ----
PASS="${SONIC_PASS:-amolla01}"
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5"

# Define fabric hosts: name=IP
declare -A HOSTS=(
    ["Spine_S1"]="172.16.2.11"
    ["Spine_S2"]="172.16.2.12"
    ["Leaf_L1"]="172.16.2.21"
    ["Leaf_L2"]="172.16.2.22"
    ["Leaf_L3"]="172.16.2.23"
    ["Border_Leaf1"]="172.16.2.31"
    ["Border_Leaf2"]="172.16.2.32"
)

# ---- Functions ----
ssh_cmd() {
    local ip="$1"
    shift
    sshpass -p "$PASS" ssh $SSH_OPTS "admin@${ip}" "$@" 2>/dev/null
}

check_host() {
    local name="$1"
    local ip="$2"

    echo "═══════════════════════════════════════════════════════════════════════"
    echo " $name ($ip)"
    echo "═══════════════════════════════════════════════════════════════════════"

    # Check if reachable
    if ! ping -c1 -W2 "$ip" &>/dev/null; then
        echo "  ⚠️  UNREACHABLE (ping failed)"
        echo ""
        return
    fi

    # BGP Summary
    echo ""
    echo "  ┌─── BGP Summary ───────────────────────────────────────────────────"
    local bgp_out
    bgp_out=$(ssh_cmd "$ip" "docker exec bgp vtysh -c 'show bgp summary'" 2>/dev/null) || true
    if [ -n "$bgp_out" ]; then
        echo "$bgp_out" | grep -E "router identifier|local AS|Neighbor|Ethernet|Total" | sed 's/^/  │ /'
    else
        echo "  │ ⚠️  Could not retrieve BGP summary (bgp container not running?)"
    fi
    echo "  └────────────────────────────────────────────────────────────────────"

    # Peer states summary
    echo ""
    echo "  ┌─── Peer States ───────────────────────────────────────────────────"
    if [ -n "$bgp_out" ]; then
        local established idle connect active
        established=$(echo "$bgp_out" | grep -c "Ethernet" | grep -v "Idle\|Connect\|Active\|OpenSent" || echo 0)
        idle=$(echo "$bgp_out" | grep -c "Idle" || echo 0)
        echo "  │ Established: $(echo "$bgp_out" | grep "Ethernet" | grep -cv "Idle\|Connect\|Active\|OpenSent\|OpenConfirm" || echo 0)"
        echo "  │ Idle:        $idle"
        echo "  │ Other:       $(echo "$bgp_out" | grep "Ethernet" | grep -c "Connect\|Active\|OpenSent\|OpenConfirm" || echo 0)"
    fi
    echo "  └────────────────────────────────────────────────────────────────────"

    # Uplink port oper status
    echo ""
    echo "  ┌─── Uplink Port Status ────────────────────────────────────────────"
    ssh_cmd "$ip" "show interfaces status" 2>/dev/null | grep -E "Interface|up|down" | head -10 | sed 's/^/  │ /'
    echo "  └────────────────────────────────────────────────────────────────────"
    echo ""
}

# ---- Main ----
echo ""
echo "╔═══════════════════════════════════════════════════════════════════════╗"
echo "║  SONiC Fabric — BGP Health Check                                    ║"
echo "║  Date: $(date -Iseconds)                              ║"
echo "╚═══════════════════════════════════════════════════════════════════════╝"
echo ""

# Check sshpass is available
if ! command -v sshpass &>/dev/null; then
    echo "ERROR: sshpass not installed. Run: sudo apt install sshpass"
    exit 1
fi

for name in Spine_S1 Spine_S2 Leaf_L1 Leaf_L2 Leaf_L3 Border_Leaf1 Border_Leaf2; do
    ip="${HOSTS[$name]:-}"
    if [ -n "$ip" ]; then
        check_host "$name" "$ip"
    fi
done

echo "═══════════════════════════════════════════════════════════════════════"
echo " Summary Complete"
echo "═══════════════════════════════════════════════════════════════════════"
