#!/bin/bash
# maas-check-region-status.sh
# Check MaaS region controller pod status, nginx, and socket connectivity
# Usage: Run from WSL or any Linux host that can SSH to the K8s node
#
# Variables (adjust to your environment):
VM_IP="${VM_IP:-172.16.2.45}"
VM_USER="${VM_USER:-ubuntu}"
VM_PASS="${VM_PASS:-ubuntu}"
NAMESPACE="${NAMESPACE:-maas-system}"

echo "=== MaaS Region Controller Status Check ==="
echo "Target: ${VM_USER}@${VM_IP}, Namespace: ${NAMESPACE}"
echo ""

sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" "echo ${VM_PASS} | sudo -S bash -c '
echo \"--- Pod Status ---\"
kubectl get pods -n ${NAMESPACE} -o wide
echo \"\"

echo \"--- Services ---\"
kubectl get svc -n ${NAMESPACE}
echo \"\"

echo \"--- Endpoints ---\"
kubectl get endpoints -n ${NAMESPACE}
echo \"\"

echo \"--- Region Pod Processes ---\"
kubectl exec -n ${NAMESPACE} deploy/maas-region -- ps aux 2>/dev/null | head -20
echo \"\"

echo \"--- Listening Sockets in Pod ---\"
kubectl exec -n ${NAMESPACE} deploy/maas-region -- ss -tlnp 2>/dev/null
echo \"\"

echo \"--- Unix Sockets (maas) ---\"
kubectl exec -n ${NAMESPACE} deploy/maas-region -- ss -xlnp 2>/dev/null | grep maas
echo \"\"

echo \"--- Nginx Status ---\"
kubectl exec -n ${NAMESPACE} deploy/maas-region -- bash -c \"
  if pgrep nginx >/dev/null 2>&1; then
    echo NGINX: RUNNING
    nginx -t -c /var/lib/maas/http/nginx.conf 2>&1
  else
    echo NGINX: NOT RUNNING
  fi
\" 2>/dev/null
echo \"\"

echo \"--- Quick HTTP Test (inside pod) ---\"
kubectl exec -n ${NAMESPACE} deploy/maas-region -- \
  curl -s -o /dev/null -w \"HTTP %{http_code} from localhost:5240/MAAS/\" http://127.0.0.1:5240/MAAS/ 2>/dev/null
echo \"\"

echo \"--- NodePort IPVS Rules ---\"
ipvsadm -Ln 2>/dev/null | grep -A2 30240
echo \"\"

echo \"--- NodePort Test (via node IP) ---\"
curl -s -o /dev/null -w \"HTTP %{http_code} from ${VM_IP}:30240/MAAS/\" http://${VM_IP}:30240/MAAS/ 2>/dev/null
echo \"\"
'" 2>/dev/null
