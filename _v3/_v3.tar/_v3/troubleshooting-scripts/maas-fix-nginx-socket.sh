#!/bin/bash
# maas-fix-nginx-socket.sh
# Fix MaaS region nginx configuration when socket is stale or nginx is not running.
#
# Problem: MaaS 3.4 regiond serves on Unix sockets, nginx reverse-proxies on port 5240.
#   - regiond creates socket: /var/lib/maas/maas-regiond-webapp.sock.<N>
#   - After pod restart, old sockets (sock.0-3) become stale on PVC
#   - The ACTIVE socket has a trailing dot: maas-regiond-webapp.sock.
#   - nginx config must point to the active socket
#
# Usage: Run from WSL or Linux host with SSH access to K8s node
#
VM_IP="${VM_IP:-172.16.2.45}"
VM_USER="${VM_USER:-ubuntu}"
VM_PASS="${VM_PASS:-ubuntu}"
NAMESPACE="${NAMESPACE:-maas-system}"

echo "=== MaaS Region Nginx Socket Fix ==="
echo "Target: ${VM_USER}@${VM_IP}, Namespace: ${NAMESPACE}"
echo ""

sshpass -p "$VM_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  "${VM_USER}@${VM_IP}" << ENDSSH
echo ${VM_PASS} | sudo -S kubectl exec -i -n ${NAMESPACE} deploy/maas-region -- bash -c '
echo "--- Finding active socket ---"
ACTIVE_SOCK=\$(ss -xlnp | grep "maas-regiond-webapp" | grep -oP "/var/lib/maas/maas-regiond-webapp\.sock\.[^ ]*")
echo "Active socket: \${ACTIVE_SOCK}"

if [ -z "\${ACTIVE_SOCK}" ]; then
  echo "ERROR: No active regiond webapp socket found. Is regiond running?"
  exit 1
fi

echo ""
echo "--- Removing stale sockets ---"
for s in /var/lib/maas/maas-regiond-webapp.sock.*; do
  if [ "\$s" != "\${ACTIVE_SOCK}" ]; then
    echo "Removing stale: \$s"
    rm -f "\$s"
  fi
done

echo ""
echo "--- Writing regiond.nginx.conf ---"
cat > /var/lib/maas/http/regiond.nginx.conf << "REGIOND"
upstream regiond-webapp {
    server unix:/var/lib/maas/maas-regiond-webapp.sock.;
}

proxy_http_version 1.1;
proxy_buffering off;
proxy_read_timeout 900s;
proxy_set_header Host \$host;
proxy_set_header X-Real-IP \$remote_addr;
proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto \$scheme;
proxy_set_header X-Forwarded-Host \$http_host;

server {
    listen [::]:5240;
    listen 5240;
    absolute_redirect off;

    location = / { return 301 /MAAS/r/; }
    location ~ ^/MAAS/?\$ { return 301 /MAAS/r/; }
    location /MAAS { proxy_pass http://regiond-webapp; }
    location /MAAS/ws {
        proxy_pass http://regiond-webapp;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Upgrade \$http_upgrade;
    }
    location ~ ^/MAAS/r/(.*)\$ {
        root /usr/share/maas/web/static;
        try_files /\$1 /index.html =404;
    }
    location ~ ^/MAAS/assets/(.*)\$ {
        root /usr/share/maas/web/static/assets;
        try_files /\$1 =404;
    }
    location /favicon.ico {
        root /usr/share/maas/web/static;
        try_files /maas-favicon-32px.png =404;
    }
}
REGIOND

echo "--- Writing nginx.conf wrapper ---"
cat > /var/lib/maas/http/nginx.conf << "WRAPPER"
worker_processes auto;
pid /run/maas-http.pid;
error_log /dev/stderr;

events { worker_connections 768; }

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    access_log /dev/stdout;
    include /var/lib/maas/http/regiond.nginx.conf;
}
WRAPPER

echo ""
echo "--- Stopping existing nginx (if any) ---"
killall nginx 2>/dev/null
sleep 1

echo "--- Testing nginx config ---"
nginx -t -c /var/lib/maas/http/nginx.conf 2>&1
TEST_RC=\$?
if [ \$TEST_RC -ne 0 ]; then
  echo "ERROR: nginx config test failed!"
  exit 1
fi

echo "--- Starting nginx ---"
nginx -c /var/lib/maas/http/nginx.conf 2>&1
START_RC=\$?
if [ \$START_RC -ne 0 ]; then
  echo "ERROR: nginx start failed!"
  exit 1
fi

sleep 1
echo ""
echo "--- Verification ---"
ss -tlnp | grep 5240
echo ""
curl -s -o /dev/null -w "HTTP test: %{http_code}\n" http://127.0.0.1:5240/MAAS/
echo "DONE: nginx started successfully on port 5240"
'
ENDSSH
