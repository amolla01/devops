#!/bin/bash
# debug_bl1_output.sh — Check OUTPUT chain and verify SYN-ACK path
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10"
BL1="admin@172.16.2.31"

echo "=== BL1: iptables OUTPUT chain ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -L OUTPUT -nv' 2>/dev/null

echo ""
echo "=== BL1: iptables FORWARD chain ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables -L FORWARD -nv' 2>/dev/null

echo ""
echo "=== BL1: All iptables chains (filter table) ==="
sshpass -p amolla01 ssh $SSH_OPTS $BL1 'sudo iptables-save' 2>/dev/null | grep -v "^#"
