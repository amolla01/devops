# Troubleshooting Scripts — SONiC VS KVM Lab

Reusable diagnostic scripts for the SONiC Virtual Switch KVM lab.

## Scripts

| Script | Purpose | Run From |
|--------|---------|----------|
| `diagnose_border_exit_bgp.sh` | Generalized Border_Leaf <-> Exit_Router TCP/BGP diagnostic workflow | KVM host (SSH) |
| `check_eth_mapping.sh` | Show actual hostif ethN → SONiC port mapping via syslog | Inside SONiC VM |
| `check_bgp_fabric.sh` | Check BGP state across all fabric switches | KVM host (SSH) |
| `diagnose_port_bridge.sh` | Full port → ethN → NIC → OVS bridge diagnosis | KVM host (SSH) |
| `verify_loopback_reachability.sh` | Test loopback-to-loopback ping for all BGP peers | KVM host (SSH) |

## Usage

```bash
# From KVM host (scripts that SSH into VMs):
chmod +x *.sh
./check_bgp_fabric.sh
./diagnose_border_exit_bgp.sh --profile bl1-er1
./diagnose_border_exit_bgp.sh --profile bl2-er2

# From inside a SONiC VM:
scp admin@<kvm-host>:troubleshooting-scripts/check_eth_mapping.sh .
bash check_eth_mapping.sh
```

## Prerequisites

- `sshpass` installed on KVM host (`apt install sshpass`)
- SSH access to SONiC VMs (default: admin / amolla01)
- OVS tools on KVM host (`ovs-vsctl`, `ovs-ofctl`)

## Key Findings These Scripts Help Diagnose

1. **ethN sequential mapping** — SONiC VS maps ports to ethN sequentially, NOT by port_config.ini index
2. **syncd doesn't bring ethN UP** — relies on ethN already having carrier from OVS bridge
3. **qdisc noop** — means syncd never initialized the interface (port not mapped to that ethN)
4. **hostif_create_tap_veth_forwarding** syslog messages — definitive proof of actual mapping
