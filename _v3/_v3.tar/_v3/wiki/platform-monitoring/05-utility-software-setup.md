# 05 — Utility Software Setup

## Overview

Installation and configuration of utility software on the control node and cluster nodes. Covers CLI tools (kubectl, helm, k9s, jq, yq), Python venv for Ansible, SSH configuration, and developer productivity tooling.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/sheba-infra-utility-software-setup.html` |
| Category | Platform Monitoring |
| Profiles | KVM + Real Hardware |
| Execution Order | **#05** — Prerequisite for all platform operations |

---

## Control Node Tools

| Tool | Version | Purpose |
|------|---------|---------|
| `ansible` | 2.15+ | Configuration management |
| `kubectl` | 1.28 | Kubernetes CLI |
| `helm` | 3.14+ | Kubernetes package manager |
| `k9s` | 0.32+ | Terminal UI for K8s |
| `jq` | 1.7+ | JSON processor |
| `yq` | 4.40+ | YAML processor |
| `ceph` (client) | 18.2 | Ceph CLI for storage management |
| `virsh` | 10.0+ | KVM VM management |
| `terraform` | 1.7+ | Infrastructure as Code (optional) |

---

## Installation Commands

### Python Virtual Environment (Ansible)

```bash
python3 -m venv /mnt/c/Users/nh1221/data-center/_v3/.venv
source /mnt/c/Users/nh1221/data-center/_v3/.venv/bin/activate
pip install ansible==2.15.* netaddr jmespath
pip install ansible-lint yamllint
```

### Kubernetes Tools

```bash
curl -LO "https://dl.k8s.io/release/v1.28.0/bin/linux/amd64/kubectl"
chmod +x kubectl && sudo mv kubectl /usr/local/bin/
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
curl -sS https://webinstall.dev/k9s | bash
```

### JSON/YAML Tools

```bash
sudo apt-get install -y jq
sudo wget -qO /usr/local/bin/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64
sudo chmod +x /usr/local/bin/yq
```

### SSH Configuration

```
Host lab-ctrl-*
  User ubuntu
  IdentityFile ~/.ssh/lab_rsa
  StrictHostKeyChecking no

Host lab-ctrl-1
  HostName 172.16.2.11
```

---

## Execution Note

### KVM Profile
All tools installed on the WSL environment of the R810 hypervisor. The control node runs from `/mnt/c/Users/nh1221/data-center/_v3/`.

### Real Hardware Profile
Same tools installed on a dedicated management server or bastion host. Ensure network connectivity to all fabric switches and server BMCs.
