# 01 — Deploy Monitoring Stack

## Overview

Deploys Prometheus, Grafana, Alertmanager, and Node Exporter via kube-prometheus-stack Helm chart. Provides cluster-wide observability for Kubernetes, Ceph, SONiC, and application workloads.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_monitoring.yml` |
| Category | Platform Monitoring |
| Profiles | KVM + Real Hardware |
| Execution Order | **#1 in monitoring** — After Kubernetes + Ceph are running |
| Prerequisites | K8s cluster; Ceph StorageClass for Prometheus PVCs; MetalLB for Grafana LB IP |
| Idempotent | Yes (Helm upgrade) |

---

## Execution Note

### KVM Profile
Deploy full monitoring stack. Grafana exposed on NodePort 31300 or MetalLB IP. Pre-loads dashboards for Ceph, K8s, SONiC.

```bash
ansible-playbook playbooks/reused/deploy_monitoring.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same stack with larger retention (30d) and persistent storage. Alert rules configured for production SLOs.

```bash
ansible-playbook playbooks/reused/deploy_monitoring.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `prometheus` | K8s | Deploy Prometheus + ServiceMonitors |
| `grafana` | K8s | Deploy Grafana + dashboard provisioning |
| `alertmanager` | K8s | Deploy Alertmanager + alert routes |
| `exporters` | All nodes | Node Exporter, ceph-exporter |
| `dashboards` | K8s | Import custom Grafana dashboards |
| `verify` | K8s | Validate targets are scraped |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `monitoring_namespace` | `monitoring` | Kubernetes namespace |
| `prometheus_retention` | `15d` | Metric retention period |
| `prometheus_pvc_size` | `50Gi` | Prometheus storage PVC |
| `grafana_admin_password` | (from secret) | Grafana admin password |
| `grafana_nodeport` | `31300` | Grafana NodePort |
| `alertmanager_slack_webhook` | (from secret) | Slack notification URL |
