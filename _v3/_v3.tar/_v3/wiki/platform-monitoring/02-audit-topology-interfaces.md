# 02 — Audit Topology & Interfaces

## Overview

Live audit playbook that validates interface admin/oper state, BGP session status, BFD health, LLDP neighbors, and VXLAN tunnel endpoints across the entire fabric. Produces a health report with pass/fail per link.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/audit_topology_interfaces.yml` |
| Category | Platform Monitoring |
| Profiles | KVM + Real Hardware |
| Execution Order | **#2 in monitoring** — Run anytime (periodic or on-demand) |
| Prerequisites | Fabric deployed; SSH access to all devices |
| Idempotent | Yes (read-only audit) |

---

## Execution Note

### KVM Profile
Validates all KVM fabric links. Useful after VM reboots or snapshot restores to confirm BGP reconvergence.

```bash
ansible-playbook playbooks/reused/audit_topology_interfaces.yml \
  -i inventory/hosts.yml -v

# Audit specific layer:
ansible-playbook playbooks/reused/audit_topology_interfaces.yml \
  -i inventory/hosts.yml --tags bgp -v
```

### Real Hardware Profile
Critical for production change validation. Run before and after any fabric maintenance window. Export report to monitoring system.

```bash
ansible-playbook playbooks/reused/audit_topology_interfaces.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `interfaces` | Switches | Check admin_status, oper_status, MTU |
| `bgp` | All | Validate BGP Established state |
| `bfd` | All | Check BFD session state |
| `lldp` | Switches | Validate expected LLDP neighbors |
| `vxlan` | Leaves + Hypervisors | Check VXLAN tunnel endpoints |
| `report` | Deployer | Generate consolidated health report |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `audit_report_dir` | `/tmp/fabric-audit/` | Output directory for reports |
| `audit_fail_on_error` | `false` | Fail playbook if any check fails |
| `audit_export_prometheus` | `false` | Push metrics to Prometheus Pushgateway |
