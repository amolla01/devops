# 04 — K8s Dashboard & Management Tools

## Overview

Deployment and configuration of Kubernetes Dashboard, Lens connectivity, and other cluster management UIs. Covers service account creation, RBAC tokens, LoadBalancer (MetalLB BGP) exposure, and secure remote access patterns.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/sheba-k8-cluster-dashboard-tool-setup.html` |
| Category | Platform Monitoring |
| Profiles | KVM + Real Hardware |
| Execution Order | **#04** — After monitoring stack (01), Day 2 operations |

---

## Components

| Tool | Purpose | Access Method |
|------|---------|--------------|
| Kubernetes Dashboard | Web UI for cluster management | LoadBalancer IP (MetalLB BGP) |
| Metrics Server | CPU/memory metrics for HPA + Dashboard | Internal (ClusterIP) |
| Lens Desktop | Rich desktop IDE for K8s | kubeconfig + SSH tunnel |
| k9s | Terminal UI for K8s | SSH to controller node |

---

## Kubernetes Dashboard Deployment

### Install

```bash
# Deploy Kubernetes Dashboard
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml

# Patch to LoadBalancer (MetalLB BGP assigns IP from pool)
kubectl -n kubernetes-dashboard patch svc kubernetes-dashboard \
  -p '{"spec":{"type":"LoadBalancer","ports":[{"port":443,"targetPort":8443}]}}'

# Verify MetalLB assigned an IP:
kubectl get svc kubernetes-dashboard -n kubernetes-dashboard
# EXTERNAL-IP will show MetalLB-assigned IP (e.g. 172.16.2.2xx)
```

### Create Admin Service Account

```bash
kubectl create serviceaccount dashboard-admin -n kubernetes-dashboard
kubectl create clusterrolebinding dashboard-admin \
  --clusterrole=cluster-admin \
  --serviceaccount=kubernetes-dashboard:dashboard-admin

# Generate token
kubectl -n kubernetes-dashboard create token dashboard-admin --duration=87600h
```

### Access via Ingress (Production)

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: dashboard-ingress
  namespace: kubernetes-dashboard
  annotations:
    nginx.ingress.kubernetes.io/backend-protocol: "HTTPS"
    nginx.ingress.kubernetes.io/ssl-passthrough: "true"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - dashboard.lab.local
  rules:
  - host: dashboard.lab.local
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: kubernetes-dashboard
            port:
              number: 443
```

---

## Metrics Server

```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

# For self-signed certs (lab):
kubectl -n kube-system patch deployment metrics-server \
  --type=json -p='[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'

# Verify
kubectl top nodes
kubectl top pods -A
```

---

## Remote Access Patterns

### SSH Tunnel (Secure)

```bash
ssh -L 30443:localhost:30443 user@172.16.2.11
# Then browse: https://localhost:30443
```

### Lens Desktop

```bash
scp user@172.16.2.11:~/.kube/config ~/.kube/lab-config
export KUBECONFIG=~/.kube/lab-config
```

---

## Execution Note

### KVM Profile
Dashboard is auto-deployed by Kubespray if `dashboard_enabled: true` in group_vars. Otherwise deploy manually post-Kubespray. Access via MetalLB-assigned LoadBalancer IP (BGP /32 route reachable from any host on the fabric).

### Real Hardware Profile
Same deployment. MetalLB LoadBalancer IP used as primary access. Optional: add Ingress with proper TLS certificates for hostname-based access.
