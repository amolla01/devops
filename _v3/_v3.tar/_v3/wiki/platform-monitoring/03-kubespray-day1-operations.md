# 03 — Kubespray Day-1 Operations

## Overview

Kubernetes node lifecycle management: add/remove worker nodes, cordon/drain for maintenance, upgrade K8s version, rotate certificates, and etcd backup/restore operations.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/kubespray_day1_operations.yml` |
| Category | Platform Monitoring |
| Profiles | KVM + Real Hardware |
| Execution Order | **#3 in monitoring** — On-demand for cluster maintenance |
| Prerequisites | Running K8s cluster deployed via Kubespray |
| Idempotent | Yes (operation-dependent) |

---

## Execution Note

### KVM Profile
Use for lab cluster maintenance: adding worker VMs, testing upgrade procedures, practicing etcd backup/restore.

```bash
# Add a node:
ansible-playbook playbooks/reused/kubespray_day1_operations.yml \
  -i inventory/hosts.yml --tags add_node --limit new_worker -v

# Upgrade K8s:
ansible-playbook playbooks/reused/kubespray_day1_operations.yml \
  -i inventory/hosts.yml --tags upgrade -v

# etcd backup:
ansible-playbook playbooks/reused/kubespray_day1_operations.yml \
  -i inventory/hosts.yml --tags etcd_backup -v
```

### Real Hardware Profile
Same operations with production safeguards: pre-drain workloads, PDB-aware eviction, backup verification before upgrade.

```bash
# Drain + remove node for hardware maintenance:
ansible-playbook playbooks/reused/kubespray_day1_operations.yml \
  -i inventory/hosts.yml --tags drain,remove_node --limit target_worker -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `add_node` | New node | Join new worker to cluster |
| `remove_node` | Target node | Cordon, drain, delete from cluster |
| `drain` | Target node | Evict pods (PDB-aware) |
| `upgrade` | All nodes | Rolling K8s version upgrade |
| `cert_rotate` | Controllers | Rotate cluster certificates |
| `etcd_backup` | Controllers | Snapshot etcd to backup location |
| `etcd_restore` | Controllers | Restore etcd from snapshot |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `kube_upgrade_target` | (required) | Target K8s version for upgrade |
| `etcd_backup_dir` | `/opt/etcd-backups/` | Backup storage path |
| `drain_timeout` | `300` | Drain timeout in seconds |
| `drain_delete_emptydir` | `true` | Delete emptyDir pods on drain |
