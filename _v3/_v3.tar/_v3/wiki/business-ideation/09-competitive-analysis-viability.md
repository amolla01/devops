# 09 — Competitive Analysis & Market Viability

## Overview

Deep competitive analysis of the Bangladesh e-commerce landscape and viability assessment for NoyoBazar.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/19-competitive-analysis.html, 18-viability-synthesis.html` |
| Category | Business Ideation |
| Type | Market Analysis |

---

## Competitive Landscape

| Competitor | Model | GMV (est.) | Strengths | Weaknesses |
|-----------|-------|-----------|-----------|-----------|
| Daraz (Alibaba) | B2C marketplace | $500M | Brand, logistics, capital | High burn, foreign-owned |
| Chaldal | Grocery (own inventory) | $100M | Execution, loyalty | Single vertical |
| Pathao | Ride-hailing + food | $80M | Driver network | Not commerce-focused |
| Bikroy | Classifieds (C2C) | $50M | Large user base | No transactions |
| Sheba.xyz | Services | $30M | Service expertise | No products |

---

## SWOT Analysis

| | Positive | Negative |
|---|---------|---------|
| **Internal** | Self-hosted infra, data sovereignty, multi-vertical | New brand, limited capital |
| **External** | 170M pop (3% online), govt digitization | Alibaba capital, regulatory uncertainty |

---

## Differentiation

| Factor | NoyoBazar | Daraz | Chaldal |
|--------|-----------|-------|---------|
| Infra Cost | $0.5K/mo | $50K+/mo | $20K/mo |
| Data Sovereignty | 100% local | Singapore | Partial |
| Seller Take Rate | 5–8% | 10–25% | N/A |
| Export Capability | Yes | Limited | No |
| Open Source | 100% | No | No |

---

## Viability Score: 7.3/10

| Factor | Score | Rationale |
|--------|-------|-----------|
| Market Size | 9 | 170M pop, $400B GDP |
| Competition | 6 | No dominant multi-vertical player |
| Technical | 9 | Full stack proven |
| Financial | 7 | Low burn via infra advantage |
| Regulatory | 5 | Evolving but supportive |
| Team | 8 | Full-stack + domain |
