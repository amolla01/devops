# 04 — Software Deployment Strategy (NoyoBazar)

## Overview

Complete software deployment strategy for the NoyoBazar application stack including microservice architecture, technology choices, deployment pipelines, and per-store software customization patterns.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/47-*.html, 48-*.html, 49-*.html, 50-*.html` |
| Category | Business Ideation |
| Type | Technical Architecture & Deployment Strategy |

---

## Application Microservices

| Service | Technology | Database | Purpose |
|---------|-----------|----------|---------|
| User Service | Go (Fiber) | PostgreSQL | Auth, profiles, RBAC |
| Catalog Service | Go (Fiber) | PostgreSQL + OpenSearch | Products, search |
| Order Service | Go (Fiber) | PostgreSQL | Cart, checkout, lifecycle |
| Payment Service | Go (Fiber) | PostgreSQL | Payment gateway |
| Notification Service | Node.js | Redis | Push, SMS, email |
| Logistics Service | Go (Fiber) | PostgreSQL + Redis | Delivery tracking |
| Analytics Service | Python (FastAPI) | ClickHouse | BI, reporting |
| Media Service | Go | MinIO (S3) | Image/video upload |
| Seller Portal | Next.js | — | Dashboard, inventory |
| Customer App (API) | Go (Gateway) | — | BFF for clients |

---

## Open Source Technology Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Backend | Go 1.22+ | Performance, small binary |
| Web Framework | Fiber / FastAPI | High throughput |
| Frontend | Next.js 14 | SSR + SSG, SEO |
| Mobile | Flutter 3.x | Single codebase |
| Database | PostgreSQL 16 | ACID, JSON, proven |
| Cache | Redis 7 | Session, rate limiting |
| Search | OpenSearch 2.11 | Full-text, analytics |
| Message Queue | RabbitMQ 3.12 | Reliable async |
| Storage | MinIO | S3-compatible |
| CI/CD | Tekton + ArgoCD | GitOps |

---

## Per-Store Customization

| Level | Mechanism | Example |
|-------|-----------|---------|
| Branding | ConfigMap per tenant | White-label storefront |
| Feature Flags | OpenBao + Redis | Enable/disable payment methods |
| Custom Domain | Ingress + cert-manager | store.mybrand.com.bd |
| Dedicated Resources | Separate namespace | Enterprise tier |

---

## Deployment Pipeline

```
Gitea → Tekton (CI) → Harbor (Registry) → ArgoCD (CD) → K8s
```

| Environment | Namespace | Auto-Deploy |
|-------------|-----------|-------------|
| Development | `noyobazar-dev` | On push |
| Staging | `noyobazar-staging` | On merge to main |
| Production | `noyobazar-prod` | Manual approval |
