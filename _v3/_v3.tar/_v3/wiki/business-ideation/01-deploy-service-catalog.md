# 01 — Deploy Service Catalog

## Overview

Deploys a service catalog framework for validating platform features end-to-end. Creates sample workloads (web app, database, message queue) that exercise the full stack: Ceph storage, Ingress, monitoring, auto-scaling, and GitOps delivery.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_service_catalog.yml` |
| Category | Business Ideation |
| Profiles | KVM + Real Hardware |
| Execution Order | **#1 in ideation** — After all infrastructure + business software is deployed |
| Prerequisites | Full platform running (K8s, Ceph, monitoring, SDLC stack) |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Deploys sample catalog entries to validate the platform works end-to-end in the lab. Exercises storage, networking, monitoring, and CI/CD pipelines.

```bash
ansible-playbook playbooks/reused/deploy_service_catalog.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same as KVM. Used for platform acceptance testing and demo environments.

```bash
ansible-playbook playbooks/reused/deploy_service_catalog.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `catalog` | K8s | Deploy service catalog CRDs + controller |
| `samples` | K8s | Deploy sample workloads for validation |
| `verify` | K8s | End-to-end acceptance tests |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `catalog_namespace` | `service-catalog` | Catalog namespace |
| `sample_app_replicas` | `2` | Sample app replica count |
| `sample_pvc_size` | `1Gi` | PVC size for sample workloads |
