# 06 — Staffing Blueprint & Team Structure

## Overview

Organizational design and staffing plan for the NoyoBazar/Sheba platform company. Covers team structure, hiring priorities, compensation, and phased team growth.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/15-staffing-blueprint.html, 00-STAFFING-SUMMARY.html` |
| Category | Business Ideation |
| Type | Organizational Design & HR Strategy |

---

## Team Structure (Phase 1: Launch)

| Department | Roles | Headcount | Priority |
|-----------|-------|-----------|----------|
| Engineering | Backend, Frontend, DevOps/SRE | 8 | Critical |
| Product | PM, UX Designer, Data Analyst | 3 | Critical |
| Operations | Seller Onboarding, Support, QA | 5 | High |
| Business | Sales, Marketing, Partnerships | 4 | High |
| Leadership | CEO, CTO, COO | 3 | Founding |

---

## Engineering Team

| Role | Count | Skills | Salary (BDT/mo) |
|------|-------|--------|-----------------|
| Sr Backend (Go) | 2 | Go, PostgreSQL, K8s | ৳120K–180K |
| Backend (Go/Node) | 2 | Go/Node, REST/gRPC | ৳70K–120K |
| Frontend (React) | 2 | Next.js, TypeScript | ৳80K–130K |
| Mobile (Flutter) | 1 | Flutter, Dart | ৳80K–130K |
| DevOps/SRE | 1 | K8s, Ansible, CI/CD | ৳100K–160K |

---

## Phased Growth

| Phase | Timeline | Team Size | Milestone | Monthly Payroll |
|-------|----------|-----------|-----------|-----------------|
| Pre-seed | Month 0–3 | 5 | MVP built | ৳400K ($3.6K) |
| Seed | Month 4–9 | 15 | 500 sellers | ৳1.5M ($13.6K) |
| Growth | Month 10–18 | 35 | 5K sellers | ৳3.5M ($31.8K) |
| Scale | Month 19–36 | 80 | 50K sellers | ৳8M ($72.7K) |

---

## Key Principles

- **Local talent first** — BD CS talent at 1/10th US cost
- **Full-stack bias** — Small team, versatile engineers
- **Infrastructure competency** — Self-hosted needs ops from Day 1
- **Remote-first** — Access talent outside Dhaka
