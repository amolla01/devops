# 10 — Infrastructure Tech Stack Blueprint

## Overview

Complete technology stack specification linking business requirements to infrastructure decisions. Documents every technology choice, version, licensing, and business rationale.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/46-infrastructure-tech-stack-blueprint.html, 34-open-source-tech-stack.html` |
| Category | Business Ideation |
| Type | Technical Architecture (Business-aligned) |

---

## Selection Criteria

| Criterion | Weight | Rationale |
|-----------|--------|-----------|
| Open Source | Critical | No vendor lock-in, cost control |
| Self-Hostable | Critical | Data sovereignty, compliance |
| Production Proven | High | Stability, hiring pool |
| K8s Native | High | Consistent deployment |
| Active Community | Medium | Patches, docs |

---

## Infrastructure Layer

| Component | Technology | License | Cloud Equivalent | Annual Savings |
|-----------|-----------|---------|-----------------|----------------|
| Hypervisor | KVM/QEMU | GPL | VMware | $15K |
| Network OS | SONiC | Apache 2.0 | Cisco ACI | $50K |
| Provisioning | MaaS | AGPL | AWS Nitro | $5K |
| K8s | Kubespray | Apache 2.0 | EKS/GKE | $20K |
| Storage | Rook-Ceph | Apache 2.0 | EBS/S3 | $30K |
| Cloud | OpenStack | Apache 2.0 | AWS/GCP | $100K+ |

## Platform Layer

| Component | Technology | Cloud Equivalent |
|-----------|-----------|-----------------|
| Database | PostgreSQL 16 | RDS |
| Cache | Redis 7 | ElastiCache |
| Queue | RabbitMQ 3.12 | SQS |
| Search | OpenSearch 2.11 | ES Service |
| Objects | MinIO | S3 |
| Secrets | OpenBao | Secrets Manager |

## DevOps Layer

| Component | Technology | Cloud Equivalent |
|-----------|-----------|-----------------|
| Git | Gitea | GitHub SaaS |
| Registry | Harbor | ECR |
| CI | Tekton | GitHub Actions |
| CD | ArgoCD | Spinnaker |
| Quality | SonarQube | SonarCloud |
| Docs | BookStack | Confluence |

---

## Cost Comparison

| Category | Self-Hosted | Cloud | Savings |
|----------|-----------|-------|---------|
| Compute | $2,400/yr | $36,000/yr | $33,600 |
| Storage | $100/yr | $3,600/yr | $3,500 |
| Database | $0 | $7,200/yr | $7,200 |
| K8s | $0 | $8,760/yr | $8,760 |
| Networking | $500/yr | $12,000/yr | $11,500 |
| DevOps Tools | $0 | $15,000/yr | $15,000 |
| **TOTAL** | **$3,000** | **$82,560** | **$79,560 (96%)** |
