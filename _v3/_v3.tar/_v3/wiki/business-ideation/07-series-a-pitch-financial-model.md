# 07 — Series A Pitch & Financial Model

## Overview

Investor-facing Series A pitch deck framework and detailed financial model for NoyoBazar/Sheba.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/21-series-a-pitch.html, 24-financial-model.html, 45-financing-equity.html` |
| Category | Business Ideation |
| Type | Investor Relations & Financial Planning |

---

## Fundraising Summary

| Round | Amount | Valuation (Pre) | Dilution | Timeline |
|-------|--------|-----------------|----------|----------|
| Pre-seed | $50K (founder) | — | — | Done |
| Seed | $300K–500K | $2–3M | 15–20% | Month 6–9 |
| Series A | $2–5M | $15–25M | 15–25% | Month 18–24 |
| Series B | $10–20M | $80–120M | 15–20% | Month 36+ |

---

## Use of Funds (Series A)

| Category | Allocation | Purpose |
|----------|-----------|---------|
| Engineering | 40% | Scale team to 25+ |
| Sales & Marketing | 30% | Seller acquisition, GTM |
| Operations | 15% | Logistics, support, compliance |
| Infrastructure | 10% | Scale DC, DR site |
| Reserve | 5% | Runway buffer |

---

## Unit Economics

| Metric | Value | Notes |
|--------|-------|-------|
| AOV | $15 (domestic) / $5K (export B2B) | Blended |
| Take Rate | 8% (domestic) / 2% (export) | By category |
| CAC | $2 (buyer) / $15 (seller) | Field + digital |
| LTV | $25 (buyer) / $200 (seller) | 12-month |
| LTV/CAC | 12.5x / 13.3x | Healthy >3x |
| Gross Margin | 65–75% | No inventory |

---

## Revenue Projections

| Year | GMV | Revenue | EBITDA |
|------|-----|---------|--------|
| 1 | $7M | $350K | -$300K |
| 2 | $75M | $5.5M | -$500K |
| 3 | $450M | $38M | $5M |
| 4 | $1.2B | $95M | $25M |

---

## Risk Factors

| Risk | Probability | Mitigation |
|------|-------------|-----------|
| Regulatory | Medium | Compliance-first |
| Competition | High | Niche focus, cost advantage |
| Execution | Medium | Culture, ESOP |
| Market adoption | Low | Field agents, training |
| Technical downtime | Low | HA, monitoring, DR |
