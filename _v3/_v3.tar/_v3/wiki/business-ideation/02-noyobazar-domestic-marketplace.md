# 02 — NoyoBazar Domestic Marketplace Strategy

## Overview

Comprehensive strategy document for the NoyoBazar domestic marketplace platform targeting Bangladesh's local commerce ecosystem. Covers grocery, auto-parts, and general merchandise verticals with seller acquisition, monetization models, and go-to-market approach.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/11-*.html through 24-*.html` (Domestic Marketplace Series) |
| Category | Business Ideation |
| Market | Bangladesh Domestic |
| Type | Strategy & Business Plan |

---

## Executive Summary

NoyoBazar is a unified digital marketplace platform designed to connect local sellers in Bangladesh with consumers through a technology-first approach. The platform leverages the self-hosted infrastructure (deployed via _v3 playbooks) to maintain data sovereignty, minimize cloud costs, and provide a competitive advantage through operational efficiency.

> This document consolidates insights from cheat-sheet papers #11–24 which individually cover: Service Catalog & Monetization, Grocery Marketplace, Auto Parts Marketplace, Bangladesh Unified Marketplace, Integration Guide, Staffing Blueprint, Local Store Seller Use Case, Burden Offloading, Viability Synthesis, Competitive Analysis, Seller Acquisition, Series A Pitch, GTM Plan, and Seller Success.

---

## Market Verticals

| Vertical | TAM (Bangladesh) | Initial Focus | Monetization |
|----------|-------------------|---------------|--------------|
| Grocery & Daily Essentials | $45B | Dhaka metro | Commission 5–8% + delivery fees |
| Auto Parts & Services | $3.2B | Nationwide (B2B first) | Subscription + commission 8–12% |
| General Merchandise | $12B | Tier-1 cities | Commission 10–15% + ads |
| Services Marketplace | $8B | Urban centers | Lead gen fees + SaaS subscriptions |

---

## Platform Architecture (Business View)

| Layer | Components | Infrastructure Mapping |
|-------|-----------|----------------------|
| Customer Apps | Mobile (Flutter), Web (Next.js), PWA | K8s + CDN |
| Seller Portal | Dashboard, Inventory, Analytics | K8s + PostgreSQL |
| Core Services | Catalog, Orders, Payments, Logistics | K8s microservices + RabbitMQ |
| Data Platform | Analytics, ML Recommendations, Search | OpenSearch + Redis + PostgreSQL |
| Infrastructure | Self-hosted DC, CI/CD, Monitoring | Full _v3 stack (playbooks 01–16) |

---

## Seller Acquisition Strategy

| Phase | Target | Approach | Timeline |
|-------|--------|----------|----------|
| Seed (0–500 sellers) | Existing known stores | Direct sales, free onboarding | Month 1–3 |
| Growth (500–5000) | Category leaders | Referral program + field agents | Month 4–9 |
| Scale (5000+) | Long tail SMBs | Self-serve onboarding + partners | Month 10–18 |

---

## Monetization Models

| Revenue Stream | Model | Target Margin |
|----------------|-------|---------------|
| Transaction Commission | 5–15% per sale | Primary revenue |
| Subscription (Seller Tools) | $5–50/month tiered | Recurring baseline |
| Advertising / Promoted Listings | CPC/CPM model | High margin (70%+) |
| Logistics as a Service | Per-delivery fee | Break-even initially |
| Financial Services (Future) | Seller lending | Interest + fees |

---

## Financial Projections (Year 1–3)

| Metric | Year 1 | Year 2 | Year 3 |
|--------|--------|--------|--------|
| Active Sellers | 2,000 | 15,000 | 50,000 |
| Monthly Active Users | 50,000 | 500,000 | 2,000,000 |
| GMV | $2M | $25M | $150M |
| Revenue | $150K | $2.5M | $18M |
| Burn Rate (monthly) | $30K | $80K | $120K |

---

## Competitive Advantage

Self-hosted infrastructure eliminates $50K–200K/year in cloud costs, ensures data sovereignty (Bangladesh Data Protection Act compliance), and provides 100% operational control with no vendor lock-in.

| Competitor | Model | NoyoBazar Differentiation |
|-----------|-------|--------------------------|
| Daraz (Alibaba) | Cloud-hosted, foreign-owned | Local ownership, lower take-rate |
| Chaldal | Grocery-only, own inventory | Multi-vertical, asset-light |
| Pathao | Ride-hailing + food | Full commerce ecosystem |
| Shopify BD resellers | SaaS tools only | Integrated marketplace + tools |
