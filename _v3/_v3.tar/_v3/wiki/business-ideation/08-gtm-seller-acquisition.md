# 08 — Go-to-Market & Seller Acquisition Plan

## Overview

Detailed GTM strategy for NoyoBazar covering domestic and export marketplace launches with seller acquisition playbook and sales targets.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/22-GTM-plan.html, 20-seller-acquisition.html, 23-seller-success.html` |
| Category | Business Ideation |
| Type | Go-to-Market Strategy |

---

## GTM Phases

| Phase | Focus | Duration | Key Metrics |
|-------|-------|----------|-------------|
| 1. Supply Building | Onboard sellers, build catalog | Month 1–6 | 500 sellers, 50K SKUs |
| 2. Demand Generation | Buyer acquisition | Month 4–12 | 50K buyers, $2M GMV |
| 3. Marketplace Flywheel | Network effects | Month 10–18 | 5K sellers, 200K buyers |
| 4. Category Expansion | New verticals, export | Month 15–24 | 20K sellers, $50M GMV |

---

## Seller Acquisition Channels

| Channel | Cost per Seller | Volume | Quality |
|---------|----------------|--------|---------|
| Direct Field Sales | $15–25 | Medium | High |
| Referral Program | $5–10 | High | Medium-High |
| Digital Marketing | $8–15 | High | Medium |
| Trade Associations | $3–5 | Very High | Medium |
| WhatsApp Communities | $2–5 | Medium | Medium |

---

## Sales Targets (2026)

| Quarter | New Sellers | Active Buyers | GMV | Revenue |
|---------|------------|---------------|-----|---------|
| Q1 | 2,000 | 100K | $5M | $400K |
| Q2 | 3,500 | 250K | $12M | $960K |
| Q3 | 5,000 | 500K | $25M | $2M |
| Q4 | 8,000 | 800K | $45M | $3.6M |

---

## Partnership Strategy

| Partner Type | Value Exchange | Examples |
|-------------|---------------|---------|
| Payment Gateways | Volume → lower rates | bKash, Nagad |
| Logistics | Volume → discounts | Pathao, RedX |
| Trade Associations | Member access → tools | BGMEA, DCCI |
| Banks | Seller data → lending | BRAC Bank, Grameen |
