# 05 — Set Interface Properties

## Overview

Utility playbook to set SONiC interface properties (admin_status, MTU, speed, FEC) across fabric, uplink, downlink, and exit interfaces. Used after Day 0 to enable physical links.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/set_interface_properties.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#5** — Immediately after Day 0 provisioning |
| Prerequisites | Day 0 complete; switches reachable |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Sets interface admin state to UP and configures MTU 9216 on all fabric links. Speed/FEC settings are no-op on virtual interfaces.

```bash
ansible-playbook playbooks/reused/set_interface_properties.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Critical step — configures speed (100G/40G/10G), FEC mode (rs/fc/none), and MTU on physical optics. Match hardware capabilities per switch model.

```bash
ansible-playbook playbooks/reused/set_interface_properties.yml \
  -i inventory/hosts.yml -v
```

---

## Scope Tags

| Tag | Scope | Description |
|-----|-------|-------------|
| `fabric` | Spine ↔ Leaf links | Inter-switch fabric uplinks |
| `uplink` | Leaf → Spine | Leaf uplink interfaces |
| `downlink` | Leaf → Server | Server-facing downlinks |
| `exit` | Border → Exit Router | External connectivity links |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `fabric_mtu` | `9216` | Jumbo frame MTU for fabric |
| `downlink_mtu` | `9000` | Server-facing MTU |
| `fabric_speed` | (per-model) | Link speed (100G, 40G, 10G) |
| `fabric_fec` | `rs` | Forward Error Correction mode |
