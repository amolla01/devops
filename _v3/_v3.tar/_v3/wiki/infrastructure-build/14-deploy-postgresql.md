# 14 — Deploy PostgreSQL

## Overview

Deploys PostgreSQL as a Helm chart on Kubernetes. Serves as the database backend for MaaS, Gitea, Plane, SonarQube, and other platform services. Includes PVC-backed storage via Ceph RBD.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_postgresql.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#14** — After Ceph storage is healthy (OSDs up) |
| Prerequisites | Ceph RBD StorageClass available; K8s cluster ready |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Deploys single-instance PostgreSQL with 10Gi PVC on Ceph RBD. Suitable for lab workloads.

```bash
ansible-playbook playbooks/reused/deploy_postgresql.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Deploy with HA (primary + streaming replica) and larger PVC. Ensure Ceph pool has sufficient capacity.

```bash
ansible-playbook playbooks/reused/deploy_postgresql.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `deploy` | K8s controller | Helm install PostgreSQL chart |
| `databases` | K8s controller | Create application databases and users |
| `verify` | K8s controller | Validate connectivity and readiness |
| `backup` | K8s controller | Configure pg_dump CronJob |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `postgresql_namespace` | `database` | Kubernetes namespace |
| `postgresql_version` | `16` | PostgreSQL major version |
| `postgresql_pvc_size` | `10Gi` | PVC storage size |
| `postgresql_storage_class` | `rook-ceph-block` | StorageClass name |
| `postgresql_databases` | `[maas, gitea, plane, sonar]` | Auto-created databases |
