# 04 — Deploy Day 0 (Base Provisioning)

## Overview

Unified day-0 base provisioning for SONiC switches, MikroTik exit routers, and Ubuntu servers. Renders device-specific configurations from templates, validates, and pushes to all fabric devices.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_day0.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#4** — After server OS is installed (MaaS or manual) |
| Prerequisites | All devices reachable via management network; SSH keys deployed |
| Idempotent | Yes — push is diff-based |

---

## Execution Note

### KVM Profile
Run after all 6 VMs are booted and SONiC KVM instances are running. Configures base system properties (hostname, management IP, NTP, syslog, AAA).

```bash
ansible-playbook playbooks/reused/deploy_day0.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Run after MaaS has commissioned all servers and switches have SONiC installed via ONIE. Establishes the base device identity across all fabric nodes.

```bash
ansible-playbook playbooks/reused/deploy_day0.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `render` | Deployer | Render config templates from inventory |
| `validate` | Deployer | Dry-run validation of generated configs |
| `push` | All devices | Push configurations to devices |
| `reload` | Switches | Reload config (SONiC `config reload`) |
| `verify` | All devices | Post-push verification |
| `preflight` | All devices | Pre-deployment connectivity checks |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `day0_management_vrf` | `default` | Management VRF name |
| `day0_ntp_servers` | `[172.16.2.1]` | NTP server list |
| `day0_syslog_server` | `172.16.2.47` | Central syslog target |
| `day0_dns_servers` | `[8.8.8.8, 1.1.1.1]` | DNS resolver list |
