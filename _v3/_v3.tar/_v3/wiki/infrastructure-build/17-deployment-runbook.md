# 17 — Deployment Runbook (R810 Full Lab Build)

## Overview

Step-by-step phased runbook for deploying the complete _v3 platform on Dell R810 hardware. Covers destroy, infrastructure, platform, and services phases with exact command sequences and validation gates between each phase.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/08-deployment-runbook.html` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Type | Operational Runbook |
| Execution Order | **#17** — Master orchestration guide (references playbooks 01–16) |

---

## Phase Summary

| Phase | Name | Playbooks Invoked | Duration (est.) |
|-------|------|-------------------|-----------------|
| 0 | Destroy / Clean Slate | Teardown all VMs, wipe disks | 5 min |
| 1 | Infrastructure Base | Preflight → Day 0 → Interfaces → Day 1 | 30 min |
| 2 | Fabric Wiring | Leaf-Server BGP → Server Networking → EVPN | 20 min |
| 3 | Platform Services | Kubespray → Ceph → PostgreSQL → Monitoring | 45 min |
| 4 | Application Layer | OpenStack → Sheba Infra → SDLC → Catalog | 30 min |

---

## Execution Note

### KVM Profile
Full lab rebuild from scratch on the R810 hypervisor. Total time ~2 hours for a clean deploy from Phase 0 through Phase 4.

```bash
# Phase 0: Destroy existing
ansible-playbook playbooks/reused/teardown.yml \
  -i inventory/hosts.yml --tags full_destroy -v

# Phase 1–4: Sequential deploy
ansible-playbook playbooks/reused/preflight_download.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_day0.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/set_interface_properties.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_day1.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_leaf_server_bgp.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_server_networking.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_sonic_evpn.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_evpn_overlay.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_kubespray.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_ceph_rook.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_postgresql.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_monitoring.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_openstack_helm.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_sheba_cloud_infra.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_sheba_infra_services.yml -i inventory/hosts.yml -v
ansible-playbook playbooks/reused/deploy_sheba_sdlc_services.yml -i inventory/hosts.yml -v
```

### Real Hardware Profile
Production deployment uses same sequence with additional validation gates. Run `audit_topology_interfaces.yml` after each phase transition.

```bash
# Same sequence as KVM, but with validation between phases:
ansible-playbook playbooks/reused/audit_topology_interfaces.yml \
  -i inventory/hosts.yml -v  # After each phase
```

---

## Validation Gates

| After Phase | Validation Check | Pass Criteria |
|-------------|-----------------|---------------|
| 1 | All BGP sessions | 100% Established |
| 2 | EVPN routes + VXLAN tunnels | Type-3 routes present, tunnels UP |
| 3 | K8s nodes + Ceph health | All nodes Ready, HEALTH_OK |
| 4 | OpenStack endpoint check | All services registered in Keystone |
