# 13 — Deploy Ceph (Rook Operator)

## Overview

Deploys Ceph distributed storage cluster via Rook operator on Kubernetes. Provisions MON, MGR, OSD daemons across worker nodes, enables the Ceph Dashboard, and creates the default storage pools.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_ceph_rook.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#13** — After MetalLB (#12b) and Kubernetes (post-Kubespray) |
| Prerequisites | K8s cluster Ready; MetalLB deployed; worker nodes have raw block devices (vdb/sdb); Rook Helm chart in cache |
| Idempotent | Partially — Phase 0 disk wipe is destructive on first run |

---

## Execution Note

### KVM Profile
Each worker VM has a dedicated /dev/vdb (20–50 GB) for OSD. Phase 0 wipes these devices. Rook operator deploys MON on controllers, OSD on workers.

```bash
ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Ensure raw SSDs/HDDs are available (no partitions, no LVM). Phase 0 will wipe them. For NVMe, specify device filter in Helm values.

```bash
ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml -v
```

---

## Phase Breakdown

| Phase | Name | Description |
|-------|------|-------------|
| 0 | Disk Wipe | Zap OSD devices (sgdisk, wipefs, dd) |
| 1 | Operator | Deploy Rook operator via Helm |
| 2 | Cluster CR | Deploy CephCluster CR; wait for MONs |
| 3 | Dashboard | Wait for MGR + patch dashboard to LoadBalancer (MetalLB assigns IP) |
| 4 | Toolbox | Deploy Ceph toolbox pod for CLI access |
| 5 | Pool + SC | Create replicapool + StorageClass |
| 5b | Teardown | Remove stale DM/LVM entries (re-deploy) |

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `wipe` | Workers | Phase 0 disk wipe |
| `operator` | K8s controller | Rook operator Helm install |
| `cluster` | K8s controller | CephCluster CR apply |
| `dashboard` | K8s controller | Dashboard LoadBalancer patch (MetalLB) |
| `toolbox` | K8s controller | Deploy rook-ceph-tools pod |
| `pool` | K8s controller | Create RBD pool + StorageClass |
| `teardown` | Workers | Cleanup device-mapper/LVM |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `rook_operator_version` | `v1.14.7` | Rook operator chart version |
| `ceph_image` | `quay.io/ceph/ceph:v18` | Ceph container image (Reef) |
| `ceph_osd_devices` | `[/dev/vdb]` | Block devices for OSD |
| `ceph_dashboard_svc_type` | `LoadBalancer` | Service type for Ceph Dashboard (LoadBalancer via MetalLB, or NodePort fallback) |
| `ceph_pool_replicas` | `3` | Replication factor |
| `ceph_namespace` | `rook-ceph` | Kubernetes namespace |
| `ceph_mds_enabled` | `true` | Enable CephFS (MDS daemons). Override `false` in dev/lab to save memory |
| `ceph_rgw_enabled` | `true` | Enable Object Gateway (RGW). Override `false` in dev/lab to save resources |
| `ceph_rgw_port` | `8080` | RGW HTTP port |
| `ceph_rgw_instances` | `1` | RGW daemon count (2 for prod HA) |

---

## Storage Types Deployed

Ceph provides **three storage paradigms** from a single cluster. All three are deployed by our playbook.

| Type | Protocol | K8s StorageClass | OpenStack Service |
|------|----------|-----------------|-------------------|
| **Block (RBD)** | RADOS Block Device | `ceph-rbd` (RWO, default) | Cinder, Nova, Glance |
| **File (CephFS)** | POSIX over RADOS | `ceph-filesystem` (RWX) | Manila |
| **Object (RGW)** | S3 / Swift REST API | `ceph-bucket` (OBC) | Swift API via RGW |

---

## CephFS (Shared Filesystem)

Controlled by `ceph_mds_enabled: true`.

**Provides:** ReadWriteMany (RWX) PersistentVolumes — multiple pods mount the same volume.

**Use cases:**
- ML training datasets shared across workers
- CMS/media shared upload directories
- OpenStack Manila providing tenant shares
- CI/CD build caches

**Deploys:**
1. MDS daemon(s) — active + standby
2. Pools: `cephfs-metadata` + `cephfs-data`
3. Filesystem: `dc-lab-ceph-fs`
4. StorageClass: `ceph-filesystem` (RWX, non-default)

```yaml
# PVC example (ReadWriteMany)
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: shared-data
spec:
  accessModes: [ReadWriteMany]
  storageClassName: ceph-filesystem
  resources:
    requests:
      storage: 10Gi
```

### Manila Integration

Manila uses `client.manila` keyring to create/delete CephFS subvolumes:

```bash
openstack share type create cephfs_native false
openstack share create --share-type cephfs_native CephFS 10
```

---

## Object Storage (Ceph RGW)

Controlled by `ceph_rgw_enabled: true`.

**Provides:** S3-compatible and Swift-compatible REST API for object storage.

**Deploys:**
1. RGW daemon(s) on MON-labeled nodes
2. Pools: `.rgw.root`, `default.rgw.meta`, `default.rgw.buckets.data`, etc.
3. HTTP port 8080, HTTPS port 8443
4. StorageClass: `ceph-bucket` for ObjectBucketClaims
5. Admin user via `radosgw-admin`

### RGW Pools

| Pool | Purpose |
|------|---------|
| `.rgw.root` | Realm/zone metadata |
| `default.rgw.log` | Usage/sync logs |
| `default.rgw.control` | Watch-notify |
| `default.rgw.meta` | User/bucket metadata |
| `default.rgw.buckets.index` | Bucket listings |
| `default.rgw.buckets.data` | Object data |

### S3 API Usage

```bash
# Get endpoint
kubectl get svc -n rook-ceph rook-ceph-rgw-dc-lab-ceph-store

# Create user
kubectl exec -n rook-ceph deploy/rook-ceph-tools -- \
  radosgw-admin user create --uid=s3user --display-name="S3 User"

# AWS CLI
aws --endpoint-url http://172.16.2.200:8080 s3 mb s3://my-bucket
aws --endpoint-url http://172.16.2.200:8080 s3 cp file.tar.gz s3://my-bucket/
```

### ObjectBucketClaim (K8s-native)

```yaml
apiVersion: objectbucket.io/v1alpha1
kind: ObjectBucketClaim
metadata:
  name: velero-backups
spec:
  bucketName: velero-backups
  storageClassName: ceph-bucket
```

### OpenStack Swift Integration

RGW registers with Keystone and responds to Swift API calls natively:

```yaml
# globals.yml (auto-generated):
enable_swift: "no"
enable_ceph_rgw: "yes"
enable_ceph_rgw_keystone: "yes"
```

```bash
# Tenants use standard Swift CLI:
swift --os-auth-url http://keystone:5000/v3 upload my-container backup.tar.gz
```

> **Benefit:** One Ceph cluster serves block (Cinder/Nova), file (Manila/CephFS), and object (Swift/S3) — no separate storage systems.

---

## Pool Summary (All Types)

| Pool | Application | Type | Consumer |
|------|-------------|------|----------|
| `kube-rbd` | rbd | Block | K8s PVCs |
| `openstack-volumes` | rbd | Block | Cinder |
| `openstack-images` | rbd | Block | Glance |
| `openstack-vms` | rbd | Block | Nova |
| `cephfs-data` | cephfs | File | CephFS / Manila |
| `cephfs-metadata` | cephfs | File | CephFS internal |
| `.rgw.root` | rgw | Object | RGW realm |
| `default.rgw.meta` | rgw | Object | User/bucket metadata |
| `default.rgw.buckets.index` | rgw | Object | Bucket listings |
| `default.rgw.buckets.data` | rgw | Object | Object data |
| `default.rgw.log` | rgw | Object | Usage logs |
| `default.rgw.control` | rgw | Object | Watch-notify |
| `fast-rbd` | rbd | Block (SSD) | Databases |
| `openstack-fast-volumes` | rbd | Block (SSD) | High-IOPS Cinder |

---

## Environment-Specific Feature Overrides

CephFS and RGW are controlled per-environment via `cd/vars/ceph-values-*.yml` (extra-vars, highest precedence):

| Environment | `ceph_mds_enabled` | `ceph_rgw_enabled` | Rationale |
|-------------|---|---|---|
| dev | `false` | `false` | Saves ~200MB/OSD; RBD-only workloads |
| r620-kvm | `false` | `false` | Tight memory budget (128GB host) |
| r810-kvm | `false` | `false` | Resource conservation; enable via `-e` override if testing |
| test | `true` | `true` | Production-like for Manila/S3 integration testing |
| prod | `true` | `true` | Full feature set; 2 RGW instances for HA |
| dr | `true` | `true` | Must match production for failover compatibility |
| real-hardware | `true` | `true` | Full feature set; 2 RGW instances for HA |
