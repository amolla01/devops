# 10 — Deploy EVPN Overlay

## Overview

Deploys L2VNI, L3VNI, VRF, and VXLAN on hypervisor/compute nodes. Creates overlay tenant networks carried over the underlay fabric using OVS + VXLAN tunnels terminating on server VTEPs.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_evpn_overlay.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#10** — After SONiC EVPN address-family is active |
| Prerequisites | EVPN route exchange confirmed between leaves |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Configures OVS bridges and VXLAN ports on KVM hypervisors. Creates tenant VRFs and maps VNIs to bridge domains.

```bash
ansible-playbook playbooks/reused/deploy_evpn_overlay.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same flow. Hypervisors must have OVS 3.x+ compiled with DPDK support for production traffic volumes.

```bash
ansible-playbook playbooks/reused/deploy_evpn_overlay.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `vxlan` | Hypervisors | Configure VXLAN tunnel endpoints |
| `ovs` | Hypervisors | OVS bridge and port configuration |
| `vrf` | All | Create L3 VRF instances |
| `l2vni` | Hypervisors | Map L2VNI to bridge domains |
| `l3vni` | Border switches | Configure L3VNI for inter-VRF routing |
| `verify` | All | Validate tunnel state and MAC learning |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `vxlan_vni_base` | `10000` | Starting VNI number for tenants |
| `l3vni_vrf_map` | (from inventory) | VRF → L3VNI mappings |
| `ovs_dpdk_enabled` | `false` | Enable OVS-DPDK (real HW only) |
| `vxlan_udp_port` | `4789` | Standard VXLAN UDP port |
