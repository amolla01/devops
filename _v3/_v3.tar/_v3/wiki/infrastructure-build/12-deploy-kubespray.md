# 12 — Deploy Kubespray (Kubernetes Cluster)

## Overview

Deploys a production-grade Kubernetes cluster via Kubespray with 3 control-plane nodes and N worker nodes. Includes Calico CNI, MetalLB load balancer, CoreDNS, and offline image support from the preflight cache.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_kubespray.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#12** — After server networking is fully converged |
| Prerequisites | All servers reachable via loopback IPs; DNS resolution working; preflight cache populated |
| Idempotent | Yes (Kubespray is re-entrant) |

---

## Execution Note

### KVM Profile
Deploys K8s across 6 VMs: 3 controllers (Host12_1, Host34_1, HostB12_1) + 3 workers (Host12_2, Host12_3, Host34_2). Uses offline cache for all images/binaries.

```bash
ansible-playbook playbooks/reused/deploy_kubespray.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same topology. Ensure iSCSI/multipath is available on worker nodes for persistent storage. Server loopbacks must be routable before starting.

```bash
ansible-playbook playbooks/reused/deploy_kubespray.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `preflight` | All nodes | Validate prerequisites (swap off, kernel modules) |
| `kubespray` | All nodes | Run full Kubespray cluster deployment |
| `addons` | Controllers | Deploy MetalLB, CoreDNS, metrics-server |
| `kubeconfig` | Deployer | Fetch admin kubeconfig to deployer |
| `verify` | Controllers | Check all nodes Ready, pods Running |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `kube_version` | `v1.29.5` | Kubernetes version |
| `calico_version` | `v3.27.3` | Calico CNI version |
| `metallb_ip_range` | `172.16.2.200-172.16.2.220` | LoadBalancer IP pool |
| `kubespray_offline_enabled` | `true` | Use preflight cache |
| `container_runtime` | `containerd` | CRI runtime |
| `etcd_deployment_type` | `kubeadm` | etcd managed by kubeadm |
