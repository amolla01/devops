# 15 — Deploy OpenStack (Helm)

## Overview

Deploys OpenStack Caracal release on Kubernetes using OpenStack-Helm charts. Includes Keystone, Nova, Neutron (OVN), Glance, Cinder (Ceph RBD backend), Horizon, and Heat services.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_openstack_helm.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#15** — After Ceph + PostgreSQL are healthy |
| Prerequisites | K8s cluster; Ceph RBD pool; PostgreSQL running; MetalLB for service IPs |
| Idempotent | Yes (Helm upgrade) |

---

## Execution Note

### KVM Profile
Deploys minimal OpenStack: Keystone + Nova + Neutron + Glance. Sufficient for VM lifecycle testing on nested KVM.

```bash
ansible-playbook playbooks/reused/deploy_openstack_helm.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Full OpenStack deployment including Cinder, Heat, Horizon. Configure provider networks to map to physical VLANs.

```bash
ansible-playbook playbooks/reused/deploy_openstack_helm.yml \
  -i inventory/hosts.yml -v

# Deploy specific service only:
ansible-playbook playbooks/reused/deploy_openstack_helm.yml \
  -i inventory/hosts.yml --tags neutron -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `infra` | K8s | Deploy RabbitMQ + Memcached + Ingress |
| `keystone` | K8s | Identity service |
| `glance` | K8s | Image service (Ceph backend) |
| `nova` | K8s | Compute service |
| `neutron` | K8s | Networking (OVN) |
| `cinder` | K8s | Block storage (Ceph RBD) |
| `manila` | K8s | Shared filesystems (CephFS backend) |
| `horizon` | K8s | Dashboard |
| `heat` | K8s | Orchestration |
| `verify` | K8s | Run Tempest smoke tests |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `openstack_release` | `2024.1` | OpenStack Caracal |
| `openstack_namespace` | `openstack` | Kubernetes namespace |
| `neutron_plugin` | `ovn` | Neutron ML2 plugin |
| `cinder_backend` | `rook-ceph-block` | Cinder volume backend |
| `glance_backend` | `rbd` | Glance image backend |
| `openstack_domain` | `cloud.lab.local` | Ingress domain |
| `os_manila_enabled` | `true` | Enable Manila shared filesystem service |
| `os_manila_cephfs_name` | `dc-lab-ceph-fs` | CephFS filesystem name for Manila |
| `os_rgw_enabled` | `true` | Enable Ceph RGW (replaces Swift) |
| `os_rgw_port` | `8080` | RGW HTTP port |
| `os_rgw_keystone_integration` | `true` | RGW authenticates via Keystone |

---

## Manila — Shared Filesystems (CephFS)

Manila provides tenant-accessible shared file storage using CephFS as the backend.

### Architecture

```
┌──────────────────┐      ┌─────────────────┐      ┌─────────────────────┐
│  OpenStack Tenant │─────▶│  Manila API      │─────▶│  CephFS (MDS + OSD) │
│  (share request)  │      │  (K8s pod)       │      │  client.manila key  │
└──────────────────┘      └─────────────────┘      └─────────────────────┘
```

### Key Configuration (globals.yml)

```yaml
enable_manila: "yes"
enable_manila_backend_cephfs_native: "yes"
manila_cephfs_filesystem_name: "dc-lab-ceph-fs"
```

### Day-1 Usage

```bash
# Create share type
openstack share type create cephfs_native false
openstack share type set cephfs_native \
  --extra-spec vendor_name=Ceph \
  --extra-spec storage_protocol=CEPHFS

# Create a 10 GB share
openstack share create --share-type cephfs_native CephFS 10

# Grant access to a tenant
openstack share access create <share-id> cephx <ceph-user>
```

### Variables

| Variable | Source | Description |
|----------|--------|-------------|
| `os_manila_enabled` | `openstack_controllers.yml` | Master toggle |
| `os_manila_cephfs_name` | `openstack_controllers.yml` | Filesystem name (`dc-lab-ceph-fs`) |
| `os_manila_cephfs_user` | `openstack_controllers.yml` | Ceph keyring user (`manila`) |
| `osh_manila_replicas` | `openstack_helm.yml` | Pod replica count |
| `osh_manila_password` | `openstack_helm.yml` | Service password (vault-backed) |

---

## Ceph RGW — Object Storage (S3/Swift API)

Ceph RGW replaces the standalone Swift service. It provides S3 and Swift-compatible REST APIs backed by Ceph RADOS.

### Architecture

```
┌──────────────────┐      ┌─────────────────┐      ┌─────────────────────┐
│  Tenant / App    │─────▶│  Ceph RGW        │─────▶│  RADOS Object Store │
│  (S3 or Swift)   │      │  (port 8080)     │      │  (.rgw.* pools)     │
└──────────────────┘      └─────────────────┘      └─────────────────────┘
                                   │
                                   ▼
                          ┌─────────────────┐
                          │  Keystone        │
                          │  (auth tokens)   │
                          └─────────────────┘
```

### Key Configuration (globals.yml)

```yaml
enable_swift: "no"               # Disabled — RGW replaces Swift
enable_ceph_rgw: "yes"
enable_ceph_rgw_keystone: "yes"  # Authenticate via Keystone
ceph_rgw_hosts: "<ceph-mon-nodes>"
ceph_rgw_port: 8080
```

### Day-1 Usage

```bash
# Swift CLI (transparent — same API, backed by RGW)
openstack container create my-container
openstack object create my-container backup.tar.gz

# S3 CLI (via RGW user)
aws --endpoint-url http://172.16.2.200:8080 s3 mb s3://my-bucket
aws --endpoint-url http://172.16.2.200:8080 s3 cp file.tar.gz s3://my-bucket/
```

### Variables

| Variable | Source | Description |
|----------|--------|-------------|
| `os_rgw_enabled` | `openstack_controllers.yml` | Master toggle |
| `os_rgw_port` | `openstack_controllers.yml` | RGW HTTP port (8080) |
| `os_rgw_hosts` | `openstack_controllers.yml` | Ceph MON hosts (RGW runs on MON nodes) |
| `os_rgw_keystone_integration` | `openstack_controllers.yml` | Keystone auth for Swift API |
| `osh_rgw_enabled` | `openstack_helm.yml` | Helm chart toggle |

---

## Environment Matrix — Feature Enablement

| Environment | Manila | RGW | Rationale |
|-------------|--------|-----|-----------|
| dev | ❌ | ❌ | Resource-constrained KVM (CephFS/RGW disabled) |
| r620-kvm | ❌ | ❌ | Tight memory (128GB host) |
| r810-kvm | ❌ | ❌ | 256GB host, RBD-only workloads |
| test | ✅ | ✅ | Production-like for integration testing |
| prod | ✅ | ✅ | Full feature set |
| dr | ✅ | ✅ | Mirror of production for failover |
| real-hardware | ✅ | ✅ | Full feature set on bare metal |
