# 12b — Deploy MetalLB Load Balancer

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_metallb.yml` |
| Role | `roles/metallb/` |
| Runs on | `kube_controllers[0]` |
| Profile | KVM + Real Hardware |
| Prerequisites | Kubernetes (Kubespray), Helm |
| Execution Order | **#12b** — Immediately after Kubespray, before Ceph (#13), Monitoring, and OpenStack |

---

## Purpose

MetalLB provides **LoadBalancer-type Service IPs** for bare-metal Kubernetes clusters. Without it, `type: LoadBalancer` services remain in "Pending" state indefinitely.

> **Why it matters:** Every downstream service (Grafana, Prometheus, OpenStack Horizon, Kong, ArgoCD) benefits from a stable external IP rather than NodePort workarounds.

---

## Modes

### L2 Mode (KVM Lab)

- Speaker responds to ARP requests for service IPs
- Zero switch config needed
- Single-node failover (~10s)
- Pool: `172.16.2.200-172.16.2.220`

### BGP Mode (Real Hardware)

- Speaker peers with SONiC leaf switches via eBGP
- True ECMP load distribution across nodes
- Sub-second failover
- MetalLB ASN: `65100`, Leaf ASN: `65000`

---

## Preflight Download

```bash
# Cache MetalLB Helm chart to /opt/fabric-cache/helm-charts/
ansible-playbook playbooks/reused/preflight_download.yml \
  -i inventory/hosts.yml --tags metallb -v
```

---

## Deployment Commands

```bash
# L2 mode (KVM lab default)
ansible-playbook playbooks/reused/deploy_metallb.yml \
  -i inventory/hosts.yml -v

# BGP mode (real hardware)
ansible-playbook playbooks/reused/deploy_metallb.yml \
  -i inventory/hosts.yml -e metallb_mode=bgp -v

# Custom IP pool
ansible-playbook playbooks/reused/deploy_metallb.yml \
  -i inventory/hosts.yml \
  -e 'metallb_ip_pool_range=10.10.100.1-10.10.100.50' -v

# Validate only
ansible-playbook playbooks/reused/deploy_metallb.yml \
  -i inventory/hosts.yml --tags metallb_validate -v

# Teardown
ansible-playbook playbooks/reused/deploy_metallb.yml \
  -i inventory/hosts.yml --tags metallb_teardown -e metallb_teardown=true -v
```

---

## Tags

| Tag | Description |
|-----|-------------|
| `metallb` | Full deployment (all phases) |
| `metallb_preflight` | Pre-checks (kubectl, helm, IP conflicts) |
| `metallb_deploy` | Helm install/upgrade |
| `metallb_configure` | Apply IPAddressPool + advertisement CRs |
| `metallb_validate` | End-to-end test with nginx service |
| `metallb_teardown` | Complete removal |

---

## Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `metallb_mode` | `l2` | `l2` or `bgp` |
| `metallb_namespace` | `metallb-system` | K8s namespace |
| `metallb_chart_version` | `0.14.8` | Helm chart version |
| `metallb_ip_pool_range` | `172.16.2.200-172.16.2.220` | IP range |
| `metallb_bgp_peer_asn` | `65000` | Leaf switch ASN |
| `metallb_bgp_my_asn` | `65100` | MetalLB ASN |
| `metallb_bgp_peer_addresses` | `[10.0.1.1, 10.0.1.2]` | Leaf loopbacks |

---

## OpenStack Integration

MetalLB and OpenStack Neutron are **complementary**:

| Concern | MetalLB | Neutron Floating IPs |
|---------|---------|---------------------|
| Purpose | Expose K8s services | Expose tenant VMs |
| Layer | K8s Service (L4) | OpenStack networking (L3) |
| IP Pool | `.200-.220` | `.100-.150` (example) |
| Consumers | Keystone, Horizon, Grafana | Tenant instances |

> **Critical:** MetalLB and Neutron IP pools MUST NOT overlap.

### OpenStack-Helm services using MetalLB IPs

| Service | Port | Example IP |
|---------|------|-----------|
| Keystone | 5000 | 172.16.2.200 |
| Horizon | 443 | 172.16.2.201 |
| Glance | 9292 | 172.16.2.202 |
| Nova | 8774 | 172.16.2.203 |
| Neutron | 9696 | 172.16.2.204 |
| Cinder | 8776 | 172.16.2.205 |

### BGP Mode + SONiC Integration

In production, MetalLB speakers peer with leaf switches:

```
router bgp 65000
  neighbor METALLB peer-group
  neighbor METALLB remote-as 65100
  neighbor 10.10.255.40 peer-group METALLB
  neighbor 10.10.255.41 peer-group METALLB
  !
  address-family ipv4 unicast
    neighbor METALLB activate
  exit-address-family
```

Leaf installs ECMP routes for service IPs → true anycast load balancing.

---

## MetalLB vs Octavia vs HAProxy/Keepalived

These three solve load balancing at different layers. They are not interchangeable.

### Comparison Matrix

| Dimension | MetalLB | OpenStack Octavia | HAProxy/Keepalived |
|-----------|---------|-------------------|--------------------|
| **What** | K8s bare-metal LB provider | OpenStack LBaaS v2 | Traditional HA stack |
| **Layer** | L4 (IP assignment only) | L4 + L7 (SSL, health checks) | L4 + L7 (full proxy) |
| **Scope** | K8s Services | OpenStack tenant VMs | Any TCP/HTTP endpoint |
| **Deployment** | DaemonSet + Deployment | Amphora VMs (HAProxy in Nova) | Standalone VMs/containers |
| **Dependencies** | Kubernetes only | Full OpenStack stack | Linux + systemd |
| **IP method** | ARP (L2) or BGP (/32 routes) | Neutron floating IP | VRRP (gratuitous ARP) |
| **HA** | L2: ~10s, BGP: sub-second | Active/Standby amphora | VRRP ~3s failover |
| **Load distribution** | BGP: ECMP; L2: single node | Round-robin, least-conn, etc. | Round-robin, leastconn, etc. |
| **SSL termination** | No (pass-through) | Yes (Barbican certs) | Yes (native) |
| **Multi-tenancy** | No (cluster-wide) | Yes (per-project quotas) | No |
| **Resource cost** | ~50MB RAM | ~1GB RAM per amphora | ~200MB RAM |
| **Complexity** | Low (Helm + 2 CRDs) | High (full OpenStack needed) | Medium |

### When to Use Each

| Scenario | Use | Why |
|----------|-----|-----|
| Expose Grafana/Prometheus | **MetalLB** | K8s Service → instant LB IP |
| Expose Keystone/Horizon APIs | **MetalLB** | OpenStack-Helm runs as K8s Services |
| Tenant creates LB for app VMs | **Octavia** | Self-service, quota-managed |
| K8s API server HA | **HAProxy/Keepalived** | Must exist before K8s is up |
| Database VIP failover | **HAProxy/Keepalived** | Custom health scripts |
| L7 routing (path, headers) | **Octavia** or **Ingress+MetalLB** | Octavia for VMs; Ingress for pods |
| BGP-announced anycast in CLOS | **MetalLB (BGP)** | Native SONiC integration |

### In Our Architecture — All Three Coexist

```
┌──────────────────────────────────────────────────┐
│  HAProxy/Keepalived  (FIRST)                     │
│  VIP: 172.16.2.100 → K8s API (6443)             │
│  Exists BEFORE K8s is operational                │
├──────────────────────────────────────────────────┤
│  MetalLB  (SECOND - after K8s up)                │
│  Pool: 172.16.2.200-220                          │
│  → Grafana, Prometheus, Kong, Horizon            │
├──────────────────────────────────────────────────┤
│  Octavia  (THIRD - inside OpenStack)             │
│  Tenant-facing LBaaS                             │
│  → Tenant apps, multi-tier services              │
└──────────────────────────────────────────────────┘
```

> **Key insight:** MetalLB does NOT replace Octavia. Octavia provides tenant-managed LBs as a cloud service. MetalLB provides the platform-level LB that exposes K8s workloads (including OpenStack's control plane). HAProxy/Keepalived bootstraps HA before either can exist.

### Decision Flowchart

```
Is it a K8s Service?
  ├─ YES → MetalLB (type: LoadBalancer)
  │         Need L7? → Add NGINX Ingress
  └─ NO → OpenStack tenant workload?
           ├─ YES → Octavia (LBaaS v2)
           └─ NO → HAProxy/Keepalived (control-plane / general HA)
```

---

## Validation

| # | Check | Command | Expected |
|---|-------|---------|----------|
| 1 | Pods | `kubectl get pods -n metallb-system` | Running |
| 2 | CRDs | `kubectl get crd \| grep metallb` | 6 CRDs |
| 3 | Pool | `kubectl get ipaddresspool -n metallb-system` | service-pool |
| 4 | LB IP | `kubectl get svc -A -o wide \| grep LoadBalancer` | IP assigned |
| 5 | HTTP | `curl http://<assigned-ip>` | 200 OK |

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| Service stuck Pending | No pool / pool exhausted | Expand `metallb_ip_pool_range` |
| IP not reachable | strictARP disabled (L2) | Re-run with `metallb_preflight` tag |
| Intermittent | L2 single-node failover | Switch to BGP mode |
| OpenStack conflict | Pool overlap | Separate IP ranges |
