# 07 — Deploy Leaf-Server BGP

## Overview

Configures leaf switch downlinks with eBGP unnumbered sessions to multi-homed compute servers. Enables server reachability via the L3 fabric and advertises server loopbacks.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_leaf_server_bgp.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#7** — After Day 1 fabric wiring |
| Prerequisites | Day 1 complete; leaf-to-spine BGP established |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Configures virtual leaf ports facing server VMs. Each server is dual-homed to a leaf pair for redundancy.

```bash
ansible-playbook playbooks/reused/deploy_leaf_server_bgp.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Configures physical downlink ports. Verify optics and speed settings match the server NIC capabilities.

```bash
ansible-playbook playbooks/reused/deploy_leaf_server_bgp.yml \
  -i inventory/hosts.yml -v

# Verify peer state:
ansible-playbook playbooks/reused/deploy_leaf_server_bgp.yml \
  -i inventory/hosts.yml --tags verify -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `verify` | Leaves + Servers | Validate BGP peer state |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `server_loopback_network` | `10.10.255.0/24` | Server loopback range announced via BGP |
| `leaf_downlink_mtu` | `9000` | MTU on server-facing ports |
