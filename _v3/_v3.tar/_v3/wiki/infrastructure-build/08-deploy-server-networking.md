# 08 — Deploy Server Networking

## Overview

Configures Ubuntu server networking: FRR daemon for BGP, loopback addresses, netplan YAML for dual-homed uplinks, and routing policy for ECMP load balancing across leaf pairs.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_server_networking.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#8** — After leaf-server BGP is configured on switch side |
| Prerequisites | Leaf downlinks configured; server NICs physically connected |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Configures virtual NIC bonds and FRR on each server VM. Server loopbacks (/32) are announced via eBGP unnumbered to both attached leaves.

```bash
ansible-playbook playbooks/reused/deploy_server_networking.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same flow. Ensure Mellanox/Intel NIC firmware is updated. Server must have 2+ uplink ports for leaf redundancy.

```bash
ansible-playbook playbooks/reused/deploy_server_networking.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `netplan` | Servers | Generate and apply netplan config |
| `frr` | Servers | Install FRR and render daemons/bgpd.conf |
| `loopback` | Servers | Configure loopback /32 addresses |
| `verify` | Servers | Ping tests and BGP peer validation |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `server_frr_version` | `9.1` | FRR version to install |
| `server_uplink_interfaces` | (from inventory) | NIC names for leaf uplinks |
| `server_loopback_ip` | (per-host) | Unique /32 loopback address |
| `ecmp_max_paths` | `2` | ECMP paths for multi-homed routing |
