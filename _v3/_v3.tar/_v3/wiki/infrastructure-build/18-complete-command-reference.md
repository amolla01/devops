# 18 — Complete Command Reference

## Overview

Exhaustive reference of all _v3 deployment commands, Ansible playbooks, tags, and operational parameters. Serves as the single source of truth for every executable action in the platform lifecycle.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/09-complete-command-reference.html` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Type | Reference Document |

---

## Playbook Command Matrix

| Playbook | Key Tags | Profile | Destructive |
|----------|----------|---------|-------------|
| `preflight_download.yml` | kubespray, ceph, openstack, helm_charts | Both | No |
| `build_packer_images.yml` | packer_build, packer_upload | HW | No |
| `deploy_day0.yml` | render, validate, push, reload, verify | Both | No |
| `set_interface_properties.yml` | fabric, uplink, downlink, exit | Both | No |
| `deploy_day1.yml` | preflight, deploy, bgp, frr, verify | Both | No |
| `deploy_leaf_server_bgp.yml` | verify | Both | No |
| `deploy_server_networking.yml` | netplan, frr, loopback, verify | Both | No |
| `deploy_sonic_evpn.yml` | deploy, verify | Both | No |
| `deploy_evpn_overlay.yml` | vxlan, ovs, vrf, l2vni, l3vni, verify | Both | No |
| `deploy_bgp_agent.yml` | install, configure, verify | Both | No |
| `deploy_kubespray.yml` | preflight, kubespray, addons, kubeconfig, verify | Both | No |
| `deploy_ceph_rook.yml` | wipe, operator, cluster, dashboard, toolbox, pool, teardown | Both | **Yes (wipe)** |
| `deploy_postgresql.yml` | deploy, databases, verify, backup | Both | No |
| `deploy_openstack_helm.yml` | infra, keystone, glance, nova, neutron, cinder, horizon, heat | Both | No |
| `deploy_monitoring.yml` | prometheus, grafana, alertmanager, exporters, dashboards | Both | No |
| `deploy_sheba_cloud_infra.yml` | ceph_pool, ceph_keyring, namespaces, quotas | Both | No |
| `deploy_sheba_infra_services.yml` | gitea, harbor, openbao, redis, minio | Both | No |
| `deploy_sheba_sdlc_services.yml` | plane, tekton, argocd, sonarqube, bookstack, mattermost | Both | No |
| `teardown.yml` | full_destroy, vms_only, fabric_only, k8s_only | Both | **Yes** |
| `extend_topology.yml` | preflight, day0, interfaces, bgp, evpn, verify | Both | No |
| `audit_topology_interfaces.yml` | interfaces, bgp, bfd, lldp, vxlan, report | Both | No |

---

## Common Ansible Flags

| Flag | Purpose | Example |
|------|---------|---------|
| `-i inventory/hosts.yml` | Specify inventory | Required for all playbooks |
| `--tags <tag>` | Run specific tasks only | `--tags deploy,verify` |
| `--skip-tags <tag>` | Skip specific tasks | `--skip-tags wipe` |
| `--limit <host>` | Target specific hosts | `--limit workers` |
| `--check` | Dry-run mode | Validate without changes |
| `-v / -vv / -vvv` | Verbosity level | `-vv` for troubleshooting |
| `--diff` | Show file diffs | See config changes before apply |

---

## Laptop Controller Quick-Start

> Run all commands from WSL on Lab-ControlNode. SSH config must be set for profile-driven connectivity.

```bash
# Set working directory
cd /mnt/c/Users/nh1221/data-center/_v3/

# Activate venv
source .venv/bin/activate

# Verify connectivity
ansible all -i inventory/hosts.yml -m ping

# Run any playbook
ansible-playbook playbooks/reused/<playbook>.yml -i inventory/hosts.yml -v
```
