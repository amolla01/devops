# 20 — Multi-Homing Strategy

## Overview

Design document for server multi-homing in the _v3 data-center fabric. Describes dual-attached server connectivity to leaf switches using LACP bonding, ECMP via unnumbered BGP, and EVPN multi-homing (ESI-based) for active-active forwarding.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/10-multi-homing-strategy.html` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Type | Architecture Design Document |

---

## Multi-Homing Models

| Model | Mechanism | Use Case | Failover |
|-------|-----------|----------|----------|
| Active-Standby Bond | LACP mode 1 (active-backup) | Legacy servers | ~3s |
| Active-Active Bond | LACP mode 4 (802.3ad) + MLAG | High-throughput servers | Sub-second |
| EVPN Multi-Homing | ESI (Ethernet Segment Identifier) | Modern fabric servers | Sub-second, standards-based |
| BGP ECMP | Unnumbered BGP with multiple uplinks | Kubernetes worker nodes | Immediate (per-flow) |

---

## EVPN Multi-Homing (ESI) Design

### ESI Assignment

```
# Leaf1 configuration (SONiC)
interface Ethernet48
  evpn ethernet-segment
    esi 00:11:22:33:44:55:66:77:88:01
    df-election-timer 3

# Leaf2 configuration (same ESI = same segment)
interface Ethernet48
  evpn ethernet-segment
    esi 00:11:22:33:44:55:66:77:88:01
    df-election-timer 3
```

### Server Bond Configuration

```yaml
# /etc/netplan/01-bond.yaml on server
network:
  version: 2
  bonds:
    bond0:
      interfaces: [ens3f0, ens3f1]
      parameters:
        mode: 802.3ad
        lacp-rate: fast
        transmit-hash-policy: layer3+4
      addresses:
        - 10.20.1.10/24
```

---

## BGP ECMP for Kubernetes Workers

> Preferred model for K8s workers: each server runs FRR, peers with both ToR leafs, advertises its loopback and pod CIDR.

```
router bgp 65100
  bgp router-id 10.255.0.10
  neighbor Ethernet0 interface remote-as external
  neighbor Ethernet1 interface remote-as external
  address-family ipv4 unicast
    network 10.255.0.10/32
    network 10.244.1.0/24
    maximum-paths 2
```

---

## Execution Note

### KVM Profile
Multi-homing in KVM uses virtio multi-queue NIC pairs attached to different OVS bridges simulating dual ToR connectivity. Configured in `deploy_server_networking.yml` (playbook #08).

### Real Hardware Profile
Physical dual-NIC servers connected to two leaf switches. LACP or EVPN-MH depending on switch capabilities. Configured during Day 1 fabric wiring (playbook #06) and server networking (playbook #08).
