# 21 — Gap Analysis: v2 vs v3

## Overview

Comprehensive comparison between the _v2 and _v3 platform generations, identifying gaps, improvements, and migration paths. Documents what was manually configured in v2 that is now automated in v3, and highlights remaining gaps to address.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/05-gap-analysis-v2-vs-v3.html` |
| Category | Infrastructure Build |
| Type | Analysis / Comparison Document |

---

## Platform Comparison Matrix

| Capability | v2 Approach | v3 Approach | Status |
|-----------|-------------|-------------|--------|
| Network Fabric | Manual SONiC CLI config | Ansible-driven Day 0/Day 1 automation | Improved |
| Server Provisioning | Manual Ubuntu install | MaaS + Packer images | Improved |
| Kubernetes | kubeadm manual | Kubespray automated | Improved |
| Storage | Local-path only | Rook-Ceph distributed | Improved |
| EVPN/VXLAN | Static VTEPs | BGP EVPN + ESI multi-homing | Improved |
| Monitoring | Ad-hoc Prometheus | Full stack (Prometheus + Grafana + Alertmanager) | Improved |
| Multi-Tenancy | Not supported | VRF + namespace + pool isolation | New |
| CI/CD | Manual deploys | Tekton + ArgoCD GitOps | New |
| Secret Management | Plain text in repo | OpenBao (Vault-compatible) | New |
| DR / Backup | Manual snapshots | Velero + Ceph mirroring (planned) | Partial |
| Load Balancing | NodePort only | MetalLB + Ingress NGINX | Improved |

---

## Remaining Gaps (v3 Roadmap)

| Gap | Priority | Target |
|-----|----------|--------|
| Full DR automation (cross-site replication) | High | Q3 2025 |
| Automated certificate rotation (cert-manager) | Medium | Q2 2025 |
| Service mesh (Istio/Cilium) | Low | Q4 2025 |
| GPU workload scheduling | Low | Future |
| Federation across multiple clusters | Medium | Q3 2025 |

---

## Migration Path: v2 → v3

> **Warning:** v2 environments cannot be upgraded in-place. Recommended approach: fresh v3 deploy + data migration.

### Migration Steps

1. Export application data from v2 (database dumps, PVs)
2. Deploy fresh v3 platform (playbooks 01–16)
3. Import data into v3 PostgreSQL / Ceph storage
4. Validate application functionality
5. Update DNS / external routing to point to v3
6. Decommission v2 environment
