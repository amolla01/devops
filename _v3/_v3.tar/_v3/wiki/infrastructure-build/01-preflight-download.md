# 01 — Preflight Download (Offline Cache)

## Overview

Pre-stages all container images, binaries, Helm charts, apt packages, and pip wheels into a local cache directory. This enables fully offline deployment of the entire platform stack without internet access on target nodes.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/preflight_download.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#1** — First playbook to run (requires internet) |
| Prerequisites | Internet connectivity on deployer node; target inventory defined |
| Idempotent | Yes — skips already-cached artifacts |

---

## Execution Note

### KVM Profile
Run from Lab-ControlNode (WSL) BEFORE any other playbook. This is Step 0 — prepares the offline cache so all subsequent deploys can use local artifacts.

```bash
ansible-playbook playbooks/reused/preflight_download.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Run from the deployment jumpbox that has internet access. Cache is stored at `/opt/fabric-cache/` and will be rsynced to target nodes during subsequent playbooks.

```bash
ansible-playbook playbooks/reused/preflight_download.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `kubespray` | K8s images + binaries | Kubespray offline images, kubectl, kubeadm |
| `k8s` | K8s core | Core Kubernetes component downloads |
| `ceph` | Ceph artifacts | cephadm binary, Rook Helm charts, Ceph container images |
| `openstack` | OpenStack | OSH charts, container images |
| `maas` | MaaS | MaaS Helm chart, PostgreSQL chart |
| `prometheus` | Monitoring | Prometheus, Grafana, Alertmanager charts + images |
| `helm_charts` | All Helm | All Helm chart tarballs |
| `apt_cache` | Apt packages | Offline apt package cache for Ubuntu nodes |
| `pip_cache` | Python | pip wheel cache for offline installs |
| `packer` | Packer | Packer binary + plugins for image building |

---

## Cache Structure

```
/opt/fabric-cache/
├── binaries/           # cephadm, kubectl, helm, packer
├── helm-charts/        # *.tgz chart archives
├── images/             # Container image tarballs (docker save)
├── apt-packages/       # .deb package cache
├── pip-wheels/         # Python wheel cache
└── kubespray/          # Kubespray offline artifact bundle
```

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ceph_preflight_cache_dir` | `/opt/fabric-cache` | Root cache directory |
| `preflight_internet_required` | `true` | Fail if no internet when true |
| `preflight_rsync_to_nodes` | `false` | Push cache to all nodes after download |
