# 06 — Deploy Day 1 (Fabric Wiring & BGP)

## Overview

Day-1 fabric wiring for eBGP unnumbered sessions across SONiC switches, MikroTik exit routers, and Ubuntu servers. Establishes the L3 CLOS underlay with IPv6 link-local peering and BFD.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_day1.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#6** — After interface properties are set |
| Prerequisites | Day 0 + interface properties complete; all links UP |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Configures BGP unnumbered on all virtual fabric links. FRR is used on Ubuntu servers for host-to-leaf peering.

```bash
ansible-playbook playbooks/reused/deploy_day1.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same as KVM. Physical links must be UP with correct speed/FEC before BGP will establish.

```bash
ansible-playbook playbooks/reused/deploy_day1.yml \
  -i inventory/hosts.yml -v

# Verify only:
ansible-playbook playbooks/reused/deploy_day1.yml \
  -i inventory/hosts.yml --tags verify -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `preflight` | All | Validate link status before BGP config |
| `deploy` | All | Push BGP configurations |
| `interfaces` | Switches | Configure interface addressing |
| `bgp` | All | Configure BGP sessions |
| `frr` | Servers | Install/configure FRR on Ubuntu hosts |
| `netplan` | Servers | Configure server netplan YAML |
| `verify` | All | Check BGP established state |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `bgp_unnumbered` | `true` | Use IPv6 link-local (no IP assignment) |
| `bfd_enabled` | `true` | Enable BFD for fast failure detection |
| `bfd_interval` | `300` | BFD interval (ms) |
| `spine_asn_base` | `65000` | Base ASN for spines |
| `leaf_asn_base` | `65100` | Base ASN for leaves |
