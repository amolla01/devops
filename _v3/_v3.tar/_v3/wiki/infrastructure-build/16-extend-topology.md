# 16 — Extend Topology (Non-disruptive Expansion)

## Overview

Non-disruptive fabric expansion playbook. Adds new spine/leaf/server nodes to an existing fabric without disrupting live traffic. Handles inventory update, configuration rendering, BGP session establishment, and EVPN extension.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/extend_topology.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#16** — Anytime after initial fabric is operational |
| Prerequisites | Existing fabric converged; new hardware cabled and SONiC installed |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Use to add new VMs to the lab (e.g., additional workers or a second leaf pair). Update inventory first, then run with `--limit` targeting new nodes.

```bash
# Add new nodes to inventory, then:
ansible-playbook playbooks/reused/extend_topology.yml \
  -i inventory/hosts.yml --limit new_leaf3,new_worker4 -v
```

### Real Hardware Profile
Use for production expansion (new rack, new pod). The playbook ensures existing BGP sessions are not disrupted while new peerings are established.

```bash
ansible-playbook playbooks/reused/extend_topology.yml \
  -i inventory/hosts.yml --limit new_nodes -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `preflight` | New nodes | Validate hardware and connectivity |
| `day0` | New nodes | Base provisioning for new devices |
| `interfaces` | New + adjacent | Configure new links |
| `bgp` | New + adjacent | Establish BGP sessions |
| `evpn` | New nodes | Enable EVPN address-family |
| `verify` | All | Full fabric convergence validation |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `extend_drain_first` | `false` | Drain traffic before changes (maintenance mode) |
| `extend_verify_full_mesh` | `true` | Validate all-to-all reachability after extension |
