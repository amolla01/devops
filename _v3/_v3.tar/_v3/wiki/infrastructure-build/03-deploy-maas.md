# 03 — Deploy MaaS (Metal as a Service)

## Overview

Deploys MaaS Region + Rack Controller via Helm on Kubernetes with PostgreSQL backend. Provides bare-metal server lifecycle management: commission, deploy OS images, and IPMI/BMC power control.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_maas.yml` |
| Category | Infrastructure Build |
| Profiles | Real Hardware (required), KVM (optional/skip) |
| Execution Order | **#3** — After Packer images; before bare-metal commissioning |
| Prerequisites | Kubernetes running; PostgreSQL deployed; Packer images uploaded |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
**Skip** — KVM VMs are created directly via libvirt/virsh on the hypervisor. MaaS is not needed for virtual lab.

### Real Hardware Profile
Required. Deploy after Kubernetes is running (even a minimal single-node cluster). MaaS will commission all bare-metal servers.

```bash
# Deploy PostgreSQL backend first
ansible-playbook playbooks/reused/deploy_postgresql.yml \
  -i inventory/hosts.yml -v

# Then deploy MaaS
ansible-playbook playbooks/reused/deploy_maas.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `prereqs` | All | Install prerequisites and validate environment |
| `deploy` | K8s controller | Deploy MaaS Helm chart |
| `configure` | MaaS controller | Configure subnets, DNS, DHCP, images |
| `verify` | MaaS controller | Validate MaaS API and rack controller health |
| `teardown` | K8s controller | Remove MaaS (destructive) |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `maas_namespace` | `maas` | Kubernetes namespace |
| `maas_admin_user` | `admin` | MaaS admin username |
| `maas_postgres_host` | (from PostgreSQL deploy) | Database connection |
| `maas_region_count` | `1` | Number of region controllers |
