# 11 — Deploy BGP Agent (OVN BGP Agent)

## Overview

Deploys OVN BGP Agent on hypervisors to advertise OpenStack/OVN port MAC/IP addresses as EVPN Type 2 routes. Enables bare-metal-like connectivity for VMs through the fabric without overlay encap on the switch side.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_bgp_agent.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#11** — After EVPN overlay is configured |
| Prerequisites | EVPN overlay operational; OVN/OVS running on hypervisors |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Installs `ovn-bgp-agent` on compute VMs and configures it to peer with the connected leaf switch via eBGP. Advertises VM MAC/IP as Type 2 routes.

```bash
ansible-playbook playbooks/reused/deploy_bgp_agent.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same as KVM. Ensure OVN Southbound DB is reachable from all compute nodes.

```bash
ansible-playbook playbooks/reused/deploy_bgp_agent.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `install` | Hypervisors | Install OVN BGP Agent package |
| `configure` | Hypervisors | Render agent config and systemd unit |
| `verify` | Hypervisors | Validate Type 2 route advertisement |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `bgp_agent_driver` | `ovn_evpn_driver` | Agent driver (EVPN Type 2/5) |
| `bgp_agent_ovn_sb_connection` | `tcp:172.16.2.40:6642` | OVN Southbound connection |
| `bgp_agent_expose_tenant_networks` | `true` | Advertise tenant network IPs |
