# 02 — Build Packer Images

## Overview

Builds customized Ubuntu 24.04 qcow2 images with pre-installed FRR, OpenStack packages, OVS, and security hardening for MaaS PXE deployment or KVM direct use.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/build_packer_images.yml` |
| Category | Infrastructure Build |
| Profiles | Real Hardware (primary), KVM (optional) |
| Execution Order | **#2** — After preflight; before MaaS commissioning |
| Prerequisites | Packer binary in cache; base ISO available |
| Idempotent | Yes — rebuilds only if template changed |

---

## Execution Note

### KVM Profile
Not strictly required for KVM lab (VMs are pre-built with cloud-init). Run only if custom image features are needed.

```bash
ansible-playbook playbooks/reused/build_packer_images.yml \
  -i inventory/hosts.yml --tags packer_build -v
```

### Real Hardware Profile
Run early — MaaS needs these images to commission bare-metal servers. Upload to MaaS image library after build.

```bash
ansible-playbook playbooks/reused/build_packer_images.yml \
  -i inventory/hosts.yml -v

# Upload to MaaS:
ansible-playbook playbooks/reused/build_packer_images.yml \
  -i inventory/hosts.yml --tags packer_upload -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `packer_build` | Deployer | Build qcow2 images via Packer |
| `packer_upload` | Deployer → MaaS | Upload images to MaaS image store |
| `packer_validate` | Deployer | Validate Packer templates without building |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `packer_base_iso` | `ubuntu-24.04-server-cloudimg-amd64.img` | Base cloud image |
| `packer_output_dir` | `/opt/fabric-cache/images/` | Output directory for built images |
| `packer_frr_version` | `9.1` | FRR version to bake into image |
