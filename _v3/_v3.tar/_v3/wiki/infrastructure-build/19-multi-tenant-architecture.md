# 19 — Multi-Tenant Architecture

## Overview

Architecture design for multi-tenant isolation in the _v3 platform. Covers network segmentation via EVPN/VXLAN VRFs, Kubernetes namespace isolation, Ceph pool-per-tenant storage, and OpenStack project boundaries.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/09-multi-tenant-architecture.html` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Type | Architecture Design Document |

---

## Isolation Layers

| Layer | Mechanism | Tenant Boundary |
|-------|-----------|-----------------|
| Network (L2/L3) | EVPN Type-5 VRFs, per-tenant VNI range | VRF instance per tenant |
| Compute | Kubernetes namespaces + NetworkPolicy | Namespace per tenant |
| Storage | Ceph RBD pool per tenant, CRUSH rules | Pool-level isolation |
| Identity | OpenStack Keystone projects | Project/domain per tenant |
| Ingress | SNI-based TLS + per-namespace Ingress classes | DNS zone per tenant |

---

## Network Segmentation Design

### VNI Allocation Scheme

| Range | Purpose | Example |
|-------|---------|---------|
| 10000–19999 | Infrastructure VRFs | VNI 10001 = mgmt, VNI 10002 = storage |
| 20000–29999 | Tenant A workloads | VNI 20001 = web, VNI 20002 = db |
| 30000–39999 | Tenant B workloads | VNI 30001 = web, VNI 30002 = db |
| 40000–49999 | Shared services | VNI 40001 = DNS, VNI 40002 = monitoring |

### Inter-Tenant Routing

> **Warning:** Inter-tenant traffic is **denied by default**. Explicit route-leak policies must be configured for any cross-tenant communication.

```
vrf Tenant-A
  address-family ipv4 unicast
    import route-target 65000:40001
  exit-address-family
```

---

## Kubernetes Multi-Tenancy

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: tenant-a
  labels:
    tenant: a
    isolation: strict
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: deny-all-ingress
  namespace: tenant-a
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

---

## Storage Isolation

```bash
ceph osd pool create tenant-a-rbd 64 64
ceph osd pool application enable tenant-a-rbd rbd
ceph auth get-or-create client.tenant-a \
  mon 'allow r' \
  osd 'allow rwx pool=tenant-a-rbd' \
  -o /etc/ceph/ceph.client.tenant-a.keyring
```

---

## Execution Note

### KVM Profile
Multi-tenant architecture is configured during EVPN overlay (playbook #10) and Kubernetes deployment (playbook #12). Tenant provisioning is a Day 2 operation post-platform.

### Real Hardware Profile
Same architecture with physical ToR switch VRF support. Requires EVPN-capable leaf switches (SONiC 4.1+ with FRR 8.5+).
