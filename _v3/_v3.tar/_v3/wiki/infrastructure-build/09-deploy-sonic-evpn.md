# 09 — Deploy SONiC EVPN (Address-Family)

## Overview

Enables EVPN address-family on SONiC eBGP sessions. Activates L2VPN EVPN capability on all leaf and border switches so they can exchange VXLAN tunnel endpoints and MAC/IP routes.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_sonic_evpn.yml` |
| Category | Infrastructure Build |
| Profiles | KVM + Real Hardware |
| Execution Order | **#9** — After full underlay is converged |
| Prerequisites | Day 1 BGP established on all spine↔leaf links |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Enables `l2vpn evpn` address-family on BGP sessions between SONiC KVM switches. Confirms Type-3 IMET routes are exchanged.

```bash
ansible-playbook playbooks/reused/deploy_sonic_evpn.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same as KVM. Validate that ASIC supports VXLAN encap/decap for the target platform (Memory/hardware tables).

```bash
ansible-playbook playbooks/reused/deploy_sonic_evpn.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `deploy` | Switches | Push EVPN address-family config |
| `verify` | Switches | Validate EVPN route exchange |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `evpn_vtep_source` | `Loopback0` | VTEP source interface |
| `evpn_advertise_all_vni` | `true` | Advertise all VNIs to EVPN peers |
