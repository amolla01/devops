# 05 — Sheba Infrastructure Software Setup

## Overview

Deployment of infrastructure-level software that supports business applications: load balancers, certificate management, DNS, log aggregation, and backup solutions.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/sheba-infra-software-setup.html` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#05** — After common software (04) |

---

## Infrastructure Software Components

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Ingress Controller | NGINX Ingress Controller | HTTP/HTTPS routing + TLS termination |
| Load Balancer | MetalLB (BGP mode) | Bare-metal LoadBalancer IPs via L3 CLOS fabric |
| Certificate Manager | cert-manager + self-signed CA | Automated TLS certificate lifecycle |
| DNS | CoreDNS + external-dns (optional) | Internal service discovery |
| Log Aggregation | Fluent Bit → OpenSearch | Centralized log collection |
| Backup | Velero + Ceph S3 | Cluster resource + PV backup |

---

## Deployment

### MetalLB

> **Both KVM and real hardware profiles use BGP mode.** All host servers peer with SONiC leaf switches via eBGP. MetalLB announces service IPs as /32 routes into the L3 CLOS fabric.

```bash
# Deployed via Ansible role (step #12b)
ansible-playbook playbooks/reused/deploy_metallb.yml -i inventory/hosts.yml -v
```

```yaml
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  name: default-pool
  namespace: metallb-system
spec:
  addresses:
  - 172.16.2.200-172.16.2.220
---
apiVersion: metallb.io/v1beta2
kind: BGPPeer
metadata:
  name: leaf-peer
  namespace: metallb-system
spec:
  myASN: 65100
  peerASN: 65000
  peerAddress: 10.0.1.1
---
apiVersion: metallb.io/v1beta1
kind: BGPAdvertisement
metadata:
  name: service-advertisement
  namespace: metallb-system
spec:
  ipAddressPools:
  - default-pool
```

### cert-manager

```bash
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager --create-namespace \
  --set installCRDs=true
```

### Fluent Bit

```bash
helm install fluent-bit fluent/fluent-bit \
  --namespace logging --create-namespace \
  --set output.type=opensearch \
  --set output.host=sheba-search-opensearch.sheba-shared.svc
```

### Velero (Backup)

```bash
velero install \
  --provider aws \
  --plugins velero/velero-plugin-for-aws:v1.8.0 \
  --bucket velero-backups \
  --backup-location-config region=default,s3ForcePathStyle=true,s3Url=http://minio.sheba-shared.svc:9000
```

---

## Execution Note

### KVM Profile
MetalLB uses BGP mode with 172.16.2.200–220 range (announced as /32 routes to leaf switches). cert-manager uses self-signed CA only. Velero optional.

### Real Hardware Profile
MetalLB uses BGP mode with production IP range. cert-manager integrated with external CA. Velero with dedicated S3 backend.
