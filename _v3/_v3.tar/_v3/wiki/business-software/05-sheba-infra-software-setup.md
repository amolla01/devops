# 05 — Sheba Infrastructure Software Setup

## Overview

Deployment of infrastructure-level software that supports business applications: load balancers, certificate management, DNS, log aggregation, and backup solutions.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/sheba-infra-software-setup.html` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#05** — After common software (04) |

---

## Infrastructure Software Components

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Ingress Controller | NGINX Ingress Controller | HTTP/HTTPS routing + TLS termination |
| Load Balancer | MetalLB (L2 mode) | Bare-metal LoadBalancer IPs |
| Certificate Manager | cert-manager + self-signed CA | Automated TLS certificate lifecycle |
| DNS | CoreDNS + external-dns (optional) | Internal service discovery |
| Log Aggregation | Fluent Bit → OpenSearch | Centralized log collection |
| Backup | Velero + Ceph S3 | Cluster resource + PV backup |

---

## Deployment

### MetalLB

```bash
helm install metallb metallb/metallb --namespace metallb-system --create-namespace
```

```yaml
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  name: default-pool
  namespace: metallb-system
spec:
  addresses:
  - 172.16.2.200-172.16.2.220
```

### cert-manager

```bash
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager --create-namespace \
  --set installCRDs=true
```

### Fluent Bit

```bash
helm install fluent-bit fluent/fluent-bit \
  --namespace logging --create-namespace \
  --set output.type=opensearch \
  --set output.host=sheba-search-opensearch.sheba-shared.svc
```

### Velero (Backup)

```bash
velero install \
  --provider aws \
  --plugins velero/velero-plugin-for-aws:v1.8.0 \
  --bucket velero-backups \
  --backup-location-config region=default,s3ForcePathStyle=true,s3Url=http://minio.sheba-shared.svc:9000
```

---

## Execution Note

### KVM Profile
MetalLB uses 172.16.2.200–220 range. cert-manager uses self-signed CA only. Velero optional.

### Real Hardware Profile
MetalLB IP range from production allocation. cert-manager integrated with external CA. Velero with dedicated S3 backend.
