# 03 — Deploy Sheba SDLC Services

## Overview

Deploys the Software Development Lifecycle toolchain: Plane (project management), Tekton (CI pipelines), ArgoCD (GitOps CD), SonarQube (code quality), BookStack (documentation wiki), and Mattermost (team chat).

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_sheba_sdlc_services.yml` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#3 in business** — After infra services (Gitea, Harbor, etc.) are running |
| Prerequisites | sheba-sdlc namespace; Gitea running; Harbor running; PostgreSQL databases created |
| Idempotent | Yes (Helm upgrade) |

---

## Execution Note

### KVM Profile
Deploys full SDLC stack with lab-sized resources. Services connect to Gitea for source, Harbor for images, and PostgreSQL for state.

```bash
ansible-playbook playbooks/reused/deploy_sheba_sdlc_services.yml \
  -i inventory/hosts.yml -v

# Deploy specific service:
ansible-playbook playbooks/reused/deploy_sheba_sdlc_services.yml \
  -i inventory/hosts.yml --tags argocd -v
```

### Real Hardware Profile
Production deployment with SSO integration (via OpenBao/OIDC), HA replicas, and dedicated resource pools.

```bash
ansible-playbook playbooks/reused/deploy_sheba_sdlc_services.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `plane` | sheba-sdlc | Project management (Plane) |
| `tekton` | sheba-sdlc | CI pipelines (Tekton + Dashboard) |
| `argocd` | sheba-sdlc | GitOps CD (ArgoCD) |
| `sonarqube` | sheba-sdlc | Code quality analysis |
| `bookstack` | sheba-sdlc | Documentation wiki |
| `mattermost` | sheba-sdlc | Team messaging |
| `verify` | sheba-sdlc | Health checks for all services |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `argocd_domain` | `argocd.lab.local` | ArgoCD ingress hostname |
| `plane_domain` | `plane.lab.local` | Plane ingress hostname |
| `sonarqube_domain` | `sonar.lab.local` | SonarQube ingress hostname |
| `bookstack_domain` | `wiki.lab.local` | BookStack ingress hostname |
| `mattermost_domain` | `chat.lab.local` | Mattermost ingress hostname |
| `tekton_dashboard_service_type` | `LoadBalancer` | Tekton Dashboard exposure (MetalLB BGP assigns IP) |
| `argocd_git_repo` | (from Gitea) | GitOps repository URL |
