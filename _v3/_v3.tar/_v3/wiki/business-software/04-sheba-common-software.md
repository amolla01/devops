# 04 — Sheba Common Software Across Business Services

## Overview

Deployment of shared software components used by all NoyoBazar/Sheba business services: message queues, caching, search engines, API gateways, and shared libraries deployed as cluster-wide services.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/sheba-common-software-across-business-services-setup.html` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#04** — After SDLC services (03), before business app deployment |

---

## Shared Services Stack

| Service | Technology | Namespace | Purpose |
|---------|-----------|-----------|---------|
| Message Queue | RabbitMQ 3.12 (Operator) | `sheba-shared` | Async messaging between services |
| Cache | Redis 7 (Sentinel HA) | `sheba-shared` | Session store, caching layer |
| Search | OpenSearch 2.11 | `sheba-shared` | Full-text search, log analytics |
| API Gateway | Kong 3.5 (DB-less mode) | `sheba-gateway` | Rate limiting, auth, routing |
| Object Storage | MinIO (S3-compatible) | `sheba-shared` | File uploads, static assets |
| Email | Mailpit (dev) / SMTP relay (prod) | `sheba-shared` | Transactional email |

---

## Deployment

### RabbitMQ (Operator)

```bash
kubectl apply -f https://github.com/rabbitmq/cluster-operator/releases/latest/download/cluster-operator.yml
```

```yaml
apiVersion: rabbitmq.com/v1beta1
kind: RabbitmqCluster
metadata:
  name: sheba-rabbitmq
  namespace: sheba-shared
spec:
  replicas: 3
  resources:
    requests:
      cpu: 500m
      memory: 1Gi
  persistence:
    storageClassName: rook-ceph-block
    storage: 10Gi
```

### Redis Sentinel

```bash
helm install sheba-redis bitnami/redis \
  --namespace sheba-shared \
  --set sentinel.enabled=true \
  --set replica.replicaCount=3 \
  --set global.storageClass=rook-ceph-block
```

### OpenSearch

```bash
helm install sheba-search opensearch/opensearch \
  --namespace sheba-shared \
  --set replicas=3 \
  --set persistence.storageClass=rook-ceph-block \
  --set persistence.size=50Gi
```

### Kong API Gateway

```bash
helm install sheba-gateway kong/kong \
  --namespace sheba-gateway \
  --set ingressController.enabled=true \
  --set proxy.type=LoadBalancer
```

---

## Execution Note

### KVM Profile
Deploy with reduced replicas (1 per service) due to resource constraints. Use smaller PVC sizes (5Gi). Kong deployed with LoadBalancer type (MetalLB BGP assigns IP).

### Real Hardware Profile
Full HA deployment with 3 replicas per service. Enable persistence with Ceph RBD. Kong deployed with LoadBalancer type via MetalLB BGP.
