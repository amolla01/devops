# 01 — Deploy Sheba Cloud Infrastructure

## Overview

Master orchestrator playbook that deploys the complete Sheba Cloud platform foundation: Ceph infra pool + keyring, shared infrastructure services namespace, and prepares the cluster for SDLC and business workloads.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_sheba_cloud_infra.yml` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#1 in business** — After all infrastructure-build playbooks complete |
| Prerequisites | K8s running; Ceph healthy with OSDs; PostgreSQL deployed; monitoring active |
| Idempotent | Yes |

---

## Execution Note

### KVM Profile
Creates the `infra-storage` Ceph pool, generates keyrings, creates K8s secrets, and establishes the `sheba-infra` namespace with resource quotas suitable for lab.

```bash
ansible-playbook playbooks/reused/deploy_sheba_cloud_infra.yml \
  -i inventory/hosts.yml -v
```

### Real Hardware Profile
Same as KVM but with production resource quotas and pool sizing. Ensure Ceph has sufficient OSDs for the infra pool replica count.

```bash
ansible-playbook playbooks/reused/deploy_sheba_cloud_infra.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `ceph_pool` | K8s controller | Create infra-storage Ceph pool |
| `ceph_keyring` | K8s controller | Generate and store Ceph keyring secret |
| `namespaces` | K8s controller | Create sheba-infra, sheba-sdlc namespaces |
| `quotas` | K8s controller | Apply resource quotas and limit ranges |
| `verify` | K8s controller | Validate pool health and secret access |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `sheba_infra_namespace` | `sheba-infra` | Infrastructure services namespace |
| `sheba_sdlc_namespace` | `sheba-sdlc` | SDLC services namespace |
| `infra_pool_name` | `infra-storage` | Ceph pool for infra workloads |
| `infra_pool_replicas` | `3` | Pool replication factor |
| `infra_pool_pg_num` | `32` | Placement groups |
