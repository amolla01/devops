# 06 — PostgreSQL Deployment Validation

## Overview

Post-deployment validation procedures for PostgreSQL (CloudNativePG). Covers connectivity tests, replication verification, performance benchmarks, backup validation, and database creation for business applications.

| Attribute | Value |
|-----------|-------|
| Source | `cheat-sheet/PostgreSQL_Deployment_Validation.html` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#06** — After PostgreSQL deploy (infra-build #14), before app deployment |

---

## Validation Checklist

| # | Check | Command | Expected Result |
|---|-------|---------|-----------------|
| 1 | Cluster status | `kubectl get cluster -n postgres` | Status: Healthy |
| 2 | Pod readiness | `kubectl get pods -n postgres` | 3/3 Running |
| 3 | Primary identification | `kubectl cnpg status sheba-pg -n postgres` | 1 primary + 2 replicas |
| 4 | Replication lag | `SELECT pg_wal_lsn_diff(...);` | < 1 MB |
| 5 | Connectivity (internal) | `psql -h sheba-pg-rw.postgres.svc` | Connected |
| 6 | Connectivity (external) | `psql -h <nodeIP> -p 30432` | Connected |
| 7 | Backup schedule | `kubectl get scheduledbackup -n postgres` | Scheduled, last success recent |

---

## Detailed Validation Commands

### Cluster Health

```bash
kubectl get cluster -n postgres -o wide
kubectl cnpg status sheba-pg -n postgres
kubectl get pods -n postgres -l cnpg.io/cluster=sheba-pg
```

### Replication Verification

```sql
SELECT client_addr, state, sent_lsn, write_lsn, flush_lsn, replay_lsn,
       pg_wal_lsn_diff(sent_lsn, replay_lsn) AS lag_bytes
FROM pg_stat_replication;
```

### Performance Benchmark

```bash
kubectl exec -it sheba-pg-1 -n postgres -- pgbench -i -s 10 postgres
kubectl exec -it sheba-pg-1 -n postgres -- pgbench -c 4 -j 2 -T 60 postgres
```

### Create Application Databases

```sql
CREATE DATABASE noyobazar_catalog;
CREATE DATABASE noyobazar_orders;
CREATE DATABASE noyobazar_users;
CREATE DATABASE noyobazar_payments;

CREATE USER noyobazar_app WITH PASSWORD 'CHANGE_ME_USE_OPENBAO';
GRANT ALL PRIVILEGES ON DATABASE noyobazar_catalog TO noyobazar_app;
```

### Backup Validation

```bash
kubectl get scheduledbackup -n postgres
kubectl cnpg backup sheba-pg -n postgres
kubectl get backup -n postgres --sort-by=.metadata.creationTimestamp
```

---

## Execution Note

### KVM Profile
Run validation after `deploy_postgresql.yml` (infra-build #14). In KVM, 1 primary + 1 replica is acceptable. pgbench with scale factor 5.

### Real Hardware Profile
Full 3-node validation. Benchmark with scale factor 50+. Verify Ceph-backed PVCs performing within expected IOPS. Configure PgBouncer for production.
