# 02 — Deploy Sheba Infrastructure Services

## Overview

Deploys core infrastructure services for the Sheba Cloud platform: Gitea (Git hosting), Harbor (container registry), OpenBao (secrets management), PostgreSQL databases, Redis cache, and MinIO object storage.

| Attribute | Value |
|-----------|-------|
| Playbook | `playbooks/reused/deploy_sheba_infra_services.yml` |
| Category | Business Software |
| Profiles | KVM + Real Hardware |
| Execution Order | **#2 in business** — After Sheba Cloud Infra (namespaces + pools ready) |
| Prerequisites | sheba-infra namespace exists; Ceph infra-storage pool healthy; PostgreSQL running |
| Idempotent | Yes (Helm upgrade) |

---

## Execution Note

### KVM Profile
Deploys all infra services with minimal resource allocation. Single replicas, small PVCs. Suitable for development and testing.

```bash
ansible-playbook playbooks/reused/deploy_sheba_infra_services.yml \
  -i inventory/hosts.yml -v

# Deploy specific service:
ansible-playbook playbooks/reused/deploy_sheba_infra_services.yml \
  -i inventory/hosts.yml --tags gitea -v
```

### Real Hardware Profile
HA deployment with multiple replicas, larger PVCs, and production TLS certificates. Configure S3-compatible storage for Harbor and Gitea LFS.

```bash
ansible-playbook playbooks/reused/deploy_sheba_infra_services.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

| Tag | Scope | Description |
|-----|-------|-------------|
| `gitea` | sheba-infra | Git hosting (Gitea Helm chart) |
| `harbor` | sheba-infra | Container registry (Harbor Helm chart) |
| `openbao` | sheba-infra | Secrets management (OpenBao/Vault) |
| `redis` | sheba-infra | Redis cache cluster |
| `minio` | sheba-infra | S3-compatible object storage |
| `verify` | sheba-infra | Health checks for all services |

---

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `gitea_domain` | `git.lab.local` | Gitea ingress hostname |
| `harbor_domain` | `registry.lab.local` | Harbor ingress hostname |
| `openbao_domain` | `vault.lab.local` | OpenBao ingress hostname |
| `minio_pvc_size` | `50Gi` | MinIO storage capacity |
| `harbor_storage_backend` | `s3` | Harbor storage (s3 → MinIO) |
| `redis_cluster_enabled` | `false` | Redis cluster mode (true for prod) |
