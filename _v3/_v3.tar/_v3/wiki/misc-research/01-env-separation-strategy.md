# Environment Separation Strategy — Dev vs Production in OpenStack on CLOS Fabric

## Executive Summary

This research paper evaluates three architectural approaches for separating development and production OpenStack environments within an enterprise CLOS fabric. Each model is analyzed for isolation guarantees, resource efficiency, operational complexity, disaster recovery, and cost trajectory as the business scales from startup through long-term maturity.

---

## Architecture Models Compared

| Model | Short Name | Description |
|-------|-----------|-------------|
| **A** | Namespace Isolation | Single OpenStack cloud, dev/prod separated at Kubernetes namespace level |
| **B** | Dual Cloud, Shared Fabric | Two independent OpenStack clouds on same CLOS spine layer, different host servers |
| **C** | Separate Racks + Fabric | Completely separate leaf switches and hosts; only shared spines at the top |

---

## Model A — Namespace Isolation (Single Cloud)

### Architecture

```
                    ┌─────────────────────────────────────────────────┐
                    │              SHARED CLOS FABRIC                  │
                    │    Spine_S1 ─────────────── Spine_S2            │
                    │     │  │  │  │              │  │  │  │          │
                    │   L1  L2  L3  L4          L1  L2  L3  L4       │
                    └─────────────────────────────────────────────────┘
                                        │
                    ┌───────────────────────────────────────────────────┐
                    │         SHARED KUBERNETES CLUSTER                  │
                    │  ┌─────────────┐    ┌─────────────┐              │
                    │  │ Controllers │    │   Workers    │              │
                    │  │ Host12_1    │    │ Host12_2     │              │
                    │  │ Host34_1    │    │ Host12_3     │              │
                    │  │ HostB12_1   │    │ Host34_2     │              │
                    │  └─────────────┘    └─────────────┘              │
                    └───────────────────────────────────────────────────┘
                                        │
              ┌─────────────────────────────────────────────────────────┐
              │              SINGLE OPENSTACK CLOUD                      │
              │                                                         │
              │  ┌──────────────────┐     ┌──────────────────┐         │
              │  │   ns: prod        │     │   ns: dev         │        │
              │  │                   │     │                   │        │
              │  │  Keystone (prod)  │     │  Keystone (dev)   │        │
              │  │  Nova (prod)      │     │  Nova (dev)       │        │
              │  │  Neutron (prod)   │     │  Neutron (dev)    │        │
              │  │  Cinder (prod)    │     │  Cinder (dev)     │        │
              │  │  Manila (prod)    │     │                   │        │
              │  │  RGW (prod)       │     │                   │        │
              │  └──────────────────┘     └──────────────────┘         │
              │                                                         │
              │  Shared: Ceph cluster, RabbitMQ, MariaDB Galera         │
              └─────────────────────────────────────────────────────────┘
```

### Characteristics

| Aspect | Detail |
|--------|--------|
| **Isolation Level** | Logical (K8s namespace + RBAC + NetworkPolicy) |
| **Blast Radius** | HIGH — noisy neighbor, shared control plane failure affects both |
| **Hardware Required** | Minimum — reuse all existing hosts |
| **Network Isolation** | VRF/VNI per tenant (VNI 10000–19999 dev, 20000–29999 prod) |
| **Ceph Pools** | Shared (quota-based), or separate pools per env |
| **Keystone** | Separate domains OR separate Keystone deployments in different namespaces |
| **Upgrade Path** | Risk: one upgrade affects both environments |

### Disaster Recovery — Model A

```
┌───────── PRIMARY SITE ─────────┐     ┌───────── DR SITE ──────────────┐
│  Single K8s + Single OpenStack │     │  Single K8s + Single OpenStack │
│  ns: prod  │  ns: dev          │     │  ns: prod  │  ns: dev          │
│  Ceph RBD mirrors ─────────────│────▶│  Ceph RBD mirrors              │
│  CephFS snapshots ─────────────│────▶│  CephFS snapshots              │
└────────────────────────────────┘     └────────────────────────────────┘
         Ceph RBD mirroring (async, pool-level)
         RGW multi-site (zone sync)
         MariaDB async replication
```

**DR Strategy:**
- Ceph RBD pool mirroring (async, RPO ~seconds)
- RGW multi-site zone replication for objects
- MariaDB Galera async replication for control plane state
- **RTO:** 15–30 min (failover involves DNS + Keystone endpoint switch)
- **RPO:** ~5–30 seconds (async Ceph mirroring lag)

---

## Model B — Dual Cloud, Shared Fabric

### Architecture

```
                    ┌─────────────────────────────────────────────────┐
                    │              SHARED CLOS FABRIC                  │
                    │    Spine_S1 ─────────────── Spine_S2            │
                    │     │  │  │  │              │  │  │  │          │
                    │   L1  L2  L3  L4          L1  L2  L3  L4       │
                    └─────────────────────────────────────────────────┘
                           │        │                 │        │
           ┌───────────────┘        └──────┐  ┌──────┘        └───────────────┐
           │                               │  │                               │
┌──────────────────────────────┐  ┌──────────────────────────────┐
│   PRODUCTION CLOUD            │  │   DEVELOPMENT CLOUD            │
│                               │  │                               │
│  K8s Cluster (PROD)           │  │  K8s Cluster (DEV)            │
│  ┌───────────┐ ┌───────────┐ │  │  ┌───────────┐ ┌───────────┐ │
│  │Host12_1   │ │Host12_2   │ │  │  │Host34_1   │ │Host34_2   │ │
│  │(ctrl)     │ │(worker)   │ │  │  │(ctrl)     │ │(worker)   │ │
│  └───────────┘ └───────────┘ │  │  └───────────┘ └───────────┘ │
│  ┌───────────┐               │  │                               │
│  │Host12_3   │               │  │                               │
│  │(worker)   │               │  │                               │
│  └───────────┘               │  │                               │
│                               │  │                               │
│  OpenStack: Keystone, Nova,   │  │  OpenStack: Keystone, Nova,   │
│  Neutron, Cinder, Manila, RGW │  │  Neutron, Glance              │
│  Ceph (full: RBD+FS+RGW)     │  │  Ceph (minimal: RBD only)     │
└──────────────────────────────┘  └──────────────────────────────┘

NETWORK ISOLATION:
  PROD servers: Leaf_L1 / Leaf_L2 (VNI 20000–29999)
  DEV servers:  Leaf_L3 / Leaf_L4 (VNI 10000–19999)
  BGP policies prevent cross-advertisement
```

### Characteristics

| Aspect | Detail |
|--------|--------|
| **Isolation Level** | Physical host + separate K8s + separate OpenStack control planes |
| **Blast Radius** | LOW — dev failure cannot affect prod (different hosts, different control plane) |
| **Hardware Required** | 2× the minimum (separate hosts for each cloud) |
| **Network Isolation** | Different leaf pairs + VRF/VNI + BGP route policies |
| **Ceph Pools** | Completely separate Ceph clusters (no shared OSDs) |
| **Keystone** | Completely independent Keystone instances |
| **Upgrade Path** | Safe: upgrade dev first, validate, then promote to prod |

### Disaster Recovery — Model B

```
┌──── PRIMARY SITE (Pod 12) ─────┐     ┌──── DR SITE ──────────────────┐
│                                 │     │                                │
│  PROD Cloud (Host12_*)          │     │  PROD-DR Cloud (dedicated HW)  │
│  K8s + OpenStack + Ceph         │     │  K8s + OpenStack + Ceph        │
│  ┌─────────────────────────┐   │     │  ┌─────────────────────────┐  │
│  │ Ceph (RBD+FS+RGW) ──────│───│────▶│  │ Ceph (RBD+FS+RGW)      │  │
│  └─────────────────────────┘   │     │  └─────────────────────────┘  │
└─────────────────────────────────┘     └────────────────────────────────┘

┌──── PRIMARY SITE (Pod 34) ─────┐
│                                 │     DEV has NO dedicated DR
│  DEV Cloud (Host34_*)           │     (rebuild from IaC if lost)
│  K8s + OpenStack + Ceph         │
└─────────────────────────────────┘
```

**DR Strategy:**
- **Production:** Dedicated DR site with Ceph RBD mirroring + RGW multi-site
- **Development:** No DR — rebuilt from Ansible/IaC in <2 hours (acceptable data loss)
- **RTO (Prod):** 10–20 min (pre-staged, just needs failover)
- **RPO (Prod):** ~5 seconds (synchronous Ceph mirroring over dedicated link)
- **RTO (Dev):** 2–4 hours (full redeploy from automation)

---

## Model C — Separate Racks + Separate Fabric Leaves

### Architecture

```
                    ┌─────────────────────────────────────────────────────┐
                    │                 SHARED SPINE TIER                    │
                    │         Spine_S1 ─────────────── Spine_S2           │
                    │          │  │  │  │  │  │        │  │  │  │  │  │  │
                    └──────────┼──┼──┼──┼──┼──┼────────┼──┼──┼──┼──┼──┼──┘
                               │  │  │  │  │  │        │  │  │  │  │  │
         ┌─────────────────────┘  │  │  │  │  └───┐   │  │  │  │  │  └──────────────────┐
         │                        │  │  │  │      │   │  │  │  │  │                      │
    ┌────┼────────────────────────┼──┼──┘  └──────┼───┼──┼──┘  └──┼─────────────────────┐│
    │    │                        │  │            │   │  │        │                      ││
    │    ▼                        ▼  ▼            ▼   ▼  ▼        ▼                      ││
┌───────────────────────┐  ┌───────────────────────┐  ┌────────────────────────────────┐ ││
│   PROD RACK (Pod 12)   │  │   DEV RACK (Pod 34)    │  │   DR RACK (Pod B12)             │ ││
│                         │  │                         │  │                                │ ││
│  Leaf_L1    Leaf_L2     │  │  Leaf_L3    Leaf_L4     │  │  Leaf_L5    Leaf_L6            │ ││
│   │  │       │  │       │  │   │  │       │  │       │  │   │  │       │  │              │ ││
│   ▼  ▼       ▼  ▼       │  │   ▼  ▼       ▼  ▼       │  │   ▼  ▼       ▼  ▼              │ ││
│  Host12_1  Host12_2     │  │  Host34_1  Host34_2     │  │  HostB12_1  HostB12_2          │ ││
│  Host12_3  Host12_4     │  │  Host34_3  Host34_4     │  │  HostB12_3  MonitorSrv         │ ││
│  Host12_5  Host12_6     │  │                         │  │                                │ ││
│                         │  │                         │  │                                │ ││
│  K8s Cluster (PROD)     │  │  K8s Cluster (DEV)      │  │  K8s Cluster (DR)              │ ││
│  OpenStack (full)       │  │  OpenStack (minimal)    │  │  OpenStack (prod mirror)       │ ││
│  Ceph (RBD+FS+RGW)     │  │  Ceph (RBD only)        │  │  Ceph (RBD+FS+RGW replica)    │ ││
│                         │  │                         │  │                                │ ││
│  VNI: 20000–29999       │  │  VNI: 10000–19999       │  │  VNI: 30000–39999              │ ││
│  ASN: 65011, 65012      │  │  ASN: 65013, 65014      │  │  ASN: 65015, 65016             │ ││
└─────────────────────────┘  └─────────────────────────┘  └────────────────────────────────┘ │
                                                                                              │
ISOLATION: Physical (different TOR switches, different hosts, different cables)                │
CONNECTIVITY: Only via spine (controlled by BGP import/export policies)                       │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

### Characteristics

| Aspect | Detail |
|--------|--------|
| **Isolation Level** | Physical (different racks, different TOR switches, different hosts) |
| **Blast Radius** | ZERO — complete physical isolation; even a power event in one rack doesn't affect others |
| **Hardware Required** | 3× the minimum (prod rack + dev rack + DR rack) |
| **Network Isolation** | Different leaf switches, different cables, different VNI ranges, different ASNs |
| **Ceph Pools** | Completely separate Ceph clusters on physically separate disks |
| **Keystone** | Completely independent (no shared anything) |
| **Upgrade Path** | Safest: fully independent lifecycle management |

### Disaster Recovery — Model C

```
┌──── PROD RACK (Pod 12) ────────┐          ┌──── DR RACK (Pod B12) ──────────┐
│  Leaf_L1 / Leaf_L2              │          │  Leaf_L5 / Leaf_L6               │
│  Host12_1–6                     │          │  HostB12_1–3 + MonitorSrv        │
│  K8s + OpenStack + Ceph (full)  │          │  K8s + OpenStack + Ceph (mirror) │
│                                 │          │                                  │
│  Ceph RBD pool mirror ──────────│─────────▶│  Ceph RBD pool mirror            │
│  RGW multi-site ────────────────│─────────▶│  RGW multi-site                  │
│  CephFS snapshot export ────────│─────────▶│  CephFS snapshot import          │
│  MariaDB async replication ─────│─────────▶│  MariaDB standby                 │
└─────────────────────────────────┘          └──────────────────────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │ MetalLB VIP      │
                                               │ DNS GSLB failover│
                                               │ (automatic)      │
                                               └─────────────────┘

┌──── DEV RACK (Pod 34) ─────────┐
│  Leaf_L3 / Leaf_L4              │     DEV: No DR (rebuild from IaC)
│  Host34_1–4                     │     IaC repo = single source of truth
│  K8s + OpenStack + Ceph (min)   │
└─────────────────────────────────┘
```

**DR Strategy:**
- **Production:** Dedicated DR rack with full Ceph mirroring across spine links
- **Replication link:** Dedicated VXLAN tunnel between L1/L2 ↔ L5/L6 via spines (10Gbps+)
- **Failover:** Automatic DNS/GSLB with MetalLB advertising DR VIPs upon primary failure
- **RTO (Prod):** 5–10 min (hot standby, pre-staged Ceph secondary)
- **RPO (Prod):** ~1–5 seconds (near-synchronous, limited by spine bandwidth)
- **Dev:** No DR — full IaC rebuild from Ansible in <2 hours

---

## Comparative Analysis

### Trade-Off Matrix

| Criteria | Model A (Namespace) | Model B (Dual Cloud) | Model C (Separate Racks) |
|----------|:-------------------:|:--------------------:|:------------------------:|
| **Isolation** | ⚠️ Logical only | ✅ Physical hosts | ✅✅ Physical everything |
| **Blast Radius** | 🔴 High | 🟡 Medium | 🟢 Zero |
| **Hardware Cost** | 🟢 Lowest (1×) | 🟡 Medium (2×) | 🔴 Highest (3×) |
| **Operational Complexity** | 🟢 Single pane of glass | 🟡 Two control planes | 🔴 Three clusters to manage |
| **Network Complexity** | 🟢 Standard (RBAC/NetworkPolicy) | 🟡 BGP policy per env | 🔴 Separate TOR + policy + cabling |
| **Upgrade Safety** | 🔴 One upgrade = both environments | 🟢 Canary in dev first | 🟢 Full independence |
| **Resource Efficiency** | 🟢 Highest (shared everything) | 🟡 Moderate (duplicate control planes) | 🔴 Lowest (3× control planes) |
| **Compliance** | 🔴 May not pass audits (shared infra) | 🟡 Acceptable for most | 🟢 SOC2/PCI/HIPAA ready |
| **DR Cost** | 🟡 One DR site mirrors everything | 🟢 DR only for prod | 🟢 Dedicated DR rack |
| **Scaling** | 🔴 Vertical only (shared noisy neighbor) | 🟡 Per-cloud horizontal | 🟢 Per-rack horizontal |
| **Dev → Prod Promotion** | 🟢 Same APIs, same endpoints | 🟡 Different endpoints, same code | 🔴 Different everything |
| **Time to Deploy** | 🟢 Hours | 🟡 Days | 🔴 Weeks |

### Risk Assessment

| Risk | Model A | Model B | Model C |
|------|---------|---------|---------|
| Control plane crash takes both envs offline | **YES** | No | No |
| Ceph OSD failure degrades both envs | **YES** | No | No |
| Network loop on one leaf affects all | **YES** | Partially (shared spines) | No (different TOR) |
| Accidental RBAC/policy misconfiguration exposes prod data to dev | **YES** | No | No |
| Single firmware bug on shared switch | Affects both | Partially (shared spines) | Affects one rack only |
| Power event (PDU failure in one rack) | Affects both | May affect one cloud | Affects only that rack |

---

## Growth Strategy: Startup → Short-Term → Long-Term

### Phase 1: Startup (0–12 months, <10 developers)

**Recommended: Model A (Namespace Isolation)**

```
┌──────────────────────────────────────────────────────────────────┐
│                 STARTUP TOPOLOGY                                   │
│                                                                    │
│    Spine_S1 ─── Spine_S2                                          │
│      │             │                                              │
│    Leaf_L1/L2    Leaf_L3/L4                                       │
│      │             │                                              │
│   Host12_1–3    Host34_1–2     (5 servers total)                  │
│                                                                    │
│   Single K8s cluster (3 controllers, 2 workers)                   │
│   Single OpenStack (minimal: Keystone + Nova + Neutron + Glance)  │
│   Single Ceph (RBD only, 2-way replication)                       │
│                                                                    │
│   Dev: K8s namespace "openstack-dev" (ResourceQuota: 25% cluster) │
│   Prod: K8s namespace "openstack-prod" (ResourceQuota: 75%)       │
│                                                                    │
│   DR: Ansible IaC + off-site Ceph RBD snapshots (S3 bucket)       │
└──────────────────────────────────────────────────────────────────┘
```

**Rationale:**
- Minimum hardware, minimum cost
- Single team manages everything
- Acceptable risk: if prod goes down, dev goes down too (small team can tolerate)
- DR: Daily Ceph snapshots exported to off-site S3; rebuild from IaC in 2–4 hours

**Ansible var file: `cd/vars/ceph-values-dev.yml` (startup profile)**
```yaml
ceph_mds_enabled: false
ceph_rgw_enabled: false
ceph_osd_pool_default_size: 2
rook_ceph_mon_count: 1
```

---

### Phase 2: Short-Term (12–36 months, 10–50 developers)

**Recommended: Model B (Dual Cloud, Shared Fabric)**

```
┌──────────────────────────────────────────────────────────────────┐
│              SHORT-TERM TOPOLOGY                                   │
│                                                                    │
│    Spine_S1 ─── Spine_S2 (shared, upgraded to 100G)               │
│      │  │         │  │                                            │
│    L1  L2       L3  L4                                            │
│     │   │        │   │                                            │
│  ┌──┴───┴──┐  ┌──┴───┴──┐                                        │
│  │PROD HOSTS│  │DEV HOSTS │                                       │
│  │12_1–12_5 │  │34_1–34_3 │                                       │
│  └──────────┘  └──────────┘                                       │
│                                                                    │
│  PROD:                        DEV:                                │
│  - K8s (3 ctrl + 2 wkr)      - K8s (1 ctrl + 2 wkr)             │
│  - OpenStack (full suite)     - OpenStack (minimal)               │
│  - Ceph (RBD + CephFS + RGW) - Ceph (RBD only)                   │
│  - 3-way replication          - 2-way replication                 │
│                                                                    │
│  DR: Prod-only DR at secondary site                               │
│      (Ceph RBD mirror + RGW multi-site)                           │
│                                                                    │
│  PROMOTION PIPELINE:                                              │
│  Dev OpenStack ──validate──▶ Prod OpenStack                       │
│  (ansible-playbook --check → ansible-playbook --apply)            │
└──────────────────────────────────────────────────────────────────┘
```

**Rationale:**
- Dev team has grown; accidental dev impact on prod is now unacceptable
- Separate control planes: dev upgrade doesn't risk prod
- Shared spines reduce cost (no new spine switches needed)
- BGP route policy enforces network isolation (no cross-talk)
- Dev uses smaller, cheaper hardware (fewer OSDs, less replication)
- DR is prod-only (business can afford dev rebuild from IaC)

**Migration from Phase 1:**
1. Deploy new K8s cluster on Host34_* (reuse existing hardware)
2. Deploy minimal OpenStack on dev cluster
3. Migrate dev workloads from prod namespace to new dev cloud
4. Remove dev namespace from prod cloud
5. Reclaim resources for prod

---

### Phase 3: Long-Term (36+ months, 50+ developers, compliance requirements)

**Recommended: Model C (Separate Racks + Fabric)**

```
┌──────────────────────────────────────────────────────────────────────────┐
│                    LONG-TERM TOPOLOGY                                      │
│                                                                            │
│    Spine_S1 ═══════════ Spine_S2 ═══════════ Spine_S3 ═══════ Spine_S4   │
│    (100G)               (100G)               (100G)           (100G)      │
│     │  │  │  │           │  │  │  │           │  │  │           │  │  │  │
│    L1 L2 L3 L4         L5 L6 L7 L8          L9 L10           L11 L12    │
│                                                                            │
│  ┌─────────────┐   ┌─────────────┐   ┌──────────────┐   ┌────────────┐  │
│  │ PROD RACK 1 │   │ PROD RACK 2 │   │  DEV RACK    │   │  DR RACK   │  │
│  │ (Pod 12)    │   │ (Pod 34)    │   │  (Pod 56)    │   │  (Pod B12) │  │
│  │             │   │             │   │              │   │            │  │
│  │ Ctrl × 3   │   │ Workers × 6 │   │ Ctrl × 1    │   │ Ctrl × 3   │  │
│  │ Workers × 4 │   │ Storage × 4 │   │ Workers × 3 │   │ Workers × 4│  │
│  │ Storage × 4 │   │             │   │ Storage × 2 │   │ Storage × 4│  │
│  └─────────────┘   └─────────────┘   └──────────────┘   └────────────┘  │
│                                                                            │
│  PROD (multi-rack):                                                       │
│  - Stretched K8s cluster across Pod 12 + Pod 34                           │
│  - OpenStack (full: all services + Manila + RGW)                          │
│  - Ceph stretched (3-way, rack-aware CRUSH)                               │
│  - Multi-AZ: az-pod12 + az-pod34                                         │
│                                                                            │
│  DEV (independent rack):                                                  │
│  - Own K8s + own OpenStack (minimal)                                      │
│  - Own Ceph (2-way, dev-only)                                             │
│  - Completely isolated failure domain                                      │
│                                                                            │
│  DR (hot standby):                                                        │
│  - Mirror of prod (same capacity)                                         │
│  - Ceph synchronous mirroring (RPO ≈ 0)                                  │
│  - Automatic GSLB failover (RTO < 5 min)                                 │
│                                                                            │
│  COMPLIANCE:                                                              │
│  - SOC2: separate failure domains ✓                                       │
│  - PCI-DSS: network segmentation ✓                                        │
│  - HIPAA: data isolation ✓                                                │
└──────────────────────────────────────────────────────────────────────────┘
```

**Rationale:**
- Large team; compliance requirements (SOC2, PCI-DSS, HIPAA)
- Zero blast radius — even a spine failure is survived (4-spine + ECMP)
- Prod is stretched across 2 racks for within-site HA
- DR is a dedicated rack with near-zero RPO
- Dev is fully independent — can be destroyed and rebuilt without any impact
- Each rack has its own power feeds, TOR switches, and management plane
- 4-spine tier provides 2-spine-failure tolerance (any 2 can fail)

**Migration from Phase 2:**
1. Procure new rack + leaf switches (L5/L6 for dev, L7/L8 for expanded prod)
2. Connect new leaves to existing spines
3. Deploy new K8s + Ceph + OpenStack on dev rack
4. Migrate dev workloads from shared-fabric to dedicated rack
5. Expand prod across two racks (stretch K8s, stretch Ceph CRUSH map)
6. Deploy DR rack with Ceph mirroring

---

## Cost Comparison (Relative Units)

| Component | Model A | Model B | Model C |
|-----------|:-------:|:-------:|:-------:|
| Servers | 5 | 8 | 20+ |
| Leaf switches | 4 (shared) | 4 (shared) | 8–12 |
| Spine switches | 2 | 2 | 2–4 |
| Ceph OSDs | 6–12 | 12–18 | 36+ |
| K8s clusters | 1 | 2 | 3+ |
| OpenStack deploys | 1 | 2 | 3+ |
| Annual OpEx (FTE) | 0.5 | 1.0 | 2.0 |
| Monthly power (est.) | $800 | $1,500 | $4,000+ |

---

## Decision Framework

```
START
  │
  ├── Team < 10 devs, budget tight, no compliance?
  │     └── MODEL A (Namespace)
  │
  ├── Team 10–50 devs, dev impact on prod unacceptable?
  │     └── MODEL B (Dual Cloud, Shared Fabric)
  │
  └── Team 50+ devs, compliance required, zero-downtime mandatory?
        └── MODEL C (Separate Racks)
```

### When to Transition

| Trigger | Current Model | Upgrade To |
|---------|:------------:|:----------:|
| First production SLA breach caused by dev activity | A | B |
| SOC2/PCI audit requirement | A or B | C |
| Team exceeds 30 developers | A | B |
| Revenue exceeds $10M ARR | B | C |
| Multi-region expansion needed | B | C |
| First unplanned outage lasting >1 hour | A | B or C |

---

## Implementation with Our Ansible Automation

Each model maps directly to our existing playbook structure:

### Model A Vars (Startup)

```yaml
# Single ceph-values file for both envs
# cd/vars/ceph-values-dev.yml
ceph_mds_enabled: false
ceph_rgw_enabled: false
ceph_osd_pool_default_size: 2

# K8s namespaces for OpenStack
openstack_prod_namespace: "openstack-prod"
openstack_dev_namespace: "openstack-dev"
```

### Model B Vars (Short-Term)

```yaml
# PROD: cd/vars/ceph-values-prod.yml
ceph_mds_enabled: true
ceph_rgw_enabled: true
ceph_rgw_instances: 2
ceph_osd_pool_default_size: 3

# DEV: cd/vars/ceph-values-dev.yml
ceph_mds_enabled: false
ceph_rgw_enabled: false
ceph_osd_pool_default_size: 2
```

### Model C Vars (Long-Term)

```yaml
# PROD: cd/vars/ceph-values-prod.yml (stretched across 2 racks)
ceph_mds_enabled: true
ceph_rgw_enabled: true
ceph_rgw_instances: 2
ceph_osd_pool_default_size: 3
rook_ceph_mon_count: 5
ceph_crush_failure_domain: "rack"   # rack-aware CRUSH

# DR: cd/vars/ceph-values-dr.yml (mirror of prod)
ceph_mds_enabled: true
ceph_rgw_enabled: true
ceph_rgw_instances: 1
ceph_osd_pool_default_size: 3
rook_ceph_mon_count: 3
ceph_rbd_mirror_enabled: true

# DEV: cd/vars/ceph-values-dev.yml (independent)
ceph_mds_enabled: false
ceph_rgw_enabled: false
ceph_osd_pool_default_size: 2
rook_ceph_mon_count: 1
```

---

## Recommendation

**For our current lab (R810 KVM + growing toward real hardware):**

1. **Now (Startup):** We are effectively running **Model A** — single K8s + single OpenStack + shared Ceph. This is appropriate for the current team size.

2. **Next step (6–12 months):** Transition to **Model B** when:
   - A second team needs independent dev access
   - First SLA is defined for production workloads
   - Hardware from `real_hardware` profile is racked

3. **Target state (18–36 months):** Evolve to **Model C** when:
   - Compliance audits begin (SOC2, regulatory)
   - Production revenue depends on uptime
   - Multi-AZ or multi-site is required

---

## References

- [13-deploy-ceph-rook.md](../infrastructure-build/13-deploy-ceph-rook.md) — Ceph deployment details
- [15-deploy-openstack-helm.md](../infrastructure-build/15-deploy-openstack-helm.md) — OpenStack deployment details
- [19-multi-tenant-architecture.md](../infrastructure-build/19-multi-tenant-architecture.md) — VRF/VNI isolation model
- [20-multi-homing-strategy.md](../infrastructure-build/20-multi-homing-strategy.md) — EVPN multi-homing
- [16-extend-topology.md](../infrastructure-build/16-extend-topology.md) — Non-disruptive expansion
- [24-deploy-metallb.md](../infrastructure-build/24-deploy-metallb.md) — MetalLB for service IP management
