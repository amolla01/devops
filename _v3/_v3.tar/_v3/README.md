# _v3 Hardened Architecture Operations Layer

This folder is a curated, hardened operations layer for full deployment and teardown workflows.

It does not blindly clone older stacks. It reuses stable _v1 artifacts for base bring-up and injects _v3-native roles for:
- OpenStack gateway nodes
- Premium firewall service tier
- Service-catalog aligned operations

All reused assets are localized under _v3:
- Reused playbooks: `playbooks/reused/`
- Reused roles copied into `roles/` (alongside _v3-native roles)

## Management Switch Implementation Note

In the current lab topology implementation, `Mgmt_Switch` is **not** deployed as a dedicated SONiC Accton VM.
It is implemented by `deploy_lab_v13.sh` as a libvirt management network (`dc-mgmt`) plus OVS/libvirt bridge wiring for data-plane links.

`deploy_lab_v13.sh` is vendored inside `_v3` (`_v3/deploy_lab_v13.sh`) so `_v3` topology behavior does not drift when parent-folder scripts change.

- Topology wiring owner: `./deploy_lab_v13.sh` (called by `deploy_lab_v3.sh` for `kvm-deploy*` actions)
- Device day0 management IP/gateway owner: `playbooks/reused/deploy_day0.yml` via role `sonic_day0`

This means all VM management NIC0 interfaces are attached to `dc-mgmt` during topology deployment, while switch management settings inside SONiC are rendered/applied during Day-0 provisioning.

### Strict OOB Policy (Exit Router and Border Leaf)

The intended model is enforced as:
- OOB management subnet stays out of L3 CLOS fabric routing.
- Exit router data-plane peering to border leaf remains on dedicated fabric links only.
- Management plane uses `dc-mgmt` and is treated as separate from fabric bridges.

Enforcement points:
- `./deploy_lab_v13.sh` validates OOB isolation before creating networks (`validate_oob_isolation_policy`).
- `roles/mikrotik_base/tasks/day1_bgp.yml` asserts management subnet is not advertised or learned through fabric BGP sessions.
- `inventory/group_vars/all.yml` exposes policy vars:
	- `oob_management_subnet`
	- `oob_management_route_token`

## Strategy: Reuse vs Rewrite

Reusable (copied under `playbooks/reused/`):
- `deploy_day0.yml` (base provisioning)
- `deploy_day1.yml` (fabric wiring)
- `deploy_kubespray.yml`
- `deploy_postgresql.yml`
- `deploy_maas.yml`
- `deploy_ceph.yml`
- `deploy_openstack_helm.yml`
- `deploy_monitoring.yml`

Rewritten or _v3-native:
- `playbooks/deploy_openstack_gateways.yml`
- `playbooks/deploy_premium_firewall.yml`
- `playbooks/teardown_openstack_gateways.yml`
- `playbooks/teardown_premium_firewall.yml`
- `playbooks/deploy_full_environment.yml`
- `playbooks/teardown_full_environment.yml`
- `playbooks/deploy_service_catalog.yml`

## Folder Layout

- `inventory/` : single source of truth — all hosts, group vars, host vars
- `playbooks/` : orchestration and role-specific deploy/teardown playbooks
- `playbooks/reused/` : imported reusable playbooks from _v1
- `roles/` : _v3-native roles for gateway and premium firewall service
- `cheat-sheet/` : category-based operator runbooks for laptop execution

## Laptop Controller Execution Model

Expected model:
1. You run Ansible from laptop controller.
2. Laptop reaches R620/R810 and lab VMs over routed path or ProxyJump.
3. Inventory variables in `inventory/group_vars/all.yml` control jump-host behavior.

## Quick Start

Validate inventory:

`ansible-inventory -i inventory/hosts.yml --list`

Laptop-to-hypervisor preflight (ProxyJump and key-auth check):

`bash deploy_lab_v3.sh --proxy-jump-host jump.example --ssh-key ~/.ssh/id_r620 --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 preflight`

Initial KVM topology setup (deploy_lab_v13.sh-style wrapper):

`bash deploy_lab_v3.sh --profile ubuntu_r620_kvm kvm-deploy`

Initial KVM setup from laptop, executed on remote hypervisor:

`bash deploy_lab_v3.sh --remote-v13-host admin@10.1.1.20 --remote-v13-path /home/admin/apm0015564-kepler-ssot-cicd/data-center/_v3/deploy_lab_v13.sh --profile ubuntu_r620_kvm kvm-deploy`

Full topology + day0 onward services:

`bash deploy_lab_v3.sh --profile ubuntu_r620_kvm full`

Phased deployment:

`bash deploy_lab_v3.sh phase-r620`

`bash deploy_lab_v3.sh phase-r810`

`bash deploy_lab_v3.sh phased-full`

Remote hypervisor KVM deployments from laptop:

`bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 kvm-deploy-r620`

`bash deploy_lab_v3.sh --r810-host admin@10.1.1.21 kvm-deploy-r810`

`bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 kvm-deploy-both`

Remote virsh operations from laptop:

`bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 remote-status`

`bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 remote-virsh r620 start Spine_S1`

`bash deploy_lab_v3.sh --r810-host admin@10.1.1.21 remote-virsh r810 list --all`

Deploy full environment:

`ansible-playbook -i inventory/hosts.yml playbooks/deploy_full_environment.yml`

Deploy only gateway tier:

`ansible-playbook -i inventory/hosts.yml playbooks/deploy_openstack_gateways.yml`

Deploy premium firewall tier:

`ansible-playbook -i inventory/hosts.yml playbooks/deploy_premium_firewall.yml`

Teardown full environment (guarded):

`ansible-playbook -i inventory/hosts.yml playbooks/teardown_full_environment.yml -e allow_destructive_teardown=true -e teardown_confirmation_token=YES-TEARDOWN-ALL`

## Notes

- Teardown is intentionally guarded and requires explicit token confirmation.
- Premium firewall service in _v3 is modeled as advanced service-tier logic beyond native OpenStack security groups.
- Use `cheat-sheet/` for categorized day-0/day-1/service/teardown operations.
