# Ceph Storage Deployment — Complete Reference

## Overview

The lab deploys **Ceph Reef v18.2.2** as the unified block/filesystem storage backend for both Kubernetes and OpenStack workloads. Two deployment modes are supported:

| Mode | Mechanism | When to Use |
|------|-----------|-------------|
| **Rook** (default) | K8s-native operator, Ceph runs as pods in `rook-ceph` namespace | Post-Kubespray; preferred for KVM lab |
| **Cephadm** | Bare-metal podman containers orchestrated by cephadm CLI | Real hardware; no K8s available yet |

The active mode is controlled by `ceph_deploy_mode` in `roles/ceph/defaults/main.yml`.

---

## Architecture

```
┌───────────────────────────────────────────────────────────┐
│                   Kubernetes Cluster                        │
│  ┌──────────────────────────────────────────────────────┐ │
│  │              rook-ceph namespace                       │ │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────────────────┐  │ │
│  │  │ MON Pod │  │ MGR Pod │  │  OSD Pods (per disk) │  │ │
│  │  │ x2      │  │ x1      │  │  x12 (6 nodes × 2)  │  │ │
│  │  └─────────┘  └─────────┘  └─────────────────────┘  │ │
│  │  ┌─────────┐  ┌────────────────┐                     │ │
│  │  │ MDS Pod │  │ Rook Operator  │                     │ │
│  │  │ x1+stby │  │ (control loop) │                     │ │
│  │  └─────────┘  └────────────────┘                     │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                           │
│  ┌──────────────────────────────────────────────────────┐ │
│  │  StorageClasses                                       │ │
│  │    ceph-rbd (default) — block volumes                │ │
│  │    ceph-filesystem    — shared filesystem            │ │
│  └──────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────┘
```

### Cluster Topology

| Node | Role | IPs | OSD Devices |
|------|------|-----|-------------|
| Host12_1 | K8s Controller + MON + OSD | 172.16.2.40 | /dev/vdb, /dev/vdc |
| Host12_2 | K8s Worker + OSD | 172.16.2.41 | /dev/vdb, /dev/vdc |
| Host12_3 | K8s Worker + OSD | 172.16.2.42 | /dev/vdb, /dev/vdc |
| Host34_1 | K8s Controller + MON + OSD | 172.16.2.43 | /dev/vdb, /dev/vdc |
| Host34_2 | K8s Worker + OSD | 172.16.2.44 | /dev/vdb, /dev/vdc |
| HostB12_1 | K8s Controller + OSD | 172.16.2.45 | /dev/vdb, /dev/vdc |

**Network:** Single flat 172.16.2.0/24 (both public + cluster network in KVM lab).

---

## File Inventory

### Playbooks

| File | Purpose |
|------|---------|
| `playbooks/reused/deploy_ceph_rook.yml` | **Primary** — Rook-Ceph K8s deployment (4 phases) |
| `playbooks/reused/deploy_ceph.yml` | Cephadm bare-metal deployment (6 phases) |
| `playbooks/reused/deploy_ceph_infra_pool.yml` | Create `infra-storage` pool + K8s Secret |
| `playbooks/reused/preflight_download.yml` | Pre-cache Rook charts + cephadm binary |

### Role (`roles/ceph/`)

| File | Purpose |
|------|---------|
| `defaults/main.yml` | Default variables (version pins, cache paths, deploy mode) |
| `tasks/main.yml` | Orchestrator — fails if mode=rook, else runs cephadm phases |
| `tasks/preflight.yml` | Install packages + cephadm (3-priority cache lookup) |
| `tasks/bootstrap.yml` | cephadm bootstrap on primary MON |
| `tasks/add_hosts.yml` | Expand cluster to additional hosts |
| `tasks/discover_volumes.yml` | Dynamic OSD device discovery (lsblk + OS root exclusion) |
| `tasks/deploy_osds.yml` | Activate OSD devices (dynamic or static) |
| `tasks/create_pools.yml` | Create pre-defined pools (kube-rbd, openstack-*, cephfs) |
| `tasks/create_keyrings.yml` | Generate client keyrings (client.kube, client.openstack) |
| `tasks/enable_services.yml` | Enable dashboard, MDS, prometheus modules |
| `tasks/validate.yml` | Health check and status report |
| `tasks/day1_osd_operations.yml` | Incremental OSD add/remove/rollback/update |
| `templates/cluster-spec.yaml.j2` | Cephadm declarative cluster specification |
| `templates/rook-ceph-cluster-values.yml.j2` | Rook CephCluster Helm values |

### Inventory Group Variables

| File | Contents |
|------|----------|
| `inventory/group_vars/ceph_mon.yml` | FSID, network config, pool definitions, keyrings, MDS |
| `inventory/group_vars/ceph_osd.yml` | Device selection, BlueStore config, performance tuning |

---

## Deployment Commands

### Prerequisites
```bash
# 1. Kubernetes must be running (Kubespray completed)
kubectl get nodes   # all nodes Ready

# 2. Pre-cache artifacts (run on deployer with internet access)
ansible-playbook playbooks/reused/preflight_download.yml \
  -i inventory/hosts.yml --tags ceph -v
```

### Rook-Ceph Deployment (Recommended)

```bash
# Full deployment (operator + cluster + validation)
ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml -v

# Phase-by-phase:
ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml --tags rook_prepare -v

ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml --tags rook_operator -v

ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml --tags rook_cluster -v

ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml --tags rook_validate -v
```

### Cephadm Deployment (Alternative)

```bash
# Requires ceph_deploy_mode: "cephadm" in defaults
ansible-playbook playbooks/reused/deploy_ceph.yml \
  -i inventory/hosts.yml -v

# Individual phases:
ansible-playbook playbooks/reused/deploy_ceph.yml \
  -i inventory/hosts.yml --tags ceph_preflight -v

ansible-playbook playbooks/reused/deploy_ceph.yml \
  -i inventory/hosts.yml --tags ceph_bootstrap -v

ansible-playbook playbooks/reused/deploy_ceph.yml \
  -i inventory/hosts.yml --tags ceph_osd -v

ansible-playbook playbooks/reused/deploy_ceph.yml \
  -i inventory/hosts.yml --tags ceph_pools,ceph_keyrings -v
```

### Post-Deployment: Infra Pool

```bash
# Creates infra-storage pool + K8s secret in sheba-cloud-infra namespace
ansible-playbook playbooks/reused/deploy_ceph_infra_pool.yml \
  -i inventory/hosts.yml -v
```

---

## Tag Reference

### Rook Playbook Tags (`deploy_ceph_rook.yml`)

| Tag | Scope | Description |
|-----|-------|-------------|
| `rook` | All phases | Run all Rook phases (prepare + operator + cluster) |
| `rook_prepare` | Phase 0 | Wipe OSD disks, load kernel modules |
| `rook_operator` | Phase 1 | Deploy Rook operator Helm chart |
| `rook_cluster` | Phase 2 | Deploy CephCluster CR (MON/OSD/MGR pods) |
| `rook_validate` | Phase 3 | Health check, PVC binding test |
| `rook_teardown` | Phase 4 | **DESTRUCTIVE** — Remove all Ceph data (requires explicit tag) |

### Cephadm Role Tags (`roles/ceph/tasks/`)

| Tag | Scope | Description |
|-----|-------|-------------|
| `ceph_preflight` | All ceph nodes | Install cephadm, packages, kernel modules |
| `ceph_bootstrap` | Primary MON | Bootstrap cluster with cephadm |
| `ceph_hosts` | Primary MON | Expand cluster to additional hosts |
| `ceph_discover` | OSD hosts | Dynamic volume discovery |
| `ceph_osd` | Primary MON | Deploy OSDs on discovered devices |
| `ceph_pools` | Primary MON | Create pre-defined pools |
| `ceph_keyrings` | Primary MON | Generate client auth keyrings |
| `ceph_services` | Primary MON | Enable dashboard, MDS, prometheus |
| `ceph_validate` | Primary MON | Cluster health report |

---

## Key Variables

### Deployment Mode & Versions (`roles/ceph/defaults/main.yml`)

| Variable | Default | Description |
|----------|---------|-------------|
| `ceph_deploy_mode` | `rook` | `rook` or `cephadm` |
| `ceph_release` | `reef` | Ceph release name |
| `ceph_version` | `18.2.2` | Exact version for binary lookup |
| `ceph_container_image` | `quay.io/ceph/ceph:v18` | Container image for Rook pods |
| `rook_ceph_version` | `v1.14.7` | Rook operator Helm chart version |
| `rook_ceph_namespace` | `rook-ceph` | K8s namespace for all Ceph pods |

### Preflight Cache (`roles/ceph/defaults/main.yml`)

| Variable | Default | Description |
|----------|---------|-------------|
| `ceph_preflight_cache_dir` | `/opt/fabric-cache` | Root cache directory |
| `ceph_preflight_binaries_dir` | `…/binaries` | cephadm binary location |
| `ceph_preflight_images_dir` | `…/images` | Container images (tar) |
| `ceph_preflight_helm_dir` | `…/helm-charts` | Helm chart tarballs |
| `ceph_preflight_apt_dir` | `…/apt-packages` | Apt package cache |

### Cluster Identity (`inventory/group_vars/ceph_mon.yml`)

| Variable | Value | Description |
|----------|-------|-------------|
| `ceph_fsid` | `a1b2c3d4-e5f6-…` | Unique cluster UUID (never change) |
| `ceph_cluster_name` | `dc-lab-ceph` | Cluster name |
| `ceph_public_network` | `172.16.2.0/24` | Client-facing network |
| `ceph_cluster_network` | `172.16.2.0/24` | OSD replication network |
| `ceph_osd_pool_default_size` | `2` | Replica count (2 for lab) |
| `ceph_dashboard_port` | `8443` | Web UI port |

### OSD Configuration (`inventory/group_vars/ceph_osd.yml`)

| Variable | Value | Description |
|----------|-------|-------------|
| `ceph_osd_dynamic_discovery` | `true` | Auto-detect disks via lsblk |
| `ceph_osd_devices_default_kvm` | `[/dev/vdb, /dev/vdc]` | Default OSD devices for KVM |
| `ceph_osd_wipe_disks` | `true` | Wipe disk signatures before OSD create |
| `ceph_bluestore_block_db_size` | `…` | BlueStore DB partition size |

---

## Pools Created

| Pool Name | Application | Size | PGs | Consumer |
|-----------|-------------|------|-----|----------|
| `kube-rbd` | rbd | 2 | 32 | K8s CSI (default StorageClass) |
| `openstack-volumes` | rbd | 2 | 32 | Cinder block volumes |
| `openstack-images` | rbd | 2 | 16 | Glance images |
| `openstack-vms` | rbd | 2 | 32 | Nova ephemeral disks |
| `cephfs-data` | cephfs | 2 | 32 | CephFS data (shared FS) |
| `cephfs-metadata` | cephfs | 2 | 16 | CephFS metadata |
| `infra-storage` | rbd | 3 | 64 | SDLC/infra services |

---

## Preflight Cache Integration

The `preflight_download.yml` playbook (with `--tags ceph`) caches:

| Artifact | Location | Used By |
|----------|----------|---------|
| `cephadm` binary | `/opt/fabric-cache/binaries/cephadm-18.2.2` | preflight.yml (cephadm mode) |
| `rook-ceph-*.tgz` | `/opt/fabric-cache/helm-charts/` | deploy_ceph_rook.yml (operator) |
| `rook-ceph-cluster-*.tgz` | `/opt/fabric-cache/helm-charts/` | deploy_ceph_rook.yml (cluster CR) |

### Cache Lookup Priority (preflight.yml)

1. **Versioned binary** — `/opt/fabric-cache/binaries/cephadm-18.2.2`
2. **Unversioned binary** — `/opt/fabric-cache/binaries/cephadm`
3. **Internet download** — `https://download.ceph.com/rpm-reef/el9/noarch/cephadm`

### Helm Chart Cache (deploy_ceph_rook.yml)

1. **Cached tarball** — `helm upgrade --install rook-ceph /opt/fabric-cache/helm-charts/rook-ceph-*.tgz`
2. **Remote repo** — `helm upgrade --install rook-ceph rook-release/rook-ceph --version v1.14.7`

---

## Day 1 Operations

After initial deployment, use `day1_osd_operations.yml` for incremental changes:

```bash
# Show OSD status vs available devices
ansible-playbook playbooks/ceph_day1_operations.yml \
  -i inventory/hosts.yml -e "ceph_day1_action=status"

# Add newly discovered volumes as OSDs
ansible-playbook playbooks/ceph_day1_operations.yml \
  -i inventory/hosts.yml -e "ceph_day1_action=add"

# Remove a specific OSD (graceful drain + rebalance)
ansible-playbook playbooks/ceph_day1_operations.yml \
  -i inventory/hosts.yml \
  -e "ceph_day1_action=remove ceph_day1_target_host=Host12_2 ceph_day1_target_device=/dev/vdd"

# Rollback (re-add) a removed device
ansible-playbook playbooks/ceph_day1_operations.yml \
  -i inventory/hosts.yml \
  -e "ceph_day1_action=rollback ceph_day1_target_host=Host12_2 ceph_day1_target_device=/dev/vdd"

# Change OSD device class
ansible-playbook playbooks/ceph_day1_operations.yml \
  -i inventory/hosts.yml \
  -e "ceph_day1_action=update ceph_day1_osd_id=5 ceph_day1_device_class=ssd"
```

---

## Validation & Troubleshooting

### Quick Health Check (Rook)

```bash
# From any K8s controller:
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph -s
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph osd tree
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph df
```

### Pod Status

```bash
kubectl get pods -n rook-ceph -o wide
kubectl get cephcluster -n rook-ceph
kubectl get sc   # StorageClasses
```

### Test PVC Binding

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: test-rbd
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: ceph-rbd
  resources:
    requests:
      storage: 1Gi
EOF

kubectl get pvc test-rbd   # Should show Bound
kubectl delete pvc test-rbd
```

### Common Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| OSD pods CrashLoopBackOff | Dirty disks (leftover LVM/partition) | `wipefs -af /dev/vdb && dd if=/dev/zero of=/dev/vdb bs=1M count=100` on host |
| MON not starting | Clock skew between nodes | Verify `chrony` running: `chronyc tracking` |
| PVC stuck Pending | No default StorageClass | `kubectl get sc` — check `ceph-rbd` is default |
| Operator pod not ready | CRDs not installed | `helm upgrade --install rook-ceph … --set crds.enabled=true` |
| `HEALTH_WARN too few PGs` | Pool pg_num too low | `ceph osd pool set <pool> pg_num 64` via toolbox |
| Cephadm role fails with "use deploy_ceph_rook.yml" | `ceph_deploy_mode: rook` | Expected — use Rook playbook instead |

### Teardown (DESTRUCTIVE)

```bash
# Rook teardown (removes ALL Ceph data)
ansible-playbook playbooks/reused/deploy_ceph_rook.yml \
  -i inventory/hosts.yml --tags rook_teardown

# Then wipe disks on OSD nodes
ansible ceph_osd -i inventory/hosts.yml -m shell \
  -a "wipefs -af /dev/vdb /dev/vdc" -b
```

---

## Deployment Sequence in Lab Build

```
deploy_lab_v13.sh sequence:
  ├── 1. Infrastructure (fabric, servers, KVM)
  ├── 2. Kubespray (K8s cluster)
  ├── 3. ► Ceph (this playbook) ◄
  │       ├── preflight_download.yml --tags ceph
  │       └── deploy_ceph_rook.yml
  ├── 4. Infra Pool
  │       └── deploy_ceph_infra_pool.yml
  ├── 5. OpenStack (uses Ceph RBD for Cinder/Glance/Nova)
  └── 6. Monitoring (Prometheus scrapes Ceph MGR metrics)
```

---

## R810 Physical Storage Layer (ubuntu_r810_kvm Profile)

### Host Disk Layout

The Dell PowerEdge R810 that hosts the KVM lab has the following physical disks:

| Device | Size | Role | Notes |
|--------|------|------|-------|
| `/dev/sda` | 465.3 GB | **OS (EXCLUDED)** | Ubuntu 24.04, boot/root partitions |
| `/dev/sdb` | 837.8 GB | OSD backing | Available for Ceph via KVM virtual disks |
| `/dev/sdc` | 931.0 GB | OSD backing | Available for Ceph via KVM virtual disks |
| `/dev/sdd` | 931.0 GB | OSD backing | Available for Ceph via KVM virtual disks |
| `/dev/sde` | 931.0 GB | OSD backing | Available for Ceph via KVM virtual disks |
| `/dev/sdf` | 1.1 TB | OSD backing | Available for Ceph via KVM virtual disks |
| **Total Available** | **~4.6 TB** | | 5 physical disks for Ceph pool |

### Storage Path: Physical → Virtual → Ceph

```
R810 Physical Disk (e.g. /dev/sdb, 838GB)
  └── qcow2 image (e.g. host12-1-osd-01.qcow2, 100GB)
        └── KVM VM sees as /dev/vdb
              └── Rook-Ceph OSD Pod claims device
                    └── BlueStore writes data directly
                          └── Ceph Pool (kube-rbd, openstack-volumes, etc.)
                                └── PVC consumed by PostgreSQL, OpenStack, etc.
```

### How `ceph_rook_use_all_devices` Maximizes Capacity

With `ceph_rook_use_all_devices: true` (default in `roles/ceph/defaults/main.yml`), the Rook operator **automatically discovers and claims** every empty block device on each OSD node — without needing explicit device lists in the inventory.

**What this means in practice:**

1. Provision KVM virtual disks from R810's 5 free physical drives
2. Attach them to any VM in the `ceph_osd` group
3. Rook finds the new device, creates an OSD pod, and expands the pool
4. **No Ansible/inventory change required** — pure capacity scaling

### Capacity Planning

| Allocation Strategy | Usable Ceph Pool (replica=2) | Usable Ceph Pool (replica=3) |
|--------------------|-----------------------------|------------------------------|
| Current (2×vdisk per VM, 6 VMs) | ~600 GB | ~400 GB |
| Maximized (spread all 4.6TB) | ~2.3 TB | ~1.5 TB |
| Balanced (80% of raw to Ceph) | ~1.8 TB | ~1.2 TB |

**Recommended for lab:** Allocate ~80% of each physical disk as KVM qcow2 for OSD backing, leaving 20% for host snapshots and overhead.

### Provisioning More Virtual Disks

To add more OSD capacity, create additional qcow2 images and attach to VMs:

```bash
# On R810 host (example: add 200GB disk to Host12_1)
qemu-img create -f qcow2 /var/lib/libvirt/images/host12-1-osd-03.qcow2 200G
virsh attach-disk Host12_1 /var/lib/libvirt/images/host12-1-osd-03.qcow2 vdd \
  --driver qemu --subdriver qcow2 --persistent

# Rook auto-discovers /dev/vdd and creates a new OSD pod — no playbook re-run needed
```

### Device Discovery Modes (Rook Template Logic)

The `rook-ceph-cluster-values.yml.j2` template supports two modes:

| Variable | Behavior | When to Use |
|----------|----------|-------------|
| `ceph_rook_use_all_devices: true` | Rook scans all nodes, claims every empty block device | Default — maximizes capacity, zero-config scaling |
| `ceph_rook_use_all_devices: false` | Uses per-host `ceph_osd_devices` from inventory | When you need precise control over which disks are OSDs |

Optional filter: `ceph_rook_device_filter: "^vd[b-z]$"` limits discovery to specific device name patterns.

---

## KVM-Specific Optimizations

| Setting | KVM Value | Production Value | Rationale |
|---------|-----------|------------------|-----------|
| Pool replica size | 2 | 3 | Fewer hosts in lab |
| MON count | 2 | 3-5 | Minimum quorum |
| OSD memory target | 1 GiB | 4+ GiB | Limited host RAM |
| MGR pod memory | 1 GiB | 2+ GiB | Reduced workload |
| PG autoscale | on | on | Same for both |
| Device discovery | `ceph_rook_use_all_devices: true` | per-host lists | Auto-claim all empty disks |
| Device filter | `""` (all devices) | `"^sd[b-z]$"` | Broader in lab, restrictive in prod |
| Network | single (172.16.2.0/24) | dual (public+cluster) | Single flat network |
| Control-plane toleration | yes | per-policy | Controllers are also OSDs |
| R810 backing disks | sdb–sdf (4.6TB total) | N/A | Physical storage pool for VMs |
