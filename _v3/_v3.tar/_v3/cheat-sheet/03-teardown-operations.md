# Teardown Operations

## Guardrail Requirement
Full teardown is blocked unless both variables are provided:
- `allow_destructive_teardown=true`
- `teardown_confirmation_token=YES-TEARDOWN-ALL`

## Full Environment Teardown

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/teardown_full_environment.yml -e allow_destructive_teardown=true -e teardown_confirmation_token=YES-TEARDOWN-ALL`

Wrapper command:

`bash ../deploy_lab_v3.sh teardown --ansible-arg=-e --ansible-arg=allow_destructive_teardown=true --ansible-arg=-e --ansible-arg=teardown_confirmation_token=YES-TEARDOWN-ALL`

## Tier-specific Teardown

Gateway teardown only:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/teardown_openstack_gateways.yml`

Premium firewall teardown only:

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/teardown_premium_firewall.yml`
