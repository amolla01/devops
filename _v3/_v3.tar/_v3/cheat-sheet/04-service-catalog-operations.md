# Service Catalog Operations

## Service Classes
- Dedicated Hosting Service
- Shared Hosting Service
- VM Only Service
- K8 Cluster Service
- Premium Firewall Service (advanced add-on)

## Control Points
- OpenStack controllers define tenant intent and policy.
- OpenStack gateways enforce north-south data path.
- Premium firewall service applies advanced policy when subscribed.

## Validation Command

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_service_catalog.yml`

## Operational Note
Native OpenStack security remains baseline.
Premium firewall is an additional service tier and should be lifecycle-driven by tenant subscription state.
