# Deployment Operations

## Profile Selection
Set the automation profile before running (defaults to `ubuntu_r810_kvm` if unset):
```
export AUTOMATION_PROFILE=ubuntu_r810_kvm   # or ubuntu_r620_kvm, win11_kvm, real_hardware
```
Or pass `--profile <name>` to deploy_lab_v3.sh.

## KVM VS vs Real Hardware — Port Breakout

**Critical**: SONiC KVM VS (`x86_64-kvm_x86_64-r0`) does **NOT** support port breakout.
Only interface names listed in the platform's `port_config.ini` are valid.

| Platform (hwsku) | Valid port names on KVM VS | Step |
|------------------|---------------------------|------|
| Arista-7050QX-32S | Ethernet0, 4, 8, 12, …, 124 | +4 |
| Arista-7050-QX32 | Ethernet0, 4, 8, 12, …, 124 | +4 |
| Seastone-DX010 | Ethernet0, 4, 8, 12, …, 124 | +4 |
| Accton-AS5712-54X | Ethernet0–47 (SFP+), 48–71 (QSFP+) | +1 |

**Breakout sub-port names like `Ethernet1`, `Ethernet2`, `Ethernet3` are INVALID on KVM VS.**

### Port mapping by mode

**KVM VS mode** (`is_kvm: true`) — uses native QSFP+ ports:
```
Border_Leaf → servers:   Ethernet0, Ethernet4, Ethernet8  (QSFP+5/6/7)
Border_Leaf → exit:      Ethernet12                       (QSFP+8)
Leaf_L3/L4  → servers:   Ethernet0, Ethernet4            (QSFP+1/2)
Leaf_L1/L2  → servers:   Ethernet0, Ethernet1, Ethernet2 (SFP+ native, valid on AS5712)
```

**Real hardware mode** — uses 4×10G breakout sub-ports:
```
Border_Leaf → servers:   Ethernet0, Ethernet1, Ethernet2 (breakout of QSFP+5)
Border_Leaf → exit:      Ethernet3                        (breakout of QSFP+5)
Leaf_L3/L4  → servers:   Ethernet0, Ethernet1            (breakout of QSFP+1)
Leaf_L1/L2  → servers:   Ethernet0, Ethernet1, Ethernet2 (SFP+ native, same as KVM)
```

### Why Ethernet0 works on both modes
`Ethernet0` exists in port_config.ini as the first native QSFP+ port AND is reused as
the first sub-port name after breakout. So it succeeds in both KVM and real hardware.
`Ethernet1/2/3` only exist AFTER breakout creates them — which KVM VS cannot do.

### Diagnosis
If `config interface startup EthernetN` fails with "Interface name is invalid":
1. SSH to the switch: `show interfaces status | grep EthernetN`
2. Check available ports: `sonic-cfggen -d --var-json PORT | python3 -m json.tool | grep name`
3. Verify port_config.ini: `cat /usr/share/sonic/device/x86_64-kvm_x86_64-r0/*/port_config.ini`

## Full Environment Deployment

`ansible-playbook -i ../inventory/hosts.yml ../playbooks/deploy_full_environment.yml`

Orchestrated KVM setup + full services:

`bash ../deploy_lab_v3.sh --profile ubuntu_r810_kvm full`

Phase-by-phase expansion:

`bash ../deploy_lab_v3.sh phase-r620`

`bash ../deploy_lab_v3.sh phase-r810`

`bash ../deploy_lab_v3.sh phased-full`

## Deployment Order (End-to-End)

The correct deployment sequence from bare metal to running services:

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Phase 0: KVM Topology (skip for real hardware)                         │
│    deploy_lab_v3.sh --profile ubuntu_r810_kvm kvm-deploy                │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 1: Day-0 Base Provisioning                                       │
│    deploy_day0.yml                                                      │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 2: Day-1 Fabric Wiring (BGP underlay)                            │
│    deploy_day1.yml                                                      │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 3: Leaf↔Server BGP + Server Networking                           │
│    deploy_leaf_server_bgp.yml → deploy_server_networking.yml            │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 4: EVPN Overlay                                                  │
│    deploy_sonic_evpn.yml → deploy_evpn_overlay.yml                      │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 5: Infrastructure Services                                       │
│    deploy_kubespray.yml → deploy_postgresql.yml → deploy_maas.yml       │
│    → deploy_ceph.yml → deploy_openstack_helm.yml → deploy_monitoring.yml│
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 6: Application Services                                          │
│    deploy_openstack_gateways.yml → deploy_premium_firewall.yml          │
│    → deploy_sheba_cloud_infra.yml                                       │
├─────────────────────────────────────────────────────────────────────────┤
│  Phase 7: OVN BGP Agent (after OpenStack is running)                    │
│    deploy_bgp_agent.yml                                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Playbook Reference (All Playbooks)

### Day-0 / Day-1 Fabric

#### `deploy_day0.yml` — Unified Day-0 Base Provisioning

| Property | Value |
|----------|-------|
| **Targets** | `sonic_switches`, `exit_routers`, `servers` (3 plays) |
| **Tags** | `preflight`, `render`, `validate`, `push`, `reload`, `deploy`, `hardening`, `backup`, `verify` |
| **Prerequisites** | KVM topology deployed (VMs running and SSH-reachable) |

Handles initial device provisioning for all device types. Renders SONiC `config_db.json`, applies management IP/hostname, configures SSH, installs base packages on servers, and provisions MikroTik exit routers.

```bash
# Full run (all devices)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml

# Only spines first, then leaves (recommended order)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml --limit spines
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml --limit leaves

# Validate rendered config only (no push)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml --tags render,validate

# Verify post-deployment state
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml --tags verify
```

---

#### `deploy_day1.yml` — Day-1 Fabric Wiring (BGP)

| Property | Value |
|----------|-------|
| **Targets** | `sonic_switches`, `exit_routers`, `servers` (3 plays) |
| **Tags** | `preflight`, `deploy`, `interfaces`, `bgp`, `verify` |
| **Prerequisites** | `deploy_day0.yml` completed successfully |

Configures eBGP underlay across the entire fabric:
- **SONiC switches**: Enables uplink/downlink interfaces, configures eBGP unnumbered with IPv6 link-local
- **MikroTik exit routers**: Configures numbered eBGP peering (IPv4 /31) to border leaves
- **Ubuntu servers**: Applies Netplan bonds + FRR eBGP unnumbered to leaf pairs

```bash
# Full fabric wiring
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day1.yml

# Fix only exit router BGP (after KVM interface fix)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day1.yml --limit exit_routers --tags deploy

# Verify all BGP sessions
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day1.yml --tags verify
```

---

### Underlay BGP (Leaf↔Server)

#### `deploy_leaf_server_bgp.yml` — Leaf Switch Downlink BGP

| Property | Value |
|----------|-------|
| **Targets** | `leaves:border_leaves` |
| **Tags** | — |
| **Prerequisites** | `deploy_day1.yml` (SONiC switches have uplink BGP established) |

Enables leaf-side downlink ports (MTU 9000) and configures eBGP unnumbered sessions to multi-homed compute servers. This is the **switch side** of leaf↔server peering.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_leaf_server_bgp.yml
```

---

#### `deploy_server_networking.yml` — Server-Side Fabric + FRR BGP

| Property | Value |
|----------|-------|
| **Targets** | `servers` |
| **Tags** | `resolve`, `verify` |
| **Prerequisites** | `deploy_leaf_server_bgp.yml` (leaf downlinks active) |

Configures the **server side** of leaf↔server peering:
1. Resolves fabric interface names (profile-aware: KVM vs real hardware)
2. Detects actual NIC names on the server (auto-remap)
3. Brings up interfaces with MTU 9000
4. Installs FRR, enables `bgpd`, deploys `frr.conf` (BGP unnumbered)
5. Verifies loopback + fabric links are UP

```bash
# Deploy all server networking
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_server_networking.yml

# Verify only (check interfaces + BGP state)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_server_networking.yml --tags verify
```

---

### EVPN Overlay

#### `deploy_sonic_evpn.yml` — Enable EVPN on SONiC Switches

| Property | Value |
|----------|-------|
| **Targets** | `leaves:border_leaves` (Play 1), `spines` (Play 2) |
| **Tags** | `validate`, `check`, `apply`, `verify` |
| **Prerequisites** | `deploy_leaf_server_bgp.yml` (BGP sessions established), `sonic_fabric` role ran |

Activates `l2vpn evpn` address-family on ALL BGP neighbors across SONiC switches:
- Leaves: Relay EVPN Type-2/5 routes between hypervisors and spines, `advertise-all-vni`
- Spines: Pass EVPN NLRI between leaves (route reflector behavior, no VXLAN termination)
- Configures VXLAN tunnel source (loopback) on leaves

```bash
# Enable EVPN on all switches
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sonic_evpn.yml

# Verify EVPN route reception
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sonic_evpn.yml --tags verify
```

---

#### `deploy_evpn_overlay.yml` — EVPN-to-the-Host Overlay

| Property | Value |
|----------|-------|
| **Targets** | `evpn_hypervisors` |
| **Tags** | — |
| **Prerequisites** | `deploy_server_networking.yml` + `deploy_sonic_evpn.yml` |

Deploys symmetric IRB (RFC 8365) EVPN overlay directly on hypervisor servers:
- L2VNI per tenant subnet, L3VNI per tenant VRF
- VXLAN tunnels, anycast gateway, ARP/ND suppression
- FRR EVPN Type-2 (MAC/IP) and Type-5 (IP prefix) advertisements

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_evpn_overlay.yml
```

---

#### `deploy_bgp_agent.yml` — OVN BGP Agent (Phase 2 EVPN)

| Property | Value |
|----------|-------|
| **Targets** | `evpn_hypervisors` |
| **Tags** | `install`, `configure`, `verify`, `uninstall` |
| **Prerequisites** | `deploy_evpn_overlay.yml` + `deploy_openstack_helm.yml` (OVN SB DB accessible) |

Installs the OpenStack OVN BGP Agent as a systemd service on hypervisors. The agent watches OVN Southbound DB for port binding events and automatically advertises/withdraws VM MAC/IP via EVPN Type-2 routes — providing **dynamic** route advertisement (vs static overlay in Phase 1).

```bash
# Install and configure
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_bgp_agent.yml

# Verify agent is running and advertising routes
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_bgp_agent.yml --tags verify

# Remove agent (rollback to static overlay)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_bgp_agent.yml --tags uninstall
```

---

### Infrastructure Services

#### `deploy_kubespray.yml` — Kubernetes Cluster via KubeSpray

| Property | Value |
|----------|-------|
| **Targets** | `localhost` (Phases 1, 2, 4), `HostB12_1` (Phases 3, 5) |
| **Tags** | `prereqs`, `generate`, `prepare`, `deploy`, `verify` |
| **Prerequisites** | HostB12_1 reachable via SSH, Python3/pip/git installed |

Deploys a single-node Kubernetes cluster on HostB12_1 using KubeSpray:
1. Installs prereqs (venv, kubespray clone)
2. Generates KubeSpray inventory from Ansible vars
3. Prepares target node (swap off, kernel modules, sysctl)
4. Runs KubeSpray `cluster.yml`
5. Verifies cluster health (`kubectl get nodes`)

```bash
# Full deployment
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_kubespray.yml

# Only install prereqs
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_kubespray.yml --tags prereqs

# Verify cluster is healthy
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_kubespray.yml --tags verify
```

---

#### `kubespray_day1_operations.yml` — K8s Node Lifecycle (Day 1+)

| Property | Value |
|----------|-------|
| **Targets** | `localhost` |
| **Tags** | — (action-driven via `-e k8s_day1_action=<action>`) |
| **Prerequisites** | `deploy_kubespray.yml` completed |

Provides incremental node lifecycle management after initial deployment. NOT for initial install — use `deploy_kubespray.yml` for that.

```bash
# Check cluster status
ansible-playbook -i inventory/hosts.yml playbooks/reused/kubespray_day1_operations.yml \
  -e "k8s_day1_action=status"

# Add worker nodes
ansible-playbook -i inventory/hosts.yml playbooks/reused/kubespray_day1_operations.yml \
  -e "k8s_day1_action=add_node k8s_day1_target_hosts=Host12_2,Host12_3"

# Remove a node (drain + delete)
ansible-playbook -i inventory/hosts.yml playbooks/reused/kubespray_day1_operations.yml \
  -e "k8s_day1_action=remove_node k8s_day1_target_hosts=Host12_3"

# Upgrade cluster version
ansible-playbook -i inventory/hosts.yml playbooks/reused/kubespray_day1_operations.yml \
  -e "k8s_day1_action=upgrade k8s_day1_target_version=v1.30.2"

# Reset a node (wipe K8s state for reuse)
ansible-playbook -i inventory/hosts.yml playbooks/reused/kubespray_day1_operations.yml \
  -e "k8s_day1_action=reset_node k8s_day1_target_hosts=Host12_4"
```

---

#### `deploy_postgresql.yml` — PostgreSQL via Helm

| Property | Value |
|----------|-------|
| **Targets** | `HostB12_1` |
| **Tags** | `prereqs`, `deploy`, `verify`, `teardown` (never) |
| **Prerequisites** | `deploy_kubespray.yml` completed, Helm 3 available |

Deploys a single PostgreSQL instance using the Bitnami Helm chart. Serves as the database backend for MaaS and other infrastructure services.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_postgresql.yml

# Verify PostgreSQL is accepting connections
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_postgresql.yml --tags verify

# Teardown (destructive — requires explicit tag)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_postgresql.yml --tags teardown
```

---

#### `deploy_maas.yml` — MaaS Region + Rack Controller

| Property | Value |
|----------|-------|
| **Targets** | `HostB12_1` |
| **Tags** | `prereqs`, `deploy`, `configure`, `verify`, `teardown` (never) |
| **Prerequisites** | `deploy_kubespray.yml` + `deploy_postgresql.yml` completed |

Deploys Metal-as-a-Service using Helm charts on K8s:
- **Region Controller**: API, Web UI, DNS, database management
- **Rack Controller**: DHCP, TFTP, PXE boot, BMC proxy for bare-metal provisioning

```bash
# Full deployment
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_maas.yml

# Only configure (post-deploy network settings, images, etc.)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_maas.yml --tags configure
```

---

#### `deploy_ceph.yml` — Ceph Storage Cluster via Cephadm

| Property | Value |
|----------|-------|
| **Targets** | `ceph_mon:ceph_osd:storage_servers` |
| **Tags** | `ceph`, `ceph_preflight`, `ceph_validate` |
| **Prerequisites** | `deploy_kubespray.yml` completed, block devices available on OSD nodes |

Deploys a Ceph Reef (v18) cluster using cephadm orchestrator:
- Phase A: Preflight checks (disks, connectivity)
- Phase B: Bootstrap first MON
- Phase C: Expand (add MONs, MGRs, OSDs)
- Phase D: Create pools + export keyrings
- Phase E: Deploy RGW/MDS services
- Phase F: Validate cluster health

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_ceph.yml

# Preflight only
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_ceph.yml --tags ceph_preflight

# Validate cluster health
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_ceph.yml --tags ceph_validate
```

---

#### `deploy_ceph_infra_pool.yml` — Ceph 'infra-storage' Pool + K8s StorageClass

| Property | Value |
|----------|-------|
| **Targets** | `ceph_controllers[0]` (Phase A), `k8_controllers[0]` (Phase B) |
| **Tags** | `ceph_infra_pool`, `create_pool`, `k8s_storage`, `validate` |
| **Prerequisites** | `deploy_ceph.yml` + `deploy_kubespray.yml` completed |

Creates a dedicated Ceph RBD pool `infra-storage` and provisions the K8s StorageClass `ceph-infra-rbd` for the `sheba-cloud-infra` namespace.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_ceph_infra_pool.yml
```

---

#### `deploy_openstack_helm.yml` — OpenStack via Helm on Kubernetes

| Property | Value |
|----------|-------|
| **Targets** | `kube_controllers[0]` |
| **Tags** | `osh`, `osh_preflight`, `osh_infra`, `osh_identity`, `osh_storage`, `osh_compute`, `osh_network`, `osh_dashboard`, `osh_validate`, `osh_day2` |
| **Prerequisites** | `deploy_kubespray.yml` + `deploy_ceph.yml` completed, Helm 3 + kubectl configured |

Production-grade deployment of OpenStack Caracal (2024.1) using OpenStack-Helm:
- Infra: RabbitMQ, Memcached, MariaDB
- Identity: Keystone
- Storage: Glance + Cinder (Ceph-backed)
- Compute: Nova + Placement
- Network: Neutron + OVN
- Dashboard: Horizon

```bash
# Full OpenStack deployment
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_openstack_helm.yml

# Deploy only network services
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_openstack_helm.yml --tags osh_network

# Validate all services healthy
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_openstack_helm.yml --tags osh_validate

# Day-2 operations (rolling upgrades, scale)
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_openstack_helm.yml --tags osh_day2
```

---

#### `deploy_monitoring.yml` — Prometheus + Grafana Monitoring

| Property | Value |
|----------|-------|
| **Targets** | `kube_controllers[0]` |
| **Tags** | `monitoring` |
| **Prerequisites** | `deploy_kubespray.yml` completed, Helm installed |

Deploys the complete observability stack:
- Prometheus (metrics + alerting rules)
- Grafana (dashboards for Ceph, Node, OpenStack, K8s)
- Node Exporter, Ceph Exporter, OpenStack Exporter
- Alertmanager (alert routing and notification)

**Access URLs after deployment:**
- Grafana: `http://<controller-ip>:30300`
- Prometheus: `http://<controller-ip>:30900`

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_monitoring.yml
```

---

### Application Services

#### `deploy_openstack_gateways.yml` — OpenStack Gateway Nodes

| Property | Value |
|----------|-------|
| **Targets** | `openstack_gateways` |
| **Tags** | — |
| **Prerequisites** | `deploy_openstack_helm.yml` completed |

Configures dedicated OpenStack gateway nodes for external network access (provider networks, floating IPs, L3 routing). _v3-native playbook.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/deploy_openstack_gateways.yml
```

---

#### `deploy_premium_firewall.yml` — Premium Firewall Service Tier

| Property | Value |
|----------|-------|
| **Targets** | `premium_firewall_nodes` |
| **Tags** | — |
| **Prerequisites** | `deploy_openstack_helm.yml` completed |

Deploys advanced firewall service tier beyond native OpenStack security groups. Models premium network security as a monetizable service-catalog item. _v3-native playbook.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/deploy_premium_firewall.yml
```

---

#### `deploy_service_catalog.yml` — Service Catalog Validation

| Property | Value |
|----------|-------|
| **Targets** | `localhost` |
| **Tags** | — |
| **Prerequisites** | All services deployed |

Validates the complete service catalog is operational. Runs health checks across all deployed components and reports readiness status.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/deploy_service_catalog.yml
```

---

#### `deploy_sheba_cloud_infra.yml` — Full Cloud Infrastructure Orchestrator

| Property | Value |
|----------|-------|
| **Targets** | (imports sub-playbooks) |
| **Tags** | `ceph_infra_pool`, `sheba_infra`, `sheba_sdlc` |
| **Prerequisites** | `deploy_kubespray.yml` + `deploy_ceph.yml` + `deploy_openstack_helm.yml` |

Master orchestrator that deploys the complete 'sheba-cloud-infra' platform in 3 phases:
1. Ceph infra-storage pool + K8s StorageClass
2. Core infrastructure (PostgreSQL, Redis, Gitea, Harbor, OpenBao, MinIO)
3. SDLC & developer tools (Plane, Tekton, ArgoCD, SonarQube, BookStack, Mattermost, Grafana, Loki, Jaeger)

```bash
# Full platform
ansible-playbook -i inventory/hosts.yml playbooks/deploy_sheba_cloud_infra.yml

# Only infrastructure services
ansible-playbook -i inventory/hosts.yml playbooks/deploy_sheba_cloud_infra.yml --tags sheba_infra

# Only SDLC tools
ansible-playbook -i inventory/hosts.yml playbooks/deploy_sheba_cloud_infra.yml --tags sheba_sdlc
```

---

#### `deploy_sheba_infra_services.yml` — Core Infrastructure Services (Helm)

| Property | Value |
|----------|-------|
| **Targets** | `k8_controllers[0]` |
| **Tags** | `sheba_infra`, `postgresql`, `redis`, `gitea`, `harbor`, `openbao`, `minio`, `validate` |
| **Prerequisites** | `deploy_ceph_infra_pool.yml` (StorageClass `ceph-infra-rbd` available) |

Deploys core infrastructure Helm charts into the `sheba-cloud-infra` K8s namespace:
- **PostgreSQL** — Relational database for Gitea, Plane, SonarQube
- **Redis** — Session cache and message broker
- **Gitea** — Self-hosted Git (code hosting)
- **Harbor** — Container registry with vulnerability scanning
- **OpenBao** — Secrets management (HashiCorp Vault fork)
- **MinIO** — S3-compatible object storage

```bash
# Deploy all infrastructure services
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sheba_infra_services.yml

# Deploy only Harbor
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sheba_infra_services.yml --tags harbor

# Validate all services healthy
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sheba_infra_services.yml --tags validate
```

---

#### `deploy_sheba_sdlc_services.yml` — SDLC & Developer Tools (Helm)

| Property | Value |
|----------|-------|
| **Targets** | `k8_controllers[0]` |
| **Tags** | `sheba_sdlc`, `plane`, `tekton`, `argocd`, `sonarqube`, `bookstack`, `mattermost`, `grafana`, `loki`, `jaeger`, `validate` |
| **Prerequisites** | `deploy_sheba_infra_services.yml` completed |

Deploys developer productivity and SDLC services:
- **Plane** — Project management (Jira alternative)
- **Tekton** — CI/CD pipelines (cloud-native)
- **ArgoCD** — GitOps continuous deployment
- **SonarQube** — Code quality and security scanning
- **BookStack** — Documentation wiki
- **Mattermost** — Team communication (Slack alternative)
- **Grafana + Loki** — Log aggregation and dashboards
- **Jaeger** — Distributed tracing

```bash
# Deploy all SDLC services
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sheba_sdlc_services.yml

# Deploy only ArgoCD
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sheba_sdlc_services.yml --tags argocd
```

---

### Utility Playbooks

#### `set_interface_properties.yml` — SONiC Interface Admin/MTU/Speed/FEC

| Property | Value |
|----------|-------|
| **Targets** | `sonic_switches` |
| **Tags** | `deploy`, `validate`, `admin`, `mtu`, `speed`, `fec`, `persist`, `verify` |
| **Prerequisites** | `deploy_day0.yml` (switches provisioned) |

Operational utility for bulk interface property changes across all SONiC switches. Reads interfaces from host_vars (`fabric_interfaces`, `uplink_interfaces`, `downlink_interfaces`) and sets admin_status, MTU, speed, and FEC mode.

```bash
# Set all properties
ansible-playbook -i inventory/hosts.yml playbooks/reused/set_interface_properties.yml

# Only set MTU
ansible-playbook -i inventory/hosts.yml playbooks/reused/set_interface_properties.yml --tags mtu

# Verify current state matches desired
ansible-playbook -i inventory/hosts.yml playbooks/reused/set_interface_properties.yml --tags verify
```

---

### Teardown Playbooks

> **WARNING**: Teardown playbooks are destructive and require explicit confirmation tokens.

#### `teardown_full_environment.yml` — Full Environment Teardown

| Property | Value |
|----------|-------|
| **Targets** | `localhost` |
| **Guard** | Requires `-e allow_destructive_teardown=true -e teardown_confirmation_token=YES-TEARDOWN-ALL` |

Tears down ALL deployed components in reverse order. **Irreversible.**

```bash
ansible-playbook -i inventory/hosts.yml playbooks/teardown_full_environment.yml \
  -e allow_destructive_teardown=true \
  -e teardown_confirmation_token=YES-TEARDOWN-ALL
```

---

#### `teardown_openstack_gateways.yml` — Remove Gateway Nodes

| Property | Value |
|----------|-------|
| **Targets** | `openstack_gateways` |

Removes OpenStack gateway configuration and drains external network attachments.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/teardown_openstack_gateways.yml
```

---

#### `teardown_premium_firewall.yml` — Remove Firewall Service

| Property | Value |
|----------|-------|
| **Targets** | `premium_firewall_nodes` |

Removes premium firewall service tier and cleans up associated network policies.

```bash
ansible-playbook -i inventory/hosts.yml playbooks/teardown_premium_firewall.yml
```

---

## Deploy by Category (Quick Reference)

### KVM Topology

```bash
# Local hypervisor
bash deploy_lab_v3.sh --profile ubuntu_r810_kvm kvm-deploy

# Remote hypervisors
bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 kvm-deploy-r620
bash deploy_lab_v3.sh --r810-host admin@10.1.1.21 kvm-deploy-r810
bash deploy_lab_v3.sh --r620-host admin@10.1.1.20 --r810-host admin@10.1.1.21 kvm-deploy-both
```

### Fabric Underlay

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day0.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_day1.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_leaf_server_bgp.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_server_networking.yml
```

### EVPN Overlay

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_sonic_evpn.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_evpn_overlay.yml
```

### Infrastructure + Platform

```bash
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_kubespray.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_postgresql.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_maas.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_ceph.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_openstack_helm.yml
ansible-playbook -i inventory/hosts.yml playbooks/reused/deploy_monitoring.yml
```

### Application + Gateway

```bash
ansible-playbook -i inventory/hosts.yml playbooks/deploy_openstack_gateways.yml
ansible-playbook -i inventory/hosts.yml playbooks/deploy_premium_firewall.yml
ansible-playbook -i inventory/hosts.yml playbooks/deploy_sheba_cloud_infra.yml
```

### Full Stack (Single Command)

```bash
ansible-playbook -i inventory/hosts.yml playbooks/deploy_full_environment.yml
```

---

## Common Tag Patterns

| Goal | Command Suffix |
|------|----------------|
| Pre-flight checks only | `--tags preflight` |
| Verify current state | `--tags verify` |
| Deploy without verification | `--tags deploy` |
| Render + validate (dry-run) | `--tags render,validate` |
| Target specific device group | `--limit spines` / `--limit exit_routers` / `--limit servers` |

## Troubleshooting Quick Checks

```bash
# Check which interfaces exist on a SONiC KVM switch
ansible -i inventory/hosts.yml Leaf_L1 -m shell -a "sonic-cfggen -d --var-json PORT | python3 -m json.tool | grep name"

# Check BGP summary on any SONiC switch
ansible -i inventory/hosts.yml sonic_switches -m shell -a "vtysh -c 'show bgp summary'"

# Check FRR on a server
ansible -i inventory/hosts.yml Host12_1 -m shell -a "vtysh -c 'show bgp summary'" --become

# Check MikroTik BGP on exit router
ansible -i inventory/hosts.yml exit_routers -m community.routeros.command -a "commands='/routing/bgp/session/print'"

# Verify EVPN routes
ansible -i inventory/hosts.yml leaves -m shell -a "vtysh -c 'show bgp l2vpn evpn summary'"
```
