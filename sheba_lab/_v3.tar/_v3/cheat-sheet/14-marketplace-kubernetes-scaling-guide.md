# Auto Parts Marketplace — Kubernetes Scaling Guide

> Companion document to `13-openstack-auto-parts-marketplace-architecture.html`  
> Covers: HPA + Rancher deployment, seasonal scaling, and operational runbook.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│  OPENSTACK NOVA VMs (R810 Hypervisor, 172.16.2.1)      │
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │         KUBERNETES (KubeSpray v2.25.0)           │ │
│  │                                                   │ │
│  │  Rancher ──▶ HPA Controller ──▶ Deployments      │ │
│  │       │         ▲                                 │ │
│  │       │    metrics-server                         │ │
│  │       │                                           │ │
│  │  ┌────┴──────────────────────────────────────┐   │ │
│  │  │  marketplace namespace                    │   │ │
│  │  │  • MedusaJS (2-10 pods, HPA)            │   │ │
│  │  │  • Typesense (1-3 pods, HPA)            │   │ │
│  │  │  • Lago API (1-4 pods, HPA)             │   │ │
│  │  │  • PostgreSQL (1 pod, VPA)              │   │ │
│  │  │  • Redis (1 pod, fixed)                 │   │ │
│  │  │  • RabbitMQ (1 pod, KEDA Year 2)        │   │ │
│  │  │  • Pimcore (1-2 pods, HPA)             │   │ │
│  │  └───────────────────────────────────────────┘   │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  Local Registry: 172.16.2.1:5000                       │
│  Cache: /opt/fabric-cache/marketplace/                 │
└─────────────────────────────────────────────────────────┘
```

---

## Deployment Playbooks

| Playbook | Purpose | Internet? |
|----------|---------|-----------|
| `preflight_marketplace.yml` | Download images, Helm charts, deps | Yes (one-time) |
| `deploy_marketplace.yml` | Push to registry → Helm → HPA → Rancher | No (air-gapped) |

### Running the Playbooks

```bash
# Step 1: Preflight (internet-connected deployer)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/preflight_marketplace.yml -v

# Step 2: Deploy (air-gapped, targets K8s cluster)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml -v

# Step 2b: Deploy specific phases
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags registry -v

ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags scaling -v
```

---

## HPA Policies

### MedusaJS (Commerce Engine)
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: medusa-hpa
  namespace: marketplace
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: medusa
  minReplicas: 2          # Adjust per season (see below)
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Pods
        value: 2
        periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Pods
        value: 1
        periodSeconds: 120
```

### Typesense (Search Engine)
- **Primary metric:** Memory (search index is memory-bound)
- **Min/Max:** 1–3 pods
- **Scale-up window:** 120s (slower — search nodes need time to sync)
- **Scale-down window:** 600s (aggressive scale-down risks cold cache)

### Lago API (Billing)
- **Primary metric:** CPU 75% (transaction processing is CPU-bound)
- **Min/Max:** 1–4 pods
- **Scale-up window:** 30s (fast — checkout bursts are sudden)
- **Scale-down window:** 600s (keep capacity for follow-up invoicing)

---

## Seasonal Scaling Calendar

| Season | Months | Traffic | MedusaJS min | Action |
|--------|--------|---------|--------------|--------|
| 🌱 Spring | Mar–May | +40% | 3 | Brake pads, filters, wipers |
| ☀️ Summer | Jun–Aug | Baseline | 2 | AC parts, road trip prep |
| 🍂 Fall | Sep–Nov | +80% | 4 | Black Friday, winter tires |
| ❄️ Winter | Dec–Feb | +30% | 3 | Batteries, starters, snow |

### Implementing Seasonal Changes

**Option A: Manual (via Rancher UI)**
1. Navigate to Rancher → marketplace → HPA
2. Edit `medusa-hpa` → Set `minReplicas` per season
3. Click "Save" — HPA controller immediately respects new minimum

**Option B: CronJob (automated)**
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: seasonal-scaler
  namespace: marketplace
spec:
  # March 1st — spring scaling begins
  schedule: "0 0 1 3 *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: scaler
            image: bitnami/kubectl:latest
            command:
            - /bin/sh
            - -c
            - |
              kubectl patch hpa medusa-hpa -n marketplace \
                --type='merge' \
                -p '{"spec":{"minReplicas":3}}'
          restartPolicy: OnFailure
```

---

## Monitoring & Observability

| Tool | Namespace | Access | Purpose |
|------|-----------|--------|---------|
| Rancher | cattle-system | `https://rancher.marketplace.local` | Cluster management, HPA visualization |
| Prometheus | monitoring | `kubectl port-forward svc/prometheus-server 9090:80 -n monitoring` | Metrics collection |
| Grafana | monitoring | `kubectl port-forward svc/grafana 3000:80 -n monitoring` | Dashboards |

### Key Metrics to Watch

| Metric | Alert Threshold | Action |
|--------|-----------------|--------|
| `container_cpu_usage_seconds_total` | >85% sustained 5min | HPA should scale (verify) |
| `container_memory_working_set_bytes` | >90% of limit | Pod OOMKill risk → increase limits |
| `kube_hpa_status_current_replicas` | == maxReplicas for 10min | Cluster capacity issue, add nodes |
| `node_memory_MemAvailable_bytes` | <1Gi per node | Need more worker VMs (Heat or manual) |

---

## Troubleshooting

### HPA Not Scaling

```bash
# Check metrics-server is working
kubectl top pods -n marketplace

# Check HPA status
kubectl get hpa -n marketplace
kubectl describe hpa medusa-hpa -n marketplace

# Common issues:
# 1. metrics-server not deployed → no CPU/Mem data
# 2. Resource requests not set on Deployment → HPA can't calculate utilization %
# 3. minReplicas == maxReplicas → HPA disabled effectively
```

### Rancher Not Accessible

```bash
# Check Rancher pods
kubectl get pods -n cattle-system

# Check Rancher ingress
kubectl get ingress -n cattle-system

# Port-forward if ingress not configured
kubectl port-forward svc/rancher 8443:443 -n cattle-system
```

### Pod Stuck in Pending (No Capacity)

```bash
# Check node resources
kubectl describe nodes | grep -A 5 "Allocated resources"

# If all nodes are full:
# Option 1: Reduce HPA maxReplicas
# Option 2: Add worker node (OpenStack Nova VM)
# Option 3: Reduce resource requests (risky)
```

---

## Decision Log

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-06 | KubeSpray + Rancher over Magnum | Simpler, air-gapped, no OpenStack integration needed |
| 2026-06 | HPA over manual scaling | Automated, handles unpredictable spikes |
| 2026-06 | VPA for PostgreSQL (not HPA) | Databases can't horizontally scale trivially |
| 2026-06 | KEDA deferred to Year 2 | Adds complexity; CPU-based HPA sufficient for now |
| 2026-06 | Rancher over ArgoCD/Flux | Non-DevOps staff need UI; Rancher includes GitOps anyway |

---

## Future Enhancements (Year 2+)

- [ ] KEDA for RabbitMQ queue-depth scaling (Lago billing pods)
- [ ] Cluster Autoscaler with OpenStack cloud provider (add/remove worker VMs)
- [ ] Rancher Fleet for multi-cluster GitOps (prod + DR site)
- [ ] VPA (Vertical Pod Autoscaler) for PostgreSQL and Redis
- [ ] Custom Prometheus metrics for business KPIs (orders/min → trigger scale)
- [ ] Pimcore feed ingestion HPA (ACES/PIES XML parsing is CPU-intensive)
