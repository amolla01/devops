# Management vs Fabric Routing — Topology Routing Matrix & OOB Policy Rules

## Overview

The SONiC CLOS fabric lab topology operates with **two completely independent routing planes**:

1. **Out-of-Band (OOB) Management** — Layer 2 KVM virtual bridge, `172.16.2.0/24`
2. **In-Band Fabric (Data Plane)** — eBGP unnumbered over IPv6 link-local, `10.x.x.x/8` address space

These planes **MUST NOT** leak into each other. If management routes are advertised into BGP, data-plane traffic destined for management IPs could be hairpinned through the fabric causing routing loops and breaking SSH connectivity.

---

## Topology Routing Matrix

### Management Plane (OOB) — 172.16.2.0/24

| Device | Management IP | Access Method | Bridge |
|--------|--------------|---------------|--------|
| R810 Hypervisor | 192.168.9.198 | Direct SSH from Windows/WSL | Physical NIC |
| Spine_S1 | 172.16.2.10 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Spine_S2 | 172.16.2.11 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Border_Leaf1 | 172.16.2.31 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Border_Leaf2 | 172.16.2.32 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Leaf_L1 | 172.16.2.21 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Leaf_L2 | 172.16.2.22 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Leaf_L3 | 172.16.2.23 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Leaf_L4 | 172.16.2.24 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Exit_Router1 | 172.16.2.98 | ProxyJump via R810 | virbr-mgmt (KVM) |
| Exit_Router2 | 172.16.2.99 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostB11_1 | 172.16.2.41 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostB11_2 | 172.16.2.42 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostB12_1 | 172.16.2.43 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostB12_2 | 172.16.2.44 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostL1 | 172.16.2.51 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostL2 | 172.16.2.52 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostL3 | 172.16.2.53 | ProxyJump via R810 | virbr-mgmt (KVM) |
| HostL4 | 172.16.2.54 | ProxyJump via R810 | virbr-mgmt (KVM) |
| MonitorSrv | 172.16.2.100 | ProxyJump via R810 | virbr-mgmt (KVM) |

### Fabric Plane (In-Band) — 10.x.x.x

| Device | Loopback/Router-ID | ASN | Fabric Interfaces |
|--------|-------------------|-----|-------------------|
| Spine_S1 | 10.0.0.1 | 65000 | Ethernet120-127 (to all leaves/borders) |
| Spine_S2 | 10.0.0.2 | 65000 | Ethernet120-127 (to all leaves/borders) |
| Border_Leaf1 | 10.0.2.1 | 65021 | Ethernet120,124 (spines), Ethernet0 (exit), Ethernet20-28 (servers) |
| Border_Leaf2 | 10.0.2.2 | 65022 | Ethernet120,124 (spines), Ethernet0 (exit), Ethernet20-28 (servers) |
| Leaf_L1 | 10.0.1.1 | 65011 | Ethernet120,124 (spines), Ethernet20 (server) |
| Leaf_L2 | 10.0.1.2 | 65012 | Ethernet120,124 (spines), Ethernet20 (server) |
| Leaf_L3 | 10.0.1.3 | 65013 | Ethernet120,124 (spines), Ethernet20 (server) |
| Leaf_L4 | 10.0.1.4 | 65014 | Ethernet120,124 (spines), Ethernet20 (server) |
| Exit_Router1 | 10.0.99.1 | 65254 | ether2 → Border_Leaf1 (10.0.253.0/31) |
| Exit_Router2 | 10.0.99.2 | 65254 | ether2 → Border_Leaf2 (10.0.253.2/31) |

### Point-to-Point Links (Exit ↔ Border)

| Link | Subnet | Border IP | Exit IP |
|------|--------|-----------|---------|
| Border_Leaf1 ↔ Exit_Router1 | 10.0.253.0/31 | 10.0.253.0 | 10.0.253.1 |
| Border_Leaf2 ↔ Exit_Router2 | 10.0.253.2/31 | 10.0.253.2 | 10.0.253.3 |

---

## Traffic Flow Diagram

```
                    ┌─────────────────────────────────────────────────────┐
                    │            MANAGEMENT PLANE (Layer 2)                │
                    │                 172.16.2.0/24                        │
                    │                                                     │
  ┌───────────┐    │  ┌──────────────────┐     ┌──────────────────────┐  │
  │ Windows   │────┼──│ R810 Hypervisor  │─────│ virbr-mgmt (KVM L2) │  │
  │ Laptop    │ SSH│  │ 192.168.9.198    │     │ All VM eth0 ports    │  │
  │ (WSL)     │    │  └──────────────────┘     └──────────────────────┘  │
  └───────────┘    │         │ ProxyJump                  │              │
                    │         ▼                            ▼              │
                    │    SSH → 172.16.2.x           SSH → 172.16.2.x     │
                    └─────────────────────────────────────────────────────┘

                    ┌─────────────────────────────────────────────────────┐
                    │              FABRIC PLANE (Layer 3 BGP)              │
                    │                  10.x.x.x/8                         │
                    │                                                     │
                    │  ┌────────────┐         ┌────────────┐             │
                    │  │ Exit_Rtr1  │         │ Exit_Rtr2  │             │
                    │  │ 10.0.99.1  │         │ 10.0.99.2  │             │
                    │  └─────┬──────┘         └─────┬──────┘             │
                    │        │ 10.0.253.0/31        │ 10.0.253.2/31      │
                    │  ┌─────┴──────┐         ┌─────┴──────┐             │
                    │  │Border_Leaf1│         │Border_Leaf2│             │
                    │  │ 10.0.2.1   │         │ 10.0.2.2   │             │
                    │  └─────┬──────┘         └─────┬──────┘             │
                    │        │ IPv6 LL eBGP         │                    │
                    │  ┌─────┴──────────────────────┴──────┐             │
                    │  │          Spine Layer               │             │
                    │  │   S1 (10.0.0.1)  S2 (10.0.0.2)   │             │
                    │  └─────┬──────────────────────┬──────┘             │
                    │        │                      │                    │
                    │  ┌─────┴────┐  ┌────┐  ┌─────┴────┐               │
                    │  │L1  L2   │  │L3  │  │L4        │               │
                    │  └─────────┘  └────┘  └──────────┘               │
                    └─────────────────────────────────────────────────────┘

  ═══════════════════════════════════════════════════════════════
  THESE TWO PLANES NEVER INTERSECT. NO ROUTING BETWEEN THEM.
  ═══════════════════════════════════════════════════════════════
```

---

## OOB Policy Rules

### Rule 1: SONiC Switches MUST NOT Inject Local Management Routes into BGP

**Implementation** — FRR prefix-list + route-map on all SONiC switches:

```
ip prefix-list PL_NO_MGMT seq 5 deny 172.16.2.0/24
ip prefix-list PL_NO_MGMT seq 100 permit 0.0.0.0/0 le 32
ipv6 prefix-list PL6_NO_MGMT seq 100 permit ::/0 le 128
!
route-map DENY_MGMT permit 10
 match ip address prefix-list PL_NO_MGMT
route-map DENY_MGMT permit 20
 match ipv6 address prefix-list PL6_NO_MGMT
!
router bgp <ASN>
 address-family ipv4 unicast
  redistribute connected route-map DENY_MGMT
 address-family ipv6 unicast
  redistribute connected route-map DENY_MGMT
```

**Enforced by:** `roles/sonic_fabric/tasks/apply_patch.yml` — vtysh BGP configuration block.

> **Critical FRR Behavior:** `redistribute connected route-map X` ONLY filters locally-originated connected routes. It does NOT affect routes learned from eBGP peers (transit routes). See Rule 1b.

### Rule 1b: Border Leaves MUST Block Transit Management Routes to Exit Routers

Even if Rule 1 is applied on the local switch, management routes from OTHER switches (that lack the filter) propagate through the spines and arrive as transit routes. These transit routes bypass `redistribute connected route-map` entirely.

**Implementation** — Outbound route-map on exit-router-facing BGP peers:

```
router bgp <ASN>
 address-family ipv4 unicast
  neighbor <exit_router_ip> route-map DENY_MGMT out
```

This blocks ALL `172.16.2.0/24` advertisements to exit routers regardless of whether the route was locally originated or learned from another eBGP peer in the fabric.

**Enforced by:** `roles/sonic_fabric/tasks/apply_patch.yml` — applied to all `_effective_ip_peers` (exit router connections).

### Rule 2: Exit Routers MUST NOT Advertise Management Routes to Fabric

**Verification assertion** in `roles/mikrotik_base/tasks/day1_bgp.yml`:

```yaml
- name: "day1 | Assert OOB management subnet is not advertised via BGP"
  assert:
    that:
      - (_bgp_advertised.stdout) is not search(oob_management_route_token)
    msg: >-
      OOB policy violation: management subnet '{{ oob_management_subnet }}'
      is being advertised to fabric peers.
```

### Rule 3: Exit Routers MUST NOT Learn Management Routes from Fabric

**Verification assertion** in `roles/mikrotik_base/tasks/day1_bgp.yml`:

```yaml
- name: "day1 | Assert OOB management subnet is not learned from fabric BGP"
  assert:
    that:
      - (_bgp_routes_received.stdout) is not search(oob_management_route_token)
    msg: >-
      OOB policy violation: management subnet token '{{ oob_management_route_token }}'
      was found in BGP-received routes. This indicates management-route leakage from fabric.
```

### Rule 4: Spine Inbound Filtering (Defense in Depth)

Spines apply inbound prefix-lists via ConfigDB `ROUTE_MAP` / `PREFIX_LIST` to only accept `10.x.x.x` prefixes:

```json
"PREFIX_LIST": {
    "FABRIC_PREFIXES_IN|10": { "prefix": "10.0.0.0/8 ge 32 le 32", "action": "permit" },
    "FABRIC_PREFIXES_IN|20": { "prefix": "10.10.0.0/16 ge 24 le 24", "action": "permit" },
    "FABRIC_PREFIXES_IN|30": { "prefix": "10.10.255.0/24 ge 32 le 32", "action": "permit" }
}
```

---

## FRR Route-Map Ordering & Transit Gotchas

### Gotcha 1: Route-map must exist BEFORE it is referenced

FRR permits everything when a route-map is referenced but doesn't yet exist. If you define BGP config with `redistribute connected route-map DENY_MGMT` and the route-map doesn't exist yet, FRR treats it as "permit all" — the management route gets advertised immediately.

**Fix:** Define prefix-lists and route-maps in a separate `docker exec bgp vtysh` call BEFORE the BGP router configuration.

### Gotcha 2: `redistribute connected route-map` only filters LOCAL routes

A route-map on `redistribute connected` prevents the switch from injecting its OWN connected routes into BGP. But if another switch in the fabric already injected `172.16.2.0/24`, that route propagates via spines to all peers as a **transit route**. Transit routes are unaffected by `redistribute connected route-map`.

**Fix:** Apply `neighbor <exit_ip> route-map DENY_MGMT out` on exit-facing peers to block both local AND transit routes.

### Gotcha 3: After changing route-maps, existing advertisements persist

FRR doesn't automatically re-evaluate routes already in the Adj-RIB-Out when you add or modify a route-map. Previously-advertised management routes remain in neighbors' tables.

**Fix:** Run `clear ip bgp * soft out` (forces re-evaluation of outbound policy) followed by `clear ip bgp * soft in` (forces re-import from peers).

---

## Troubleshooting History (Day-1 OOB Leak)

| Attempt | What was done | Why it still failed |
|---------|--------------|-------------------|
| 1st | Added `route-map DENY_MGMT` defined AFTER `redistribute connected` | FRR permits all when a referenced route-map doesn't exist yet. Management route advertised before route-map was created. |
| 2nd | Moved route-map definition BEFORE BGP config + added `clear soft out` | Fixed local injection from Border_Leaf2. But `172.16.2.0/24` still arrived as a **transit route** from other switches through the spines (pfxRcd went from 15→16). |
| 3rd | Added `neighbor <exit_ip> route-map DENY_MGMT out` on exit-facing peers | Blocks BOTH local AND transit routes from reaching exit routers. Combined with soft-clear, forces immediate withdrawal. |

### Route Propagation Path (what was happening)

```
Border_Leaf1 (no route-map applied) 
  → "redistribute connected" injects 172.16.2.0/24 into BGP
    ↓ eBGP
Spine_S1 / Spine_S2  (transit — no filtering on this direction)
    ↓ eBGP
Border_Leaf2 (has route-map on redistribute, but learns 172.16.2.0/24 from spines as TRANSIT)
    ↓ eBGP (IP-based peer to exit router)
Exit_Router2 → sees 172.16.2.0/24 → ASSERTION FAILS
```

The `redistribute connected route-map` on Border_Leaf2 only prevented Border_Leaf2's OWN management route from entering BGP. It did nothing about the same route arriving from Spine_S2 (originated by Border_Leaf1 or any leaf).

---

## Why Exit Routers Do NOT Need Management Routing Rules

| Question | Answer |
|----------|--------|
| Can I SSH to switches from my laptop? | **Yes** — via ProxyJump through R810 (192.168.9.198), which is directly on the KVM management bridge |
| Does traffic to 172.16.2.x flow through the Exit Routers? | **No** — management traffic is Layer 2 on the hypervisor bridge |
| Do Exit Routers need `172.16.2.0/24` in their routing table? | **No** — they only participate in the fabric (10.x.x.x) |
| What happens if the management route leaks into BGP? | **Routing loop** — fabric tries to forward 172.16.2.x packets through eBGP paths instead of the direct bridge |
| Should I add firewall accept rules for 172.16.2.0/24 on MikroTik? | **No** — the traffic never reaches the Exit Router's data plane |

---

## Ansible Variables (inventory/group_vars/all.yml)

```yaml
oob_management_subnet: "172.16.2.0/24"
oob_management_route_token: "172.16.2."
```

---

## Summary

- **Management access** works via Layer 2 KVM bridge → ProxyJump (R810) → `172.16.2.x` — no BGP involvement
- **Fabric routing** uses eBGP over `10.x.x.x` address space — management IPs explicitly denied from redistribution AND outbound to exits
- **Four enforcement points**: source (FRR redistribute route-map), egress (FRR neighbor outbound route-map to exits), transit (spine inbound prefix-list), verification (MikroTik Day-1 assertions)
- **No routing rules needed on Exit Routers** for management — the planes are air-gapped at Layer 2/3 boundary
- **Key lesson**: `redistribute connected route-map` only blocks local routes; outbound neighbor route-maps are required to block transit routes
