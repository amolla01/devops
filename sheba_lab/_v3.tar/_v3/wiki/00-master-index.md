# 00 — Wiki Master Index

Complete document index for the _v3 platform wiki organized into four categories.

---

## Infrastructure Build (25 documents)

| # | Document | Scope |
|---|----------|-------|
| 01 | Preflight Download | Offline artifact preparation |
| 02 | Build Packer Images | OS image creation for MaaS |
| 03 | Deploy MaaS | Bare metal provisioning |
| 04 | Deploy Day 0 Base Provisioning | Switch zero-touch config |
| 05 | Set Interface Properties | Hardware-aware port mapping |
| 06 | Deploy Day 1 Fabric Wiring | BGP underlay + BFD |
| 07 | Deploy Leaf-Server BGP | Server-to-leaf peering |
| 08 | Deploy Server Networking | Netplan + FRR |
| 09 | Deploy SONiC EVPN | EVPN control plane |
| 10 | Deploy EVPN Overlay | VXLAN + VRFs |
| 11 | Deploy BGP Agent | Route redistribution |
| 12 | Deploy Kubespray | Kubernetes cluster |
| 13 | Deploy Ceph (Rook) | Distributed storage |
| 14 | Deploy PostgreSQL | HA database |
| 15 | Deploy OpenStack (Helm) | Cloud platform |
| 16 | Extend Topology | Add nodes |
| 17 | Deployment Runbook | Full orchestration |
| 18 | Complete Command Reference | All playbooks/tags |
| 19 | Multi-Tenant Architecture | VRF + NS isolation |
| 20 | Multi-Homing Strategy | LACP, ESI, ECMP |
| 21 | Gap Analysis v2 vs v3 | Platform comparison |
| 22 | Enhancement Report | v3 improvements |
| 23 | Complete Platform Report | Executive summary |
| 24 | R810 Resource Profile | KVM resource allocation |
| 25 | Air-Gapped Cache Architecture | Cache-first deployment pattern |

## Platform Monitoring (5 documents)

| # | Document | Scope |
|---|----------|-------|
| 01 | Deploy Monitoring | Prometheus + Grafana |
| 02 | Audit Topology Interfaces | Fabric health |
| 03 | Kubespray Day 1 Operations | K8s maintenance |
| 04 | K8s Dashboard & Tools | Dashboard, Lens, k9s |
| 05 | Utility Software Setup | CLI tools, SSH |

## Business Software (6 documents)

| # | Document | Scope |
|---|----------|-------|
| 01 | Deploy Sheba Cloud Infra | Namespaces, quotas |
| 02 | Deploy Sheba Infra Services | Gitea, Harbor, OpenBao |
| 03 | Deploy Sheba SDLC Services | Tekton, ArgoCD, SonarQube |
| 04 | Sheba Common Software | RabbitMQ, Redis, OpenSearch |
| 05 | Sheba Infrastructure Software | MetalLB, cert-manager, Velero |
| 06 | PostgreSQL Deployment Validation | Verification + benchmarks |

## Business Ideation (10 documents)

| # | Document | Scope |
|---|----------|-------|
| 01 | Deploy Service Catalog | Service catalog foundation |
| 02 | NoyoBazar Domestic Marketplace | BD commerce (papers #11–24) |
| 03 | NoyoBazar Export Marketplace | Intl trade (papers #31–45) |
| 04 | Software Deployment Strategy | Microservices + pipeline |
| 05 | Bangladesh Digitization Catalog | Market + K8s-aaS |
| 06 | Staffing Blueprint | Team, hiring, compensation |
| 07 | Series A Pitch & Financial Model | Fundraising, projections |
| 08 | GTM & Seller Acquisition | Go-to-market, partnerships |
| 09 | Competitive Analysis & Viability | SWOT, differentiation |
| 10 | Infrastructure Tech Stack Blueprint | OSS stack + cost analysis |

---

## Totals

| Category | Documents | Files |
|----------|-----------|-------|
| Infrastructure Build | 25 | 50 |
| Platform Monitoring | 5 | 10 |
| Business Software | 6 | 12 |
| Business Ideation | 10 | 20 |
| **TOTAL** | **46** | **92** |
