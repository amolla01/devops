# 24 — R810 Resource Profile (Role-Tiered VM Allocation)

## Overview

Defines the role-based resource allocation strategy for the Dell R810 hypervisor running the full 18-VM L3 CLOS topology. Resources are differentiated by workload role rather than flat per-type allocation, ensuring no operator, controller, or data-plane process is starved.

| Attribute | Value |
|-----------|-------|
| Profile | `ubuntu_r810_kvm` |
| Category | Infrastructure Build |
| Hypervisor | Dell R810 — 256 GB RAM, 64 vCPU, 5+ TB disk |
| VMs | 18 total (8 SONiC, 6 servers + 2 gateway/monitor, 2 CHR) |
| Files Modified | `all.yml`, `deploy_lab_v13.sh`, `ceph_osd.yml`, `kube_workers.yml` |
| Prerequisites | Ubuntu 24.04 on R810, libvirt/QEMU/KVM, OVS bridges |

---

## Design Philosophy

1. **Role-tiered** — VMs are sized by their workload, not uniformly
2. **Parameterized** — All values are variables in `all.yml` and `deploy_lab_v13.sh`; change one place, everything adapts
3. **Generous headroom** — Allocate above average so etcd, Ceph, and OpenStack never compete for resources
4. **Hypervisor reserve** — Always keep 8–16 GB free for OVS, libvirt, sshd, kernel
5. **Auto-provisioned OSD disks** — Ceph disks created at deploy time (no manual `virsh attach-disk`)

---

## Resource Allocation Table

### RAM Budget (256 GB physical)

| Role | VMs | Per-VM | Total | Justification |
|------|-----|--------|-------|---------------|
| SONiC switches | Spine×2, Leaf×4, Border×2 | 4 GB | 32 GB | BGP/LLDP/ZTP only; SONiC KVM uses ~1.5 GB |
| **K8s Controllers** | Host12_1, Host34_1, HostB12_1 | **32 GB** | **96 GB** | etcd (8 GB), apiserver, scheduler, Ceph MON/MGR, OpenStack ctrl |
| **K8s Workers** | Host12_2, Host12_3, Host34_2 | **28 GB** | **84 GB** | Ceph OSD cache (4 GB), Nova compute, app pods |
| Gateway/Monitor | HostB12_2, MonitorSrv | 16 GB | 32 GB | OpenStack GW, Prometheus, Grafana, MaaS |
| MikroTik CHR | Exit_Router1, Exit_Router2 | 2 GB | 4 GB | RouterOS uses <512 MB |
| **Guest Total** | **18** | — | **248 GB** | |
| Hypervisor reserve | — | — | ~8 GB | OVS, libvirt, sshd, kernel |

### vCPU Budget (64 physical cores)

| Role | Per-VM | Count | Total |
|------|--------|-------|-------|
| SONiC | 2 | 8 | 16 |
| K8s Controllers | 10 | 3 | 30 |
| K8s Workers | 10 | 3 | 30 |
| Gateway/Monitor | 4 | 2 | 8 |
| CHR | 2 | 2 | 4 |
| **Total** | | **18** | **88 vCPU** |

> 88 vCPU on 64 physical = 1.375:1 overcommit ratio — safe for mixed workloads where not all VMs saturate simultaneously.

### Disk Budget (5+ TB physical)

| Purpose | Per-Item | Count | Total |
|---------|----------|-------|-------|
| Controller OS disk | 80 GB | 3 | 240 GB |
| Worker OS disk | 60 GB | 3 | 180 GB |
| Gateway OS disk | 50 GB | 2 | 100 GB |
| SONiC OS disk | 20 GB | 8 | 160 GB |
| CHR disk | 5 GB | 2 | 10 GB |
| **Ceph OSD disks** | **200 GB** | **12** (6 nodes × 2) | **2,400 GB** |
| **Total** | | | **~3.1 TB** |

> Leaves ~2 TB headroom for snapshots, images directory, and temporary storage.

---

## Variables Reference

### `inventory/group_vars/all.yml` — Profile `ubuntu_r810_kvm`

```yaml
lab_sonic_ram_mb: 4096
lab_sonic_vcpu: 2
lab_sonic_root_disk_gb: 20

lab_server_controller_ram_mb: 32768
lab_server_controller_vcpu: 10
lab_server_controller_root_disk_gb: 80

lab_server_worker_ram_mb: 28672
lab_server_worker_vcpu: 10
lab_server_worker_root_disk_gb: 60

lab_server_gateway_ram_mb: 16384
lab_server_gateway_vcpu: 4
lab_server_gateway_root_disk_gb: 50

lab_chr_ram_mb: 2048
lab_chr_vcpu: 2
lab_chr_root_disk_gb: 5

lab_ceph_osd_disk_gb: 200
lab_ceph_osd_disks_per_node: 2
```

### `deploy_lab_v13.sh` — Shell Variables

```bash
# Role-tiered (set by apply_profile_settings for ubuntu_r810_kvm)
SERVER_CONTROLLER_RAM=32768; SERVER_CONTROLLER_VCPU=10
SERVER_WORKER_RAM=28672;     SERVER_WORKER_VCPU=10
SERVER_GATEWAY_RAM=16384;    SERVER_GATEWAY_VCPU=4

SERVER_CONTROLLER_ROOT_DISK_GB=80
SERVER_WORKER_ROOT_DISK_GB=60
SERVER_GATEWAY_ROOT_DISK_GB=50

CEPH_OSD_DISK_GB=200
CEPH_OSD_DISKS_PER_NODE=2
```

### `inventory/group_vars/ceph_osd.yml` — OSD Memory

```yaml
# R810 profile: 2 GB per OSD (generous BlueStore cache)
ceph_osd_memory_target: '2147483648'   # 2 GB

# Systemd limits
ceph_osd_systemd_overrides:
  Service:
    MemoryMax: "4G"
    CPUQuota: "200%"
```

### `inventory/group_vars/kube_workers.yml` — Kubelet Reservations

```yaml
kubelet_system_reserved:
  cpu: "2000m"
  memory: "4Gi"
  ephemeral_storage: "2Gi"

kubelet_kube_reserved:
  cpu: "1000m"
  memory: "2Gi"
```

---

## VM-to-Role Mapping

```
┌──────────────────────────────────────────────────────────────────────┐
│  Host12_1  │ K8s Controller │ etcd + apiserver + Ceph MON + OS ctrl  │
│  Host34_1  │ K8s Controller │ etcd + apiserver + Ceph MON + OS ctrl  │
│  HostB12_1 │ K8s Controller │ etcd + apiserver + Ceph MON + MaaS     │
├──────────────────────────────────────────────────────────────────────┤
│  Host12_2  │ K8s Worker     │ Ceph OSD + Nova compute + app pods     │
│  Host12_3  │ K8s Worker     │ Ceph OSD + Nova compute + app pods     │
│  Host34_2  │ K8s Worker     │ Ceph OSD + Nova compute + app pods     │
├──────────────────────────────────────────────────────────────────────┤
│  HostB12_2 │ Gateway        │ OpenStack GW (neutron L3/DHCP)         │
│  MonitorSrv│ Monitoring     │ Prometheus + Grafana + Loki            │
├──────────────────────────────────────────────────────────────────────┤
│  8× SONiC  │ Network        │ BGP/EVPN control plane only            │
│  2× CHR    │ Exit Router    │ MikroTik RouterOS (WAN uplink)         │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Changes Made (Diff Summary)

### 1. `data-center/_v3/inventory/group_vars/all.yml`

- Replaced flat `lab_sonic_ram_mb`/`lab_server_ram_mb`/`lab_chr_ram_mb` with role-tiered variables
- Added `lab_server_controller_*`, `lab_server_worker_*`, `lab_server_gateway_*`
- Added `lab_ceph_osd_disk_gb` and `lab_ceph_osd_disks_per_node`

### 2. `data-center/_v3/deploy_lab_v13.sh`

- Added role-tiered resource variables (`SERVER_CONTROLLER_RAM`, etc.)
- Added disk size variables (`SONIC_ROOT_DISK_GB`, `CEPH_OSD_DISK_GB`, etc.)
- `apply_profile_settings(ubuntu_r810_kvm)` now sets all tiered values
- `initialize_vm_catalog()` maps VMs to roles and assigns differentiated RAM/vCPU
- `deploy_single_vm()` uses role-based disk sizes and auto-creates Ceph OSD disks
- `print_profile_summary()` shows tiered breakdown
- OSD disks are created as empty qcow2 and passed to virt-install as additional `--disk` arguments

### 3. `data-center/_v3/inventory/group_vars/ceph_osd.yml`

- `ceph_osd_memory_target`: 1 GB → 2 GB for R810 profile
- `ceph_osd_systemd_overrides.MemoryMax`: 2G → 4G for R810
- `ceph_osd_systemd_overrides.CPUQuota`: 100% → 200% for R810

### 4. `data-center/_v3/inventory/group_vars/kube_workers.yml`

- `kubelet_system_reserved.cpu`: 500m → 2000m (for R810/R620)
- `kubelet_system_reserved.memory`: 512Mi → 4Gi
- `kubelet_kube_reserved.cpu`: 200m → 1000m
- `kubelet_kube_reserved.memory`: 256Mi → 2Gi
- `ephemeral_storage`: 1Gi → 2Gi

---

## How to Apply

### Option A: Full Rebuild (Recommended)

Destroys all 18 VMs and recreates with new resource allocations:

```bash
# SSH into R810
ssh nh1221@R810

# Set profile
export AUTOMATION_PROFILE=ubuntu_r810_kvm

# Full teardown + rebuild
cd ~/dc-lab/_v3
bash deploy_lab_v13.sh --profile ubuntu_r810_kvm redeploy
```

This will:
1. Destroy all existing VMs (`virsh destroy` + `virsh undefine`)
2. Delete all disks (COW + OSD)
3. Recreate VMs with tiered resources (32 GB controllers, 28 GB workers, etc.)
4. Auto-create Ceph OSD disks (200 GB × 2 per OSD node)
5. Boot all VMs and validate SSH

### Option B: Resize Existing VMs (No Data Loss)

If you want to keep existing VMs and just resize:

```bash
ssh nh1221@R810

# Stop all VMs
for vm in Host12_1 Host12_2 Host12_3 Host34_1 Host34_2 HostB12_1 HostB12_2 MonitorSrv; do
  sudo virsh shutdown "$vm" 2>/dev/null; done
sleep 30

# Resize controllers (32 GB, 10 vCPU)
for vm in Host12_1 Host34_1 HostB12_1; do
  sudo virsh setmaxmem "$vm" 33554432 --config
  sudo virsh setmem "$vm" 33554432 --config
  sudo virsh setvcpus "$vm" 10 --config --maximum
  sudo virsh setvcpus "$vm" 10 --config
done

# Resize workers (28 GB, 10 vCPU)
for vm in Host12_2 Host12_3 Host34_2; do
  sudo virsh setmaxmem "$vm" 29360128 --config
  sudo virsh setmem "$vm" 29360128 --config
  sudo virsh setvcpus "$vm" 10 --config --maximum
  sudo virsh setvcpus "$vm" 10 --config
done

# Resize gateways (16 GB, 4 vCPU)
for vm in HostB12_2 MonitorSrv; do
  sudo virsh setmaxmem "$vm" 16777216 --config
  sudo virsh setmem "$vm" 16777216 --config
  sudo virsh setvcpus "$vm" 4 --config --maximum
  sudo virsh setvcpus "$vm" 4 --config
done

# Add larger OSD disks if not present (200 GB each)
DISK_DIR="/var/lib/libvirt/images/dc-lab/disks"
for vm in Host12_1 Host12_2 Host12_3 Host34_1 Host34_2 HostB12_1; do
  for d in 1 2; do
    osd_disk="$DISK_DIR/${vm}-osd${d}.qcow2"
    if [[ ! -f "$osd_disk" ]]; then
      sudo qemu-img create -f qcow2 "$osd_disk" 200G
      sudo virsh attach-disk "$vm" "$osd_disk" "vd$(echo $d | tr '12' 'bc')" \
        --driver qemu --subdriver qcow2 --persistent
    fi
  done
done

# HostB12_1 only gets 1 OSD disk (per inventory)
sudo rm -f "$DISK_DIR/HostB12_1-osd2.qcow2"
sudo virsh detach-disk HostB12_1 vdc --config 2>/dev/null || true

# Start all VMs
for vm in Host12_1 Host12_2 Host12_3 Host34_1 Host34_2 HostB12_1 HostB12_2 MonitorSrv; do
  sudo virsh start "$vm"; done
```

### Option C: Apply Only to Existing Running Cluster (No VM Rebuild)

If VMs are already running with old resources and you just need to fix the Ceph/etcd crash:

```bash
# On R810 — increase the 6 K8s node VMs memory live (if supported)
# Note: live memory increase requires balloon driver and maxmem > current
# Usually requires VM restart — use Option B instead

# After VM resize + restart, re-run Kubespray if needed:
cd ~/dc-lab/_v3
ansible-playbook playbooks/reused/deploy_kubespray.yml -i inventory/hosts.yml -v

# Then redeploy Ceph:
ansible-playbook playbooks/reused/deploy_ceph_rook.yml -i inventory/hosts.yml -v
```

---

## Validation

After applying, verify:

```bash
# Check VM resources
virsh list --all
for vm in Host12_1 Host34_1 HostB12_1; do
  echo "=== $vm ==="; virsh dominfo "$vm" | grep -E 'Memory|CPU'; done

# Verify OSD disks visible inside VMs
ssh ubuntu@172.16.2.40 'lsblk | grep -E "vd[bc]"'

# Check K8s node resources
kubectl top nodes

# Check etcd health (should not timeout)
kubectl -n kube-system exec etcd-host12-1 -- etcdctl endpoint health

# Check Ceph status
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph status
```

---

## Why This Fixes the etcd Crash

The operator logs showed:
```
etcdserver: request timed out → etcdserver: leader changed → dial tcp 10.233.0.1:443: connection refused
```

**Root cause:** 6 OSD prepare jobs launched simultaneously, each pulling container images + running `ceph-volume lvm prepare`. Combined with apiserver, etcd, Ceph MON/MGR, and CSI controllers — all sharing 16 GB on controller nodes — etcd ran out of memory and lost leader election.

**Fix:** Controllers now have 32 GB (2× previous). etcd alone gets ~8 GB headroom. The kubelet also reserves 4 Gi for system services, preventing pod over-scheduling from crowding critical processes.
