# 25 — Air-Gapped Cache Architecture

## Overview

Documents how the `/opt/fabric-cache/` directory (populated by `preflight_download.yml`) is consumed by every subsequent playbook in the deployment chain. All playbooks use a **cache-first** pattern: check for local artifacts before attempting internet downloads.

| Attribute | Value |
|-----------|-------|
| Scope | All deployment playbooks |
| Category | Infrastructure Build |
| Profiles | KVM (air-gapped via tinyproxy) + Real Hardware |
| Prerequisites | `preflight_download.yml` has been run with internet access |
| Design Principle | **Never hit the internet if the cache has the artifact** |

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│  DEPLOYER (Lab-ControlNode / WSL2)                                   │
│  /opt/fabric-cache/                                                  │
│  ├── binaries/       helm, kubectl, cephadm, yq, k9s, argocd        │
│  ├── helm-charts/    38+ .tgz chart tarballs                         │
│  ├── images/         cirros, ubuntu cloud images                     │
│  ├── apt-packages/   .deb files for offline apt                      │
│  ├── pip-packages/   .whl files for offline pip                      │
│  └── kubespray/                                                      │
│      ├── src/        kubespray v2.25.0 git clone                     │
│      ├── venv/       python venv with all deps                       │
│      └── download-cache/  container images for download_localhost     │
└──────────────┬──────────────────────────────────────────────────────┘
               │  ansible.builtin.copy / scp / piped transfer
               ▼
┌─────────────────────────────────────────────────────────────────────┐
│  TARGET NODES (KVM VMs on R810)                                      │
│  172.16.2.0/24 — Air-gapped (no direct internet)                     │
│                                                                      │
│  /etc/apt/apt.conf.d/90proxy  ──→ tinyproxy @ 172.16.2.1:8888       │
│  /tmp/infra-charts/*.tgz      ──→ helm install source                │
│  /tmp/sdlc-charts/*.tgz       ──→ helm install source                │
│  /tmp/monitoring-charts/*.tgz ──→ helm install source                │
│  /usr/local/bin/helm          ──→ from /opt/fabric-cache/binaries/   │
│  /usr/local/bin/cephadm       ──→ from /opt/fabric-cache/binaries/   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Cache-First Pattern

Every helm install task follows this pattern:

```bash
CHART_SRC=$(ls /tmp/<stage>-charts/<chartname>-*.tgz 2>/dev/null | head -1)
if [ -z "$CHART_SRC" ]; then
  CHART_SRC="<repo>/<chart>"     # online fallback
fi
helm upgrade --install <release> "$CHART_SRC" \
  --namespace <ns> --values <values> --wait
```

Every binary install follows:

```bash
if [ -f /opt/fabric-cache/binaries/<binary> ]; then
  cp /opt/fabric-cache/binaries/<binary> /usr/local/bin/<binary>
elif <fallback-curl>; then
  ...  # internet fallback
fi
```

---

## Proxy Configuration (KVM Profiles)

For KVM-based air-gapped nodes, apt proxy is configured before any `apt-get update`:

```
# /etc/apt/apt.conf.d/90proxy
Acquire::http::Proxy "http://172.16.2.1:8888";
Acquire::https::Proxy "http://172.16.2.1:8888";
```

**Applied by**: `deploy_kubespray.yml` Phase 3, `extend_topology.yml`  
**Condition**: `automation_profile in ['ubuntu_r810_kvm', 'ubuntu_r620_kvm', 'win11_kvm']`  
**Why**: Ansible's `apt` module does NOT inherit shell `http_proxy` env vars. It needs apt's native proxy config.

---

## Playbook-by-Playbook Cache Usage

### Fully Cache-Aware (No Internet Required)

| # | Playbook | Helm Charts | Binaries | APT Proxy |
|---|----------|-------------|----------|-----------|
| 01 | `preflight_download.yml` | Downloads all → cache | Downloads all → cache | N/A (deployer) |
| 12 | `deploy_kubespray.yml` | via KubeSpray download_localhost | helm from cache | ✅ 90proxy |
| 12b | MetalLB (role) | `/opt/fabric-cache/helm-charts/metallb-*.tgz` | — | — |
| 13 | `deploy_ceph_rook.yml` | rook-ceph from cache | cephadm from cache | — |
| 14 | `deploy_postgresql.yml` | postgresql from cache | helm from cache | — |
| 15 | OpenStack Helm (role) | All OSH charts → `/tmp/osh-charts/` | helm-diff plugin from cache | — |
| 16 | `extend_topology.yml` | — | cephadm from cache | ✅ 90proxy |
| — | `deploy_maas.yml` | maas chart from cache | — | — |
| — | `deploy_sheba_infra_services.yml` | 6 charts → `/tmp/infra-charts/` | — | — |
| — | `deploy_sheba_sdlc_services.yml` | 7 charts → `/tmp/sdlc-charts/` | — | — |
| — | Monitoring (role) | prometheus-stack → `/tmp/monitoring-charts/` | — | — |

---

## Preflight Download — Complete Artifact Inventory

### Binaries (`/opt/fabric-cache/binaries/`)

| Binary | Version | Used By |
|--------|---------|---------|
| `helm` | latest | deploy_kubespray, deploy_postgresql, all helm playbooks |
| `kubectl` | matches kubespray version | deploy_kubespray |
| `cephadm` | reef | deploy_ceph_rook, extend_topology |
| `yq` | v4.x | inventory generation |
| `k9s` | latest | operator tooling |
| `argocd` | latest | argocd CLI |
| `packer` | latest | build_packer_images |
| `node_exporter` | latest | monitoring |
| `prometheus` | latest | monitoring |
| `alertmanager` | latest | monitoring |

### Helm Charts (`/opt/fabric-cache/helm-charts/`)

| Chart | Consumer Playbook |
|-------|-------------------|
| `postgresql-*.tgz` | deploy_postgresql, deploy_sheba_infra_services |
| `postgresql-ha-*.tgz` | HA PostgreSQL deployments |
| `redis-*.tgz` | deploy_sheba_infra_services |
| `metallb-*.tgz` | roles/metallb |
| `rook-ceph-*.tgz` | deploy_ceph_rook |
| `kube-prometheus-stack-*.tgz` | roles/monitoring |
| `grafana-*.tgz` | deploy_sheba_sdlc_services, roles/monitoring |
| `loki-*.tgz` | deploy_sheba_sdlc_services |
| `tempo-*.tgz` | roles/monitoring |
| `promtail-*.tgz` | roles/monitoring |
| `ingress-*.tgz` | roles/openstack_helm |
| `mariadb-*.tgz` | roles/openstack_helm |
| `rabbitmq-*.tgz` | roles/openstack_helm |
| `memcached-*.tgz` | roles/openstack_helm |
| `keystone-*.tgz` | roles/openstack_helm |
| `glance-*.tgz` | roles/openstack_helm |
| `cinder-*.tgz` | roles/openstack_helm |
| `placement-*.tgz` | roles/openstack_helm |
| `nova-*.tgz` | roles/openstack_helm |
| `neutron-*.tgz` | roles/openstack_helm |
| `horizon-*.tgz` | roles/openstack_helm |
| `heat-*.tgz` | roles/openstack_helm |
| `openvswitch-*.tgz` | roles/openstack_helm |
| `cert-manager-*.tgz` | cert management |
| `gitea-*.tgz` | deploy_sheba_infra_services |
| `harbor-*.tgz` | deploy_sheba_infra_services |
| `openbao-*.tgz` | deploy_sheba_infra_services |
| `minio-*.tgz` | deploy_sheba_infra_services |
| `plane-ce-*.tgz` | deploy_sheba_sdlc_services |
| `argo-cd-*.tgz` | deploy_sheba_sdlc_services |
| `sonarqube-*.tgz` | deploy_sheba_sdlc_services |
| `mattermost-team-edition-*.tgz` | deploy_sheba_sdlc_services |
| `jaeger-*.tgz` | deploy_sheba_sdlc_services |
| `maas-*.tgz` | deploy_maas |
| `mongodb-*.tgz` | various |
| `elasticsearch-*.tgz` | various |
| `keycloak-*.tgz` | auth services |
| `minio-*.tgz` | deploy_sheba_infra_services |

### APT Packages (`/opt/fabric-cache/apt-packages/`)

Core packages cached for offline install:
- `conntrack`, `socat`, `ipset`, `ipvsadm`, `libipset13`
- `openvswitch-switch`, `frr`, `frr-pythontools`, `lldpd`
- `qemu-kvm`, `libvirt-daemon-system`, `chrony`
- `apt-transport-https`, `ca-certificates`, `curl`
- `lvm2`, `gdisk` (Ceph OSD prerequisites)

### Pip Packages (`/opt/fabric-cache/pip-packages/`)

- `kolla-ansible`, `python-openstackclient`, `python-heatclient`
- `docker`, `ansible-core`, `netaddr`, `jinja2`

---

## KubeSpray Offline Mode

KubeSpray uses a special mechanism via `kubespray_all.yml.j2`:

```yaml
download_localhost: true          # Download images ON deployer
download_cache_dir: /opt/fabric-cache/kubespray/download-cache
download_force_cache: true        # Always prefer cache over pull

# Proxy for nodes (apt-get update, etc.)
http_proxy: "http://172.16.2.1:8888"
https_proxy: "http://172.16.2.1:8888"
```

**Key Insight**: The `http_proxy` env vars in KubeSpray's all.yml work for container runtime (containerd/docker) but NOT for Ansible's `apt` module. That's why we additionally write `/etc/apt/apt.conf.d/90proxy` on all nodes.

---

## Troubleshooting

### `apt-get update` hangs for 60+ minutes
**Cause**: Nodes can't reach `archive.ubuntu.com` — apt proxy not configured.  
**Fix**: Ensure the `Configure apt to use R810 proxy` task runs in Phase 3 of `deploy_kubespray.yml` BEFORE KubeSpray's cluster.yml.

### Helm chart not found in cache
**Cause**: `preflight_download.yml` was run without the relevant tag, or chart name doesn't match glob.  
**Fix**: Re-run preflight with the specific tag, e.g. `--tags helm_charts`. Verify chart exists: `ls /opt/fabric-cache/helm-charts/<name>-*.tgz`

### Binary not in `/opt/fabric-cache/binaries/`
**Cause**: Preflight skipped binary download or version mismatch.  
**Fix**: Re-run `ansible-playbook preflight_download.yml --tags binaries -v`

### `helm repo add` still runs despite cache
**Cause**: The `delegate_to: localhost` find task can't see `/opt/fabric-cache/helm-charts/` (wrong path or permissions).  
**Fix**: Verify the cache dir exists on the deployer: `ls /opt/fabric-cache/helm-charts/*.tgz | wc -l`

---

## Design Decisions

1. **Cache on deployer, copy to nodes** — avoids needing shared NFS or direct internet from nodes
2. **`delegate_to: localhost` for discovery** — the deployer always has the cache; nodes may not
3. **Glob matching for chart versions** — `postgresql-*.tgz` allows version bumps without playbook edits
4. **Conditional `helm repo add`** — only hits internet if no cache found (graceful degradation)
5. **Separate staging dirs per playbook** — `/tmp/infra-charts/`, `/tmp/sdlc-charts/`, `/tmp/monitoring-charts/`, `/tmp/osh-charts/` prevent collisions
6. **apt proxy via file, not env var** — Ansible's `apt` module respects `/etc/apt/apt.conf.d/` but ignores `http_proxy` environment variable
