# Grocery Marketplace — Open-Source Integration Blueprint (Bangladesh)

## Overview

This document details how open-source marketplace software can be integrated and stitched together to build a **Grocery Marketplace** targeting the **Bangladesh market**. It covers the full commerce lifecycle—from vendor onboarding and catalog management to order fulfillment, delivery tracking, and payments via bKash, Nagad, and credit cards—along with strategies for pre-populating a product database with grocery data.

---

## 1. Architecture — Software Stack

| Layer | Software | Role | License |
|-------|----------|------|---------|
| Commerce Engine | **MedusaJS v2** | Orders, cart, checkout, fulfillment workflows | MIT |
| Product Info Mgmt | **Akeneo PIM CE** or **Pimcore** | Centralized product catalog, attributes, localization (Bangla) | AGPL / GPL |
| Search | **Typesense** or **Meilisearch** | Fast product search, faceted filtering, Bangla text support | GPL-3 / MIT |
| Billing & Subscription | **Lago** | Vendor subscription plans, commission invoicing, usage-based billing | AGPL |
| Storefront | **Mercur / Next.js** | B2C customer-facing storefront (SSR, responsive, mobile-first) | MIT |
| Admin Panel | **Medusa Admin** | Backoffice for orders, inventory, vendors | MIT |
| API Gateway | **Kong** or **APISIX** | Rate limiting, auth, routing, API key management | Apache-2.0 |
| Message Broker | **RabbitMQ** | Event-driven communication between services | MPL-2.0 |
| Cache | **Redis** | Session, cart, rate-limit counters | BSD |
| Database | **PostgreSQL 16** | Transactional data (orders, users, inventory) | PostgreSQL License |
| Object Storage | **MinIO** | Product images, invoices, documents | AGPL |
| Delivery/Mapping | **OSRM** + **Leaflet** | Route optimization, delivery ETA, driver tracking | BSD |
| Monitoring | **Grafana + Prometheus** | Platform health, SLA dashboards | AGPL / Apache-2.0 |
| Auth | **Keycloak** | SSO, vendor/customer identity, RBAC | Apache-2.0 |

---

## 2. Module Breakdown — How They Stitch Together

### 2.1 Business Account Registration & Vendor Onboarding

```
Vendor → Keycloak (registration) → MedusaJS (store creation) → Lago (subscription plan assignment)
```

| Step | System | API/Action |
|------|--------|-----------|
| Vendor signs up | Keycloak | `POST /realms/marketplace/users` |
| Assign role `vendor` | Keycloak | Role mapping |
| Create store entity | MedusaJS | `POST /admin/stores` (custom module) |
| Assign subscription tier | Lago | `POST /api/v1/subscriptions` (Basic/Pro/Enterprise) |
| NID/TIN verification | Custom service | Bangladesh NID API integration |

### 2.2 Catalog Upload & Product Management

```
Vendor → Admin Panel → Akeneo/Pimcore (PIM) → Sync → MedusaJS Products → Index → Typesense
```

- **Bulk CSV/Excel upload** via PIM (Akeneo or Pimcore)
- **Category taxonomy**: Grocery → Fruits, Vegetables, Dairy, Rice/Grains, Snacks, Beverages, Household, etc.
- **Localization**: Product names in Bangla (বাংলা) + English
- **Variant support**: Weight variants (500g, 1kg, 5kg), pack sizes
- **Image pipeline**: Upload → MinIO → CDN (resize to 400x400, webp conversion)

### 2.3 Search

| Feature | Implementation |
|---------|---------------|
| Autocomplete | Typesense instant-search (< 50ms) |
| Faceted filtering | Category, price range, brand, weight |
| Bangla search | Typesense tokenizer with Bangla unicode support |
| Synonyms | "আলু" ↔ "Potato", "চাল" ↔ "Rice" |
| Popularity boost | Order count as ranking signal |

### 2.4 Cart & Checkout

```
Customer → Storefront → MedusaJS Cart API → Apply coupons → Select payment → Place order
```

| Endpoint | Purpose |
|----------|---------|
| `POST /store/carts` | Create cart |
| `POST /store/carts/:id/line-items` | Add item |
| `POST /store/carts/:id/payment-sessions` | Initialize payment |
| `POST /store/carts/:id/complete` | Place order |

### 2.5 Inventory Management

- **MedusaJS Inventory Module** tracks stock per warehouse/vendor
- **Low-stock alerts** via RabbitMQ → notification service
- **Multi-warehouse**: Support for vendor-owned storage + central marketplace warehouse
- **Webhook on stock change**: Triggers re-index in Typesense (removes out-of-stock items)

### 2.6 Order Fulfillment & Delivery

```
Order Placed → RabbitMQ → Fulfillment Service → Assign Rider → OSRM (Route) → Delivery Tracking
```

| Component | Role |
|-----------|------|
| MedusaJS Fulfillment Module | Order → packed → shipped → delivered state machine |
| Custom Rider Assignment Service | Assigns nearest available rider (geofenced) |
| OSRM | Open-source routing for Dhaka/Chittagong streets |
| Leaflet + WebSocket | Real-time map tracking for customer |
| SMS notification | Delivery ETA via Bangla SMS (Alpha SMS / Infobip) |

### 2.7 Invoicing & Billing

| Use Case | Lago Feature |
|----------|-------------|
| Vendor monthly subscription | Fixed recurring charge (BDT 500/1000/2000) |
| Commission per order | Usage-based billing: % of GMV |
| Platform fees | Aggregated weekly invoice |
| Customer invoice | Generated per order (PDF via MinIO) |

### 2.8 Order Tracking

- Customer-facing: `/orders/:id/track` → shows fulfillment status + rider location
- Vendor-facing: Admin panel shows all their orders with filters
- Events published to RabbitMQ on each state transition

---

## 3. Payment Integration — Bangladesh Market

### 3.1 Supported Payment Methods

| Provider | Type | Integration Method | Settlement |
|----------|------|-------------------|-----------|
| **bKash** | Mobile Wallet | bKash Checkout API (Tokenized) | T+1 to T+3 |
| **Nagad** | Mobile Wallet | Nagad Payment Gateway API | T+1 to T+2 |
| **Credit/Debit Card** | Visa/Mastercard | via **SSLCommerz** or **AamarPay** | T+3 to T+5 |
| **Cash on Delivery** | Physical | Internal tracking | Immediate |

### 3.2 bKash Integration

**Sandbox**: `https://tokenized.sandbox.bka.sh/v1.2.0-beta`  
**Production**: `https://tokenized.pay.bka.sh/v1.2.0-beta`

```
Flow:
1. POST /tokenized/checkout/create  → Get paymentID
2. Redirect customer to bKash app/URL
3. Customer authorizes
4. POST /tokenized/checkout/execute → Confirm payment
5. Webhook callback → Update order status
```

**Key Fields**:
```json
{
  "mode": "0011",
  "payerReference": "customer_phone",
  "callbackURL": "https://api.marketplace.com.bd/webhooks/bkash",
  "amount": "350.00",
  "currency": "BDT",
  "intent": "sale",
  "merchantInvoiceNumber": "ORD-20240601-0001"
}
```

**Requirements**:
- bKash Merchant Account (apply at merchant.bkash.com)
- App Key, App Secret, Username, Password (sandbox first)
- PCI-DSS not required (tokenized flow)

### 3.3 Nagad Integration

**Sandbox**: `http://sandbox.mynagad.com:10080/remote-payment-gateway-1.0`  
**Production**: `https://api.mynagad.com`

```
Flow:
1. GET /api/dfs/check-out/initialize/:merchantId/:orderId
2. Decrypt response → get challenge
3. POST /api/dfs/check-out/complete/:paymentReferenceId
4. Customer completes payment on Nagad app
5. Callback → order confirmed
```

**Key Fields**:
```json
{
  "merchantId": "6830000001",
  "orderId": "ORD-20240601-0001",
  "amount": "350.00",
  "currencyCode": "050",
  "challenge": "<decrypted_challenge>",
  "merchantCallbackURL": "https://api.marketplace.com.bd/webhooks/nagad"
}
```

**Requirements**:
- Nagad PGW Merchant Account
- PG Public Key (RSA) for encryption
- Merchant Private Key for signing

### 3.4 SSLCommerz (Card Payments)

**Sandbox**: `https://sandbox.sslcommerz.com`  
**Production**: `https://securepay.sslcommerz.com`

```
Flow:
1. POST /gwprocess/v4/api.php (init transaction)
2. Redirect customer to SSLCommerz hosted page
3. Customer enters card details
4. IPN callback → validate via /validator/api/validationserverAPI.php
5. Order confirmed
```

Supports: Visa, Mastercard, AMEX, local bank cards, bKash, Nagad (unified gateway).

### 3.5 MedusaJS Payment Provider Plugin Pattern

```typescript
// src/modules/payment-bkash/service.ts
import { AbstractPaymentProvider } from "@medusajs/medusa"

class BkashPaymentProvider extends AbstractPaymentProvider {
  static identifier = "bkash"

  async initiatePayment(context): Promise<PaymentProviderSessionResponse> {
    const { amount, currency_code } = context
    const bkashSession = await this.bkashClient.createPayment({
      amount: (amount / 100).toFixed(2),
      currency: "BDT",
      intent: "sale",
      callbackURL: `${this.baseUrl}/webhooks/bkash`
    })
    return { data: { paymentID: bkashSession.paymentID } }
  }

  async capturePayment(paymentData): Promise<Record<string, unknown>> {
    return await this.bkashClient.executePayment(paymentData.paymentID)
  }

  async refundPayment(paymentData, refundAmount): Promise<Record<string, unknown>> {
    return await this.bkashClient.refundTransaction({
      paymentID: paymentData.paymentID,
      amount: (refundAmount / 100).toFixed(2),
      trxID: paymentData.trxID,
      reason: "Customer refund"
    })
  }
}
```

---

## 4. Pre-Populating Grocery Product Database

### 4.1 Trusted Data Sources

| Source | Type | Coverage | Access |
|--------|------|----------|--------|
| **Open Food Facts** | Open Database | 3M+ products globally, growing BD entries | Free API: `https://world.openfoodfacts.org/api/v2/` |
| **GS1 Bangladesh** | Barcode Registry | Official barcode → product mapping | Membership required (gs1bd.org) |
| **BSTI Product Registry** | Govt Database | Registered food products in Bangladesh | Public records / RTI |
| **Syndigo / Salsify** | Commercial PIM | Brand-authorized product data | Paid (enterprise) |
| **Chaldal / Daraz scraping** | Existing Grocery | BD-specific products with Bangla names | Legal grey area — use only public catalog data |
| **Vendor self-upload** | First-party | Vendor provides their own SKUs | Free (part of onboarding) |
| **Manual data entry** | Curated | Start with top 2000 grocery SKUs | Labor cost |

### 4.2 Open Food Facts — Best Free Source

```bash
# Search for products sold in Bangladesh
curl "https://world.openfoodfacts.org/cgi/search.pl?search_terms=rice&countries_tags=bangladesh&json=1&page_size=50"

# Get product by barcode
curl "https://world.openfoodfacts.org/api/v2/product/8901030793615.json"
```

**Returned fields usable for grocery DB**:
- `product_name` / `product_name_bn` (Bangla)
- `brands`
- `categories_tags`
- `nutriments` (calories, protein, fat, etc.)
- `image_url`, `image_small_url`
- `quantity` (e.g., "1 kg", "500 ml")
- `code` (barcode / EAN)

### 4.3 Data Ingestion Pipeline

```
Open Food Facts API → ETL Script (Python) → Clean/Normalize → PostgreSQL (product_catalog) → Sync to Akeneo PIM → Publish to MedusaJS → Index in Typesense
```

**Python ETL Script (example)**:
```python
import requests
import psycopg2

def fetch_off_products(category: str, country: str = "bangladesh", page_size: int = 100):
    """Fetch products from Open Food Facts for Bangladesh."""
    url = "https://world.openfoodfacts.org/cgi/search.pl"
    params = {
        "search_terms": category,
        "countries_tags": country,
        "json": 1,
        "page_size": page_size,
        "fields": "code,product_name,brands,categories_tags,image_url,quantity,nutriments"
    }
    response = requests.get(url, params=params, timeout=30)
    response.raise_for_status()
    return response.json().get("products", [])

def normalize_product(raw: dict) -> dict:
    """Normalize OFF product to internal schema."""
    return {
        "barcode": raw.get("code"),
        "name_en": raw.get("product_name", "").strip(),
        "brand": raw.get("brands", "Unknown"),
        "category": (raw.get("categories_tags") or ["uncategorized"])[0].replace("en:", ""),
        "image_url": raw.get("image_url"),
        "weight": raw.get("quantity", ""),
        "calories": raw.get("nutriments", {}).get("energy-kcal_100g"),
    }

def insert_products(products: list, conn):
    """Insert normalized products into PostgreSQL."""
    cur = conn.cursor()
    for p in products:
        cur.execute("""
            INSERT INTO product_catalog (barcode, name_en, brand, category, image_url, weight, calories)
            VALUES (%(barcode)s, %(name_en)s, %(brand)s, %(category)s, %(image_url)s, %(weight)s, %(calories)s)
            ON CONFLICT (barcode) DO UPDATE SET
                name_en = EXCLUDED.name_en,
                brand = EXCLUDED.brand,
                image_url = EXCLUDED.image_url
        """, p)
    conn.commit()

# Usage
categories = ["rice", "lentils", "oil", "milk", "sugar", "flour", "spices", "snacks", "biscuits", "tea"]
conn = psycopg2.connect("dbname=marketplace user=app host=localhost")

for cat in categories:
    products = fetch_off_products(cat)
    normalized = [normalize_product(p) for p in products if p.get("code")]
    insert_products(normalized, conn)
    print(f"Imported {len(normalized)} products for '{cat}'")
```

### 4.4 Recommended Initial Catalog (Top Categories for BD Grocery)

| Category | Example Products | Est. SKU Count |
|----------|-----------------|----------------|
| Rice & Grains | Miniket, Nazirshail, Basmati, Red rice | 50-80 |
| Lentils & Pulses | Masoor dal, Mung dal, Chola | 30-40 |
| Cooking Oil | Soybean oil, Mustard oil, Sunflower | 25-35 |
| Spices | Turmeric, Chili, Cumin, Coriander | 60-80 |
| Dairy | Milk (Aarong, Farm Fresh), Yogurt, Ghee | 30-40 |
| Snacks & Biscuits | Nabisco, Pran, Olympic, ACI | 80-100 |
| Beverages | Tea (Ispahani, Finlay), Coffee, Juice | 40-50 |
| Personal Care | Soap, Shampoo, Toothpaste | 60-80 |
| Household | Detergent, Dishwash, Tissue | 40-50 |
| Baby & Kids | Formula, Diapers, Baby food | 30-40 |
| **Total seed catalog** | | **~500-600 SKUs** |

### 4.5 Bangla Product Name Mapping

For customer-facing search, maintain a mapping table:

```sql
CREATE TABLE product_name_i18n (
    product_id UUID REFERENCES products(id),
    locale VARCHAR(5) NOT NULL,  -- 'bn', 'en'
    name TEXT NOT NULL,
    description TEXT,
    PRIMARY KEY (product_id, locale)
);

-- Examples:
INSERT INTO product_name_i18n VALUES
('uuid-1', 'en', 'Miniket Rice 5kg', 'Premium quality Miniket rice'),
('uuid-1', 'bn', 'মিনিকেট চাল ৫ কেজি', 'উন্নতমানের মিনিকেট চাল');
```

---

## 5. Integration Flow — End-to-End

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         GROCERY MARKETPLACE (BD)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────┐    ┌──────────┐    ┌──────────────┐    ┌─────────────┐       │
│  │ Keycloak │───▶│ MedusaJS │◀──▶│ PostgreSQL   │    │ Typesense   │       │
│  │ (Auth)   │    │ (Engine) │    │ (Data Store) │    │ (Search)    │       │
│  └──────────┘    └────┬─────┘    └──────────────┘    └──────▲──────┘       │
│                       │                                      │              │
│                       ▼                                      │              │
│  ┌──────────┐    ┌──────────┐    ┌──────────────┐    ┌──────┴──────┐       │
│  │ Lago     │◀───│ RabbitMQ │───▶│ Fulfillment  │    │ Akeneo PIM  │       │
│  │(Billing) │    │ (Events) │    │ (Delivery)   │    │ (Catalog)   │       │
│  └──────────┘    └────┬─────┘    └──────┬───────┘    └─────────────┘       │
│                       │                  │                                   │
│                       ▼                  ▼                                   │
│  ┌──────────┐    ┌──────────┐    ┌──────────────┐    ┌─────────────┐       │
│  │  MinIO   │    │  Redis   │    │ OSRM+Leaflet │    │ SMS Service │       │
│  │ (Images) │    │ (Cache)  │    │ (Routing)    │    │ (Alerts)    │       │
│  └──────────┘    └──────────┘    └──────────────┘    └─────────────┘       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │                    PAYMENT GATEWAY LAYER                         │       │
│  │  ┌────────┐    ┌────────┐    ┌─────────────┐    ┌───────────┐  │       │
│  │  │ bKash  │    │ Nagad  │    │ SSLCommerz  │    │    COD    │  │       │
│  │  │Checkout│    │  PGW   │    │(Visa/Master)│    │ (Manual)  │  │       │
│  │  └────────┘    └────────┘    └─────────────┘    └───────────┘  │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. API Mapping — Service-to-Service

| Business Function | Primary Service | API Pattern | Event Published |
|-------------------|----------------|-------------|-----------------|
| Customer Register | Keycloak | REST `/users` | `user.created` |
| Vendor Register | Keycloak + MedusaJS | REST | `vendor.onboarded` |
| Add to Cart | MedusaJS | REST `/store/carts` | — |
| Place Order | MedusaJS | REST `/store/carts/:id/complete` | `order.placed` |
| Process Payment | bKash/Nagad/SSL | REST (provider-specific) | `payment.captured` |
| Assign Rider | Fulfillment Svc | Internal gRPC | `fulfillment.assigned` |
| Update Inventory | MedusaJS | REST `/admin/inventory-items` | `inventory.updated` |
| Generate Invoice | Lago | REST `/api/v1/invoices` | `invoice.generated` |
| Search Products | Typesense | REST `/collections/products/documents/search` | — |
| Track Delivery | OSRM + WebSocket | WS `/tracking/:orderId` | `delivery.status_changed` |
| Catalog Sync | Akeneo → MedusaJS | Webhook/Cron | `product.synced` |
| Subscription Billing | Lago | Cron (monthly) | `subscription.invoiced` |

---

## 7. Deployment Topology

```yaml
# Kubernetes namespace layout
namespaces:
  - marketplace-core      # MedusaJS, Redis, PostgreSQL
  - marketplace-search    # Typesense cluster (3 nodes)
  - marketplace-billing   # Lago + Lago UI
  - marketplace-pim       # Akeneo/Pimcore + MySQL
  - marketplace-infra     # RabbitMQ, MinIO, Kong, Keycloak
  - marketplace-delivery  # OSRM, Rider service, Tracking WS
  - marketplace-frontend  # Next.js storefront, Admin panel
```

---

## 8. Cost Estimation (Bangladesh Market)

| Component | Hosting (Monthly) | Notes |
|-----------|-------------------|-------|
| 3-node K8s cluster (8vCPU, 16GB each) | BDT 25,000–40,000 | DigitalOcean / local VPS |
| bKash merchant fees | 1.5% per transaction | Deducted from settlement |
| Nagad merchant fees | 1.2% per transaction | Deducted from settlement |
| SSLCommerz fees | 2.0–2.5% per card txn | Monthly minimum applies |
| Domain + SSL | BDT 2,000/year | .com.bd domain |
| SMS (Alpha/Infobip) | BDT 0.25–0.50/SMS | Bulk rate |
| **Total infrastructure** | **~BDT 30,000–50,000/mo** | Before revenue |

---

## 9. Security & Compliance

- **Bangladesh Bank regulations**: E-commerce payments must go through licensed PSPs
- **NID verification**: Required for vendor onboarding (Bangladesh National ID)
- **TIN/BIN**: Tax registration required for invoicing
- **Data residency**: Customer PII should be stored within BD or compliant jurisdiction
- **PCI-DSS**: Not required if using tokenized flows (bKash, Nagad) or hosted payment pages (SSLCommerz)
- **SSL/TLS**: All API endpoints must use HTTPS
- **RBAC**: Keycloak enforces vendor isolation (vendor A cannot see vendor B data)

---

## 10. Quickstart — MVP in 4 Weeks

| Week | Milestone |
|------|-----------|
| 1 | Deploy MedusaJS + PostgreSQL + Redis. Import seed catalog (500 SKUs from Open Food Facts). Setup Keycloak. |
| 2 | Integrate bKash sandbox. Build storefront (Next.js). Enable cart + checkout flow. |
| 3 | Add Typesense search. Vendor onboarding flow. Nagad sandbox integration. |
| 4 | Fulfillment module (basic: manual assignment). SSLCommerz integration. Go-live with 5 pilot vendors. |

---

## References

- [MedusaJS Documentation](https://docs.medusajs.com/)
- [Open Food Facts API](https://wiki.openfoodfacts.org/API)
- [bKash Merchant API](https://developer.bka.sh/)
- [Nagad PGW Docs](https://nagad.com.bd/merchant/)
- [SSLCommerz API](https://developer.sslcommerz.com/)
- [Typesense Docs](https://typesense.org/docs/)
- [Lago Billing](https://www.getlago.com/docs)
- [Akeneo PIM CE](https://www.akeneo.com/community-edition/)
- [OSRM (Routing)](https://project-osrm.org/)
- [GS1 Bangladesh](https://www.gs1bd.org/)

---

*Document created: 2026-06-07 | Target market: Bangladesh | Stack: MedusaJS + Akeneo + Typesense + Lago + bKash + Nagad + SSLCommerz*
