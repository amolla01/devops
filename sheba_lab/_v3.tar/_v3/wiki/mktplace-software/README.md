# Marketplace Software Deployment — User Guide

## Overview

This guide covers deploying the **Auto Parts Marketplace** stack to a Kubernetes cluster running on OpenStack Nova VMs. The deployment uses a 2-playbook air-gapped pattern:

| Playbook | What It Does | Internet Required? |
|----------|--------------|-------------------|
| `preflight_marketplace.yml` | Downloads all container images, Helm charts, and application dependencies to local cache | **Yes** (one-time) |
| `deploy_marketplace.yml` | Pushes cached artifacts to local registry, deploys all services with HPA scaling | **No** (fully air-gapped) |

---

## Prerequisites

| Requirement | Details |
|-------------|---------|
| Kubernetes cluster | Deployed via `deploy_kubespray.yml` (6 nodes, v1.29.4) |
| Ansible | v2.15+ on deployer (Lab-ControlNode / WSL2) |
| kubectl | Configured with kubeconfig for target cluster |
| Helm | v3.14+ installed on deployer |
| Docker | Running on R810 (172.16.2.1) for local registry |
| Disk space | ~15GB free at `/opt/fabric-cache/marketplace/` |
| Network | Deployer can reach internet (preflight) and K8s nodes (deploy) |

---

## Quick Start

```bash
# From the deployer (Lab-ControlNode):
cd /path/to/data-center/_v3

# 1. Run preflight (downloads everything — requires internet)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/preflight_marketplace.yml -v

# 2. Deploy to cluster (air-gapped)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml -v
```

---

## Preflight Playbook (`preflight_marketplace.yml`)

### What It Downloads

| Category | Location | Examples |
|----------|----------|----------|
| Container images | `/opt/fabric-cache/marketplace/images/` | medusa, postgres, redis, rabbitmq, typesense, lago, pimcore, rancher, nginx |
| Helm charts | `/opt/fabric-cache/marketplace/helm-charts/` | postgresql, redis, rabbitmq, prometheus, grafana, metrics-server, cert-manager, rancher |
| Composer deps | `/opt/fabric-cache/marketplace/composer/` | Pimcore skeleton + vendor packages |
| Node modules | `/opt/fabric-cache/marketplace/node-modules/` | MedusaJS dependencies |
| Seed data | `/opt/fabric-cache/marketplace/seed-data/` | ACES/PIES fitment placeholder files |

### Running Specific Phases

```bash
# Only download container images
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/preflight_marketplace.yml --tags images -v

# Only download Helm charts
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/preflight_marketplace.yml --tags helm_charts -v

# Only download Node/Composer deps
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/preflight_marketplace.yml --tags node_modules,composer -v
```

### Verifying Preflight Success

```bash
# Check images are cached
ls -la /opt/fabric-cache/marketplace/images/*.tar | wc -l
# Expected: ~15 tar files

# Check Helm charts
ls /opt/fabric-cache/marketplace/helm-charts/*.tgz
# Expected: 9 chart archives

# Check total cache size
du -sh /opt/fabric-cache/marketplace/
# Expected: ~8-12GB
```

---

## Deploy Playbook (`deploy_marketplace.yml`)

### Deployment Phases

| Phase | Tag | What It Does |
|-------|-----|--------------|
| 1 | `registry` | Starts local registry on 172.16.2.1:5000, pushes all cached images |
| 2 | `infra` | Deploys PostgreSQL, Redis, RabbitMQ via Helm into `marketplace` namespace |
| 3 | `apps` | Deploys MedusaJS, Typesense, Lago API as Kubernetes Deployments + Services |
| 4 | `scaling` | Deploys metrics-server, cert-manager, Rancher, configures HPA policies |
| 5 | `monitoring` | Deploys Prometheus + Grafana into `monitoring` namespace |

### Running Specific Phases

```bash
# Only push images to registry
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags registry -v

# Only deploy infrastructure (DB, cache, queue)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags infra -v

# Only deploy applications
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags apps -v

# Only configure scaling (HPA + Rancher)
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags scaling -v

# Only deploy monitoring
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags monitoring -v
```

### Overriding Defaults

Pass extra variables to customize the deployment:

```bash
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml -v \
  -e "local_registry=192.168.1.100:5000" \
  -e "medusa_max_replicas=15" \
  -e "rancher_hostname=rancher.mycompany.com" \
  -e "kubeconfig_path=/home/deployer/.kube/config"
```

| Variable | Default | Description |
|----------|---------|-------------|
| `local_registry` | `172.16.2.1:5000` | Container registry address |
| `kubeconfig_path` | `/etc/kubernetes/admin.conf` | Path to kubeconfig |
| `marketplace_namespace` | `marketplace` | K8s namespace for app services |
| `medusa_min_replicas` | `2` | HPA minimum pods for MedusaJS |
| `medusa_max_replicas` | `10` | HPA maximum pods for MedusaJS |
| `typesense_max_replicas` | `3` | HPA maximum pods for Typesense |
| `lago_max_replicas` | `4` | HPA maximum pods for Lago |
| `rancher_hostname` | `rancher.marketplace.local` | Rancher UI hostname |
| `rancher_bootstrap_password` | `admin` | Initial Rancher admin password |
| `postgres_version` | `16-alpine` | PostgreSQL image tag |
| `redis_version` | `7-alpine` | Redis image tag |
| `medusa_version` | `latest` | MedusaJS image tag |
| `typesense_version` | `27.1` | Typesense image tag |
| `lago_version` | `v1.19.0` | Lago API image tag |

---

## Post-Deployment Verification

### Check All Pods Are Running

```bash
kubectl get pods -n marketplace
# Expected: medusa (2 pods), typesense (1), lago-api (1),
#           postgresql (1), redis (1), rabbitmq (1)

kubectl get pods -n cattle-system
# Expected: rancher (1 pod)

kubectl get pods -n monitoring
# Expected: prometheus-server (1), grafana (1)
```

### Check HPA Status

```bash
kubectl get hpa -n marketplace
# NAME            REFERENCE       TARGETS         MINPODS   MAXPODS   REPLICAS
# medusa-hpa      Deployment/medusa    12%/70%    2         10        2
# typesense-hpa   Deployment/typesense  8%/75%    1         3         1
# lago-hpa        Deployment/lago-api   5%/75%    1         4         1
```

### Access Services

| Service | Access Method |
|---------|--------------|
| Rancher UI | `https://rancher.marketplace.local` (or port-forward: `kubectl port-forward svc/rancher 8443:443 -n cattle-system`) |
| Grafana | `kubectl port-forward svc/grafana 3000:80 -n monitoring` |
| Prometheus | `kubectl port-forward svc/prometheus-server 9090:80 -n monitoring` |
| MedusaJS API | `kubectl port-forward svc/medusa 9000:9000 -n marketplace` |
| Typesense | `kubectl port-forward svc/typesense 8108:8108 -n marketplace` |

---

## Seasonal Scaling Operations

The auto parts business has predictable seasonal demand. Adjust HPA minimums via Rancher UI or kubectl:

### Manual Season Switch

```bash
# Spring (March): increase baseline for car maintenance season
kubectl patch hpa medusa-hpa -n marketplace \
  --type='merge' -p '{"spec":{"minReplicas":3}}'

# Fall (September): pre-scale for Black Friday
kubectl patch hpa medusa-hpa -n marketplace \
  --type='merge' -p '{"spec":{"minReplicas":4}}'

# Summer (June): return to baseline
kubectl patch hpa medusa-hpa -n marketplace \
  --type='merge' -p '{"spec":{"minReplicas":2}}'
```

### Via Rancher UI

1. Log in to Rancher → select `marketplace` cluster
2. Navigate to **Workloads → HorizontalPodAutoscalers**
3. Click `medusa-hpa` → Edit YAML
4. Change `minReplicas` value → Save

---

## Troubleshooting

### Images Fail to Push to Registry

```bash
# Verify registry is running
curl -s http://172.16.2.1:5000/v2/_catalog | jq .

# Check Docker can reach registry
docker pull 172.16.2.1:5000/marketplace/medusa:latest

# If "connection refused": restart registry
docker restart marketplace-registry
```

### Helm Install Fails

```bash
# Check chart file exists
ls /opt/fabric-cache/marketplace/helm-charts/

# Verify Helm can communicate with cluster
helm list -A

# Check namespace exists
kubectl get namespace marketplace
```

### HPA Shows "Unknown" Targets

```bash
# metrics-server must be running
kubectl get pods -n kube-system | grep metrics-server

# Check metrics are flowing
kubectl top pods -n marketplace

# If "error: Metrics API not available":
# Re-deploy metrics-server
ansible-playbook -i inventory/hosts.yml \
  playbooks/reused/deploy_marketplace.yml --tags scaling -v
```

### Pod OOMKilled

```bash
# Check which pod was killed
kubectl get events -n marketplace --sort-by='.lastTimestamp' | grep OOM

# Increase memory limits for that deployment
kubectl set resources deployment/medusa -n marketplace \
  --limits=memory=4Gi
```

---

## Uninstall / Cleanup

```bash
# Remove marketplace applications
kubectl delete namespace marketplace

# Remove Rancher
helm uninstall rancher -n cattle-system
kubectl delete namespace cattle-system

# Remove monitoring
helm uninstall prometheus grafana -n monitoring
kubectl delete namespace monitoring

# Remove local registry (on R810)
docker stop marketplace-registry
docker rm marketplace-registry

# Clear cache (optional)
rm -rf /opt/fabric-cache/marketplace/
```

---

## Related Documents

| Document | Location |
|----------|----------|
| Architecture (HTML) | `cheat-sheet/13-openstack-auto-parts-marketplace-architecture.html` |
| Scaling Guide (MD) | `cheat-sheet/14-marketplace-kubernetes-scaling-guide.md` |
| Preflight Playbook | `playbooks/reused/preflight_marketplace.yml` |
| Deploy Playbook | `playbooks/reused/deploy_marketplace.yml` |
| KubeSpray Deploy | `playbooks/reused/deploy_kubespray.yml` |
