# Product Data Sourcing & Bengali (বাংলা) Language Strategy

## Research Summary

**Question 1:** Is there a trusted and easy way to gather product data sold in Grocery Store / Kacha-Bazar to pre-populate the product DB?

**Question 2:** How should language customization work — Bengali stored in DB, or side-by-side English/Bengali via AI NLP at the GUI layer?

**Answer:** Use a **hybrid approach** — store BOTH English and Bengali as first-class columns in PostgreSQL (not one or the other), pre-populate from trusted sources, then use self-hosted AI translation (LibreTranslate) for bulk initial seeding, with human review. The GUI shows **both languages side-by-side** with user toggle.

---

## Part 1: Trusted Product Data Sources for BD Kacha-Bazar

### The Reality

Bangladesh kacha-bazar (কাঁচাবাজার) products are 80% **unbranded fresh produce** (vegetables, fish, rice, spices) — these do NOT exist in global barcode databases. You need a **multi-source strategy**:

### Source Ranking (Most Trusted → Least)

| # | Source | Trust | Coverage | Cost | Best For |
|---|--------|-------|----------|------|----------|
| 1 | **Manual Curation (Human)** | ⭐⭐⭐⭐⭐ | Targeted top 500 SKUs | Labor: 2-3 days | Unbranded produce (vegetables, fish, rice) |
| 2 | **Open Food Facts API** | ⭐⭐⭐⭐ | 3M+ products, growing BD | Free | Branded packaged goods (Pran, ACI, Teer) |
| 3 | **GS1 Bangladesh** (gs1bd.org) | ⭐⭐⭐⭐⭐ | Official barcode registry | Membership fee | Barcode validation for packaged items |
| 4 | **BSTI Product Registry** | ⭐⭐⭐⭐⭐ | Govt-registered food items | Public/RTI | Regulatory compliance check |
| 5 | **Vendor Self-Upload** | ⭐⭐⭐⭐ | Vendor's own SKUs | Free (onboarding) | Fresh produce, local specialties |
| 6 | **Chaldal/Shwapno/Meena Bazar** (public catalog reference) | ⭐⭐⭐ | ~10K-30K SKUs | Research only (no scraping) | Category taxonomy, pricing benchmarks |

### Why Global Databases Fail for Kacha-Bazar

- **Open Food Facts**: Excellent for packaged goods (Radhuni spices, Teer oil, Pran juice) but has **zero entries** for "1 kg ilish maach" or "দেশি টমেটো"
- **UPC databases**: Bangladesh produce has no barcodes
- **Google Shopping API**: Not available in BD

### ✅ Recommended Strategy: 3-Layer Approach

```
Layer 1: Manual Seed Catalog (500-800 SKUs)
    → Fresh produce, fish, meat, daily essentials
    → Created by a local Bangla-speaking team in 2-3 days
    → This is the ONLY reliable source for kacha-bazar items

Layer 2: Open Food Facts API Import (1000-2000 SKUs)
    → All branded/packaged items sold in BD
    → Automated ETL pipeline
    → Covers: Pran, ACI, Square, Teer, Meghna, etc.

Layer 3: Vendor Self-Upload (ongoing)
    → Each vendor adds their unique items at onboarding
    → Admin review before publishing
    → Grows the catalog organically
```

### Layer 1: Manual Seed Catalog — Template

This is the **most important step** for kacha-bazar. No API can give you this.

```sql
-- The seed catalog CSV/Excel template vendors/team fill in:
CREATE TABLE seed_catalog (
    id SERIAL PRIMARY KEY,
    sku VARCHAR(20) NOT NULL UNIQUE,          -- e.g., "VEG-TOM-001"
    name_bn VARCHAR(200) NOT NULL,            -- "দেশি টমেটো"
    name_en VARCHAR(200) NOT NULL,            -- "Deshi Tomato (Local)"
    category_bn VARCHAR(100) NOT NULL,        -- "সবজি"
    category_en VARCHAR(100) NOT NULL,        -- "Vegetables"
    unit VARCHAR(20) NOT NULL,                -- "kg", "piece", "dozen", "liter"
    typical_price_bdt DECIMAL(10,2),          -- 80.00
    image_placeholder VARCHAR(50),            -- "tomato.webp"
    is_seasonal BOOLEAN DEFAULT FALSE,
    season_months VARCHAR(50),                -- "Nov-Mar"
    shelf_life_days INT,                      -- 5
    storage_temp VARCHAR(20),                 -- "cool-dry"
    tags TEXT[]                               -- '{দেশি, fresh, সবজি}'
);
```

**Example seed data (what the team fills):**

| SKU | name_bn | name_en | category_en | unit | price_bdt |
|-----|---------|---------|-------------|------|-----------|
| VEG-TOM-001 | দেশি টমেটো | Deshi Tomato | Vegetables | kg | 80 |
| VEG-POT-001 | আলু (ময়মনসিংহ) | Potato (Mymensingh) | Vegetables | kg | 35 |
| FSH-ILS-001 | ইলিশ মাছ (পদ্মা) | Hilsa Fish (Padma) | Fish | kg | 1200 |
| RCE-MIN-001 | মিনিকেট চাল | Miniket Rice | Rice & Grains | kg | 65 |
| SPK-TRM-001 | হলুদ গুঁড়া | Turmeric Powder | Spices | 200g | 45 |
| DAI-MLK-001 | তরল দুধ (আড়ং) | Liquid Milk (Aarong) | Dairy | liter | 92 |
| OIL-SOY-001 | তীর সয়াবিন তেল | Teer Soybean Oil | Cooking Oil | 5L | 890 |
| EGG-HEN-001 | মুরগির ডিম | Chicken Eggs | Eggs | dozen | 160 |

### Layer 2: Open Food Facts — Automated ETL

```python
"""
ETL Script: Import branded BD grocery products from Open Food Facts
Trusted source - community-maintained, 3M+ products, free API
"""
import requests
import psycopg2
from psycopg2.extras import execute_values
import time

OFF_API = "https://world.openfoodfacts.org/cgi/search.pl"

BD_GROCERY_CATEGORIES = [
    "rice", "lentils", "dal", "cooking oil", "soybean oil", "mustard oil",
    "milk", "yogurt", "ghee", "tea", "biscuits", "noodles", "juice",
    "spices", "turmeric", "chili powder", "salt", "sugar", "flour",
    "soap", "shampoo", "toothpaste", "detergent", "snacks"
]

def fetch_products(search_term: str, country="bangladesh", page_size=100) -> list:
    """Fetch from Open Food Facts. Rate limit: 100 req/min for non-app users."""
    params = {
        "search_terms": search_term,
        "countries_tags": country,
        "json": 1,
        "page_size": page_size,
        "fields": "code,product_name,product_name_bn,brands,categories_tags,"
                  "image_url,image_small_url,quantity,nutriments,stores,labels_tags"
    }
    resp = requests.get(OFF_API, params=params, timeout=30,
                        headers={"User-Agent": "GroceryMarketplaceBD/1.0"})
    resp.raise_for_status()
    return resp.json().get("products", [])


def normalize(raw: dict) -> dict:
    """Transform Open Food Facts JSON → our DB schema."""
    return {
        "barcode": raw.get("code"),
        "name_en": (raw.get("product_name") or "").strip(),
        "name_bn": (raw.get("product_name_bn") or "").strip() or None,  # May be empty
        "brand": (raw.get("brands") or "Unknown").split(",")[0].strip(),
        "category": next(
            (c.replace("en:", "") for c in (raw.get("categories_tags") or [])
             if c.startswith("en:")),
            "uncategorized"
        ),
        "image_url": raw.get("image_url"),
        "weight": raw.get("quantity", ""),
        "calories_per_100g": (raw.get("nutriments") or {}).get("energy-kcal_100g"),
    }


def bulk_insert(products: list, conn):
    """Upsert products into catalog (idempotent)."""
    if not products:
        return
    cur = conn.cursor()
    sql = """
        INSERT INTO product_catalog (barcode, name_en, name_bn, brand, category,
                                     image_url, weight, calories_per_100g)
        VALUES %s
        ON CONFLICT (barcode) DO UPDATE SET
            name_en = EXCLUDED.name_en,
            name_bn = COALESCE(EXCLUDED.name_bn, product_catalog.name_bn),
            brand = EXCLUDED.brand,
            image_url = COALESCE(EXCLUDED.image_url, product_catalog.image_url)
    """
    values = [(p["barcode"], p["name_en"], p["name_bn"], p["brand"],
               p["category"], p["image_url"], p["weight"], p["calories_per_100g"])
              for p in products if p["barcode"]]
    execute_values(cur, sql, values)
    conn.commit()
    print(f"  Upserted {len(values)} products")


def main():
    conn = psycopg2.connect("dbname=marketplace user=app host=localhost")
    total = 0
    for cat in BD_GROCERY_CATEGORIES:
        print(f"Fetching: {cat}...")
        products = fetch_products(cat)
        normalized = [normalize(p) for p in products]
        bulk_insert(normalized, conn)
        total += len(normalized)
        time.sleep(1)  # Rate limit courtesy
    print(f"\n✅ Total imported: {total} products")
    conn.close()

if __name__ == "__main__":
    main()
```

### Layer 3: Vendor Self-Upload (Onboarding Form)

```yaml
# Vendor onboarding product upload form fields
vendor_product_form:
  required:
    - product_name_bn: "পণ্যের নাম (বাংলায়)"    # Required in Bangla
    - product_name_en: "Product Name (English)"   # Required in English
    - category: "Select category"                 # Dropdown (pre-built taxonomy)
    - unit: "kg / piece / liter / pack"           # Standard units
    - price_bdt: "Price (৳)"                      # In BDT
    - image: "Product photo"                      # Camera upload (mobile)
  optional:
    - barcode: "Barcode (if packaged)"
    - brand: "Brand name"
    - weight: "Net weight"
    - description_bn: "বিবরণ"
    - shelf_life: "Shelf life (days)"
```

---

## Part 2: Language Strategy — The Right Architecture

### ❌ Wrong Approach: Bengali Only in DB, English at GUI

This fails because:
- Search won't work across languages
- SEO requires both-language URLs
- Admin/vendor may prefer English; customer prefers Bengali
- AI translation at runtime adds latency (200-500ms per request)

### ❌ Wrong Approach: English Only in DB, Translate at GUI via AI

This fails because:
- Bengali product names are PROPER NOUNS — AI will mistranslate ("মিনিকেট চাল" is NOT "miniket floor")
- Runtime translation is slow and expensive
- Grocery names have regional variants AI doesn't know

### ✅ Correct Approach: Both Languages as First-Class DB Columns + AI for Initial Bulk Seed

```
┌────────────────────────────────────────────────────────────────────┐
│                    DATA LAYER (PostgreSQL)                          │
│                                                                    │
│  products table:                                                   │
│    name_en     VARCHAR(200) NOT NULL                                │
│    name_bn     VARCHAR(200) NOT NULL                                │
│    desc_en     TEXT                                                 │
│    desc_bn     TEXT                                                 │
│    category_en VARCHAR(100)                                         │
│    category_bn VARCHAR(100)                                         │
│                                                                    │
│  → BOTH columns required at insert time                            │
│  → Searchable in BOTH languages via Typesense                      │
│  → No runtime translation needed                                   │
├────────────────────────────────────────────────────────────────────┤
│                    GUI LAYER (Next.js + i18next)                    │
│                                                                    │
│  User selects language → "bn" or "en"                              │
│  API returns the correct column based on locale                    │
│  Both shown side-by-side in admin/vendor panel                     │
│  Customer sees ONLY their chosen language                          │
└────────────────────────────────────────────────────────────────────┘
```

### Database Schema — Dual-Language (The Right Way)

```sql
-- Products table: both languages are REQUIRED, not optional
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(30) UNIQUE NOT NULL,
    barcode VARCHAR(20),

    -- ═══ DUAL LANGUAGE COLUMNS ═══
    name_en VARCHAR(200) NOT NULL,
    name_bn VARCHAR(200) NOT NULL,         -- বাংলা নাম (required!)
    description_en TEXT,
    description_bn TEXT,

    -- Category (dual)
    category_id UUID REFERENCES categories(id),

    -- Pricing & Units
    unit VARCHAR(20) NOT NULL,             -- "kg", "piece", "liter", "pack"
    unit_label_bn VARCHAR(20) NOT NULL,    -- "কেজি", "পিস", "লিটার", "প্যাক"
    price_bdt DECIMAL(10,2) NOT NULL,

    -- Metadata
    brand VARCHAR(100),
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    vendor_id UUID REFERENCES vendors(id),

    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Categories: also dual-language
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(50) UNIQUE NOT NULL,      -- "vegetables"
    name_en VARCHAR(100) NOT NULL,         -- "Vegetables"
    name_bn VARCHAR(100) NOT NULL,         -- "সবজি"
    parent_id UUID REFERENCES categories(id),
    icon VARCHAR(10),                      -- emoji "🥬"
    sort_order INT DEFAULT 0
);

-- Seed categories
INSERT INTO categories (slug, name_en, name_bn, icon, sort_order) VALUES
('vegetables',    'Vegetables',      'সবজি',          '🥬', 1),
('fruits',        'Fruits',          'ফলমূল',         '🍎', 2),
('fish',          'Fish',            'মাছ',           '🐟', 3),
('meat',          'Meat & Poultry',  'মাংস ও মুরগি',  '🥩', 4),
('rice-grains',   'Rice & Grains',   'চাল ও শস্য',    '🌾', 5),
('lentils',       'Lentils & Pulses','ডাল',           '🫘', 6),
('spices',        'Spices',          'মশলা',          '🌶️', 7),
('cooking-oil',   'Cooking Oil',     'রান্নার তেল',    '🫒', 8),
('dairy',         'Dairy & Eggs',    'দুধ ও ডিম',     '🥛', 9),
('snacks',        'Snacks',          'নাস্তা',        '🍪', 10),
('beverages',     'Beverages',       'পানীয়',         '🧃', 11),
('household',     'Household',       'গৃহস্থালি',      '🧹', 12),
('baby',          'Baby & Kids',     'শিশু',          '👶', 13),
('personal-care', 'Personal Care',   'ব্যক্তিগত যত্ন', '🧴', 14);
```

### Typesense Search Index — Multi-Language

```json
{
  "name": "products",
  "fields": [
    {"name": "name_en", "type": "string", "locale": "en"},
    {"name": "name_bn", "type": "string", "locale": "bn"},
    {"name": "description_en", "type": "string", "locale": "en", "optional": true},
    {"name": "description_bn", "type": "string", "locale": "bn", "optional": true},
    {"name": "category_en", "type": "string", "facet": true},
    {"name": "category_bn", "type": "string", "facet": true},
    {"name": "brand", "type": "string", "facet": true, "optional": true},
    {"name": "price_bdt", "type": "float", "facet": true},
    {"name": "unit", "type": "string", "facet": true},
    {"name": "is_active", "type": "bool"}
  ],
  "default_sorting_field": "price_bdt",
  "token_separators": ["-", "/"],
  "enable_nested_fields": false
}
```

**Search query (customer searching in Bengali):**
```bash
curl "http://typesense:8108/collections/products/documents/search" \
  -H "X-TYPESENSE-API-KEY: ${KEY}" \
  -d '{
    "q": "আলু",
    "query_by": "name_bn,description_bn,category_bn",
    "filter_by": "is_active:true",
    "sort_by": "price_bdt:asc",
    "per_page": 20
  }'
```

**Search query (same customer searching mixed Bangla+English):**
```bash
# Typesense handles this by searching BOTH language fields
curl ... -d '{
    "q": "Teer oil",
    "query_by": "name_en,name_bn,brand",
    "filter_by": "is_active:true"
  }'
```

---

## Part 3: AI Translation — ONLY for Initial Bulk Seed (Not Runtime)

### When to Use AI Translation

| Scenario | Use AI? | Why |
|----------|---------|-----|
| Initial seed: translate 2000 packaged product names from English→Bengali | ✅ YES | One-time batch, human-reviewed after |
| Runtime: customer views product page | ❌ NO | Too slow, use pre-stored `name_bn` column |
| Vendor uploads product in Bengali only | ✅ YES | Auto-fill `name_en` as draft, vendor confirms |
| Admin adds category | ❌ NO | Only 15 categories, translate manually |

### Self-Hosted Translation: LibreTranslate (No Cloud API Costs)

```yaml
# docker-compose.yml — self-hosted translation
services:
  libretranslate:
    image: libretranslate/libretranslate:v1.9.6
    ports:
      - "5000:5000"
    environment:
      - LT_LOAD_ONLY=en,bn    # Only load English ↔ Bengali models
      - LT_DISABLE_WEB_UI=true
      - LT_API_KEYS=true
      - LT_REQUIRE_API_KEY_ORIGIN=*
    volumes:
      - lt-models:/home/libretranslate/.local
    deploy:
      resources:
        limits:
          memory: 2G    # Bengali model needs ~1.5GB RAM

volumes:
  lt-models:
```

### Batch Translation Script (One-Time Seed)

```python
"""
One-time batch translation for seed catalog.
Uses self-hosted LibreTranslate (free, no API costs).
Results are REVIEWED by human before publishing.
"""
import requests
import psycopg2
import time

LT_URL = "http://localhost:5000/translate"

def translate_en_to_bn(text: str) -> str:
    """Translate English → Bengali via self-hosted LibreTranslate."""
    if not text or not text.strip():
        return ""
    resp = requests.post(LT_URL, json={
        "q": text,
        "source": "en",
        "target": "bn",
        "api_key": "your-local-key"  # Self-hosted, free
    }, timeout=10)
    resp.raise_for_status()
    return resp.json()["translatedText"]


def translate_bn_to_en(text: str) -> str:
    """Translate Bengali → English via self-hosted LibreTranslate."""
    resp = requests.post(LT_URL, json={
        "q": text,
        "source": "bn",
        "target": "en",
        "api_key": "your-local-key"
    }, timeout=10)
    resp.raise_for_status()
    return resp.json()["translatedText"]


def fill_missing_translations(conn):
    """Find products missing Bengali names, translate, flag for review."""
    cur = conn.cursor()
    # Products that have English name but no Bengali
    cur.execute("""
        SELECT id, name_en FROM products
        WHERE name_bn IS NULL OR name_bn = ''
        LIMIT 100
    """)
    rows = cur.fetchall()
    print(f"Found {len(rows)} products needing Bengali translation...")

    for product_id, name_en in rows:
        try:
            name_bn = translate_en_to_bn(name_en)
            cur.execute("""
                UPDATE products
                SET name_bn = %s, translation_status = 'ai_draft'
                WHERE id = %s
            """, (name_bn, product_id))
            print(f"  ✓ '{name_en}' → '{name_bn}'")
            time.sleep(0.5)  # Don't hammer local service
        except Exception as e:
            print(f"  ✗ Failed for '{name_en}': {e}")

    conn.commit()
    print(f"\n✅ Translated {len(rows)} products (marked as 'ai_draft' for human review)")


if __name__ == "__main__":
    conn = psycopg2.connect("dbname=marketplace user=app host=localhost")
    fill_missing_translations(conn)
    conn.close()
```

### Translation Review Workflow

```
Product Added (English only)
       ↓
AI translates → name_bn (draft)        ← translation_status = 'ai_draft'
       ↓
Human reviewer sees in Admin Panel      ← Queue of drafts to approve
       ↓
Reviewer corrects if needed → Approve   ← translation_status = 'verified'
       ↓
Product goes LIVE on storefront
```

```sql
-- Translation status column
ALTER TABLE products ADD COLUMN translation_status VARCHAR(20)
    DEFAULT 'verified'
    CHECK (translation_status IN ('verified', 'ai_draft', 'needs_review'));

-- Admin query: "Show me AI translations needing review"
SELECT id, name_en, name_bn, translation_status
FROM products
WHERE translation_status = 'ai_draft'
ORDER BY created_at DESC;
```

---

## Part 4: GUI — Side-by-Side English/Bengali (next-i18next)

### Architecture Decision

| Concern | Decision | Reasoning |
|---------|----------|-----------|
| What does the customer see? | **Single language** (based on toggle/cookie) | Clean UI, no clutter |
| What does the vendor see? | **Side-by-side** (both languages in form) | They MUST provide both |
| What does admin see? | **Side-by-side** with edit capability | Quality control |
| Where does translation happen? | **Database layer** (pre-stored) | Zero runtime latency |
| What does search use? | **Both columns** (query_by: name_en, name_bn) | Customer can type in either |

### Next.js i18n Setup (next-i18next v16)

```bash
npm install next-i18next i18next react-i18next
```

**File structure:**
```
app/
  i18n/
    locales/
      en/
        common.json
        products.json
      bn/
        common.json
        products.json
  [lng]/
    layout.tsx
    page.tsx
    products/
      [id]/
        page.tsx
```

**Translation files:**

```json
// app/i18n/locales/en/common.json
{
  "nav": {
    "home": "Home",
    "categories": "Categories",
    "cart": "Cart",
    "orders": "My Orders",
    "account": "Account"
  },
  "search": {
    "placeholder": "Search for groceries...",
    "no_results": "No products found"
  },
  "units": {
    "kg": "kg",
    "piece": "piece",
    "dozen": "dozen",
    "liter": "liter",
    "pack": "pack"
  },
  "currency": "৳",
  "add_to_cart": "Add to Cart",
  "buy_now": "Buy Now"
}
```

```json
// app/i18n/locales/bn/common.json
{
  "nav": {
    "home": "হোম",
    "categories": "ক্যাটাগরি",
    "cart": "কার্ট",
    "orders": "আমার অর্ডার",
    "account": "অ্যাকাউন্ট"
  },
  "search": {
    "placeholder": "মুদি খুঁজুন...",
    "no_results": "কোনো পণ্য পাওয়া যায়নি"
  },
  "units": {
    "kg": "কেজি",
    "piece": "পিস",
    "dozen": "ডজন",
    "liter": "লিটার",
    "pack": "প্যাক"
  },
  "currency": "৳",
  "add_to_cart": "কার্টে যোগ করুন",
  "buy_now": "এখনই কিনুন"
}
```

### i18n Config

```typescript
// i18n.config.ts
import type { I18nConfig } from 'next-i18next/proxy'

const i18nConfig: I18nConfig = {
  supportedLngs: ['bn', 'en'],          // Bengali is DEFAULT (most users)
  fallbackLng: 'bn',                     // Fallback to Bengali
  defaultNS: 'common',
  ns: ['common', 'products', 'checkout'],
  hideDefaultLocale: true,               // /products (Bengali), /en/products (English)
  resourceLoader: (language, namespace) =>
    import(`./app/i18n/locales/${language}/${namespace}.json`),
}

export default i18nConfig
```

### Product Card Component (Shows Correct Language)

```tsx
// app/[lng]/components/ProductCard.tsx
'use client'
import { useT } from 'next-i18next/client'
import { useParams } from 'next/navigation'

interface Product {
  id: string
  name_en: string
  name_bn: string
  price_bdt: number
  unit: string
  unit_label_bn: string
  image_url: string
  category_en: string
  category_bn: string
}

export function ProductCard({ product }: { product: Product }) {
  const { t } = useT('common')
  const { lng } = useParams()

  // Pick the correct language column — NO runtime translation
  const name = lng === 'bn' ? product.name_bn : product.name_en
  const category = lng === 'bn' ? product.category_bn : product.category_en
  const unitLabel = lng === 'bn' ? product.unit_label_bn : product.unit

  return (
    <div className="product-card">
      <img src={product.image_url} alt={name} loading="lazy" />
      <span className="category">{category}</span>
      <h3>{name}</h3>
      <p className="price">
        {t('currency')}{product.price_bdt}/{unitLabel}
      </p>
      <button>{t('add_to_cart')}</button>
    </div>
  )
}
```

### API Response — Language-Aware

```typescript
// app/api/products/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const lng = request.headers.get('x-i18next-current-language') || 'bn'

  // Return BOTH language columns; let frontend pick
  // (Alternatively: SELECT only the relevant column for bandwidth savings)
  const products = await db.query(`
    SELECT id, sku, name_en, name_bn, price_bdt, unit, unit_label_bn,
           image_url, category_en, category_bn, brand
    FROM products
    WHERE is_active = true
    ORDER BY sort_order, name_${lng === 'bn' ? 'bn' : 'en'}
    LIMIT 50
  `)

  return NextResponse.json({ products: products.rows, locale: lng })
}
```

### Language Switcher (Customer-Facing)

```tsx
// app/[lng]/components/LanguageSwitcher.tsx
'use client'
import { usePathname, useRouter } from 'next/navigation'

export function LanguageSwitcher() {
  const pathname = usePathname()
  const router = useRouter()

  const switchTo = (locale: string) => {
    const segments = pathname.split('/')
    if (['en', 'bn'].includes(segments[1])) {
      segments[1] = locale
    } else {
      segments.splice(1, 0, locale)
    }
    router.push(segments.join('/'))
  }

  return (
    <div className="lang-switch">
      <button onClick={() => switchTo('bn')}>বাংলা</button>
      <button onClick={() => switchTo('en')}>English</button>
    </div>
  )
}
```

### Vendor Admin — Side-by-Side Input

```tsx
// Vendor product form: BOTH languages required
export function ProductForm() {
  return (
    <form>
      <div className="dual-lang-input">
        <div>
          <label>পণ্যের নাম (বাংলা) *</label>
          <input name="name_bn" required placeholder="যেমন: দেশি টমেটো" dir="ltr" />
        </div>
        <div>
          <label>Product Name (English) *</label>
          <input name="name_en" required placeholder="e.g., Deshi Tomato" />
        </div>
        {/* AI assist button: auto-fills the other language */}
        <button type="button" onClick={autoTranslate}>
          🤖 Auto-fill other language
        </button>
      </div>
      {/* ... rest of form */}
    </form>
  )
}
```

---

## Part 5: Quick Rollout Plan — Error-Free in 2 Weeks

### Week 1: Data + DB

| Day | Task | Output |
|-----|------|--------|
| 1 | Set up PostgreSQL + schema (dual-language tables) | DB ready |
| 1 | Deploy LibreTranslate (Docker) | Translation service up |
| 2-3 | **Manual seed catalog**: Team creates 500 products in Excel (both Bengali/English) | `seed_catalog.csv` |
| 3 | Import seed CSV → PostgreSQL | 500 products in DB |
| 4 | Run Open Food Facts ETL (branded items) | +1500 products |
| 4 | Batch-translate missing Bengali names via LibreTranslate | AI drafts created |
| 5 | **Human review** of AI translations (2 people, 4 hours) | All products verified |

### Week 2: Frontend + Search

| Day | Task | Output |
|-----|------|--------|
| 6 | Set up Typesense, index all products (both languages) | Search working |
| 7 | Next.js storefront with i18next (bn/en), ProductCard | Bengali UI live |
| 8 | Vendor upload form (dual-language, AI assist button) | Vendors can add products |
| 9 | Language switcher, search in both languages | Full i18n |
| 10 | QA: test Bengali rendering, search, category nav | Go-live ready |

### Error Prevention Checklist

```markdown
✅ Bengali font rendering: Use "Noto Sans Bengali" from Google Fonts (free, complete)
✅ Unicode handling: PostgreSQL stores UTF-8 natively — no issues
✅ Typesense Bengali tokenization: Works out-of-box with Unicode
✅ Sort order: Bengali alphabetical sort uses ICU collation in PostgreSQL
✅ Input validation: Allow Bengali Unicode range (U+0980–U+09FF) in forms
✅ Image alt text: Always dual-language (accessibility)
✅ SEO: Separate URLs per language (/en/products/rice vs /products/চাল)
✅ Mobile keyboard: Android/iOS auto-detect Bengali input method
✅ RTL: Bengali is LTR (same as English) — NO RTL issues
✅ Number formatting: Bengali numerals optional (১২৩ vs 123) — keep Arabic numerals for prices
```

### Font Setup (Critical for Bengali Rendering)

```css
/* globals.css */
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap');

:root {
  --font-bn: 'Noto Sans Bengali', 'Kalpurush', sans-serif;
  --font-en: 'Inter', 'Segoe UI', sans-serif;
}

/* Bengali text uses Bengali font */
[lang="bn"] body,
.text-bn {
  font-family: var(--font-bn);
}

/* English remains in English font */
[lang="en"] body,
.text-en {
  font-family: var(--font-en);
}

/* Product names: always use Bengali font for Bengali text */
.product-name-bn {
  font-family: var(--font-bn);
  font-size: 1.1rem;  /* Bengali glyphs need slightly larger */
}
```

---

## Summary — Key Decisions

| Question | Answer |
|----------|--------|
| Where to get kacha-bazar data? | **Manual curation** (fresh produce has no API) + Open Food Facts (packaged) + Vendor upload |
| Store Bengali in DB? | **YES** — `name_bn` column is NOT NULL, required |
| Store English in DB? | **YES** — `name_en` column is NOT NULL, required |
| Translate at runtime via AI? | **NO** — too slow, too error-prone for proper nouns |
| When to use AI translation? | **One-time batch seed** only, with human review |
| Which AI translation tool? | **LibreTranslate** (self-hosted, free, supports Bengali) |
| How does GUI work? | **next-i18next** — user picks language, API returns correct column |
| Side-by-side in GUI? | **Only for vendor/admin** panel (input both); customer sees ONE language |
| Search language? | **Typesense indexes both** — customer can search in either language |
| Default language? | **Bengali (bn)** — 95% of target users prefer Bengali |
| Bengali font? | **Noto Sans Bengali** (Google, free, complete glyph coverage) |

---

## References

- [Open Food Facts API](https://wiki.openfoodfacts.org/API) — Free product database (3M+ items)
- [LibreTranslate](https://github.com/LibreTranslate/LibreTranslate) — Self-hosted MT (AGPL, supports bn↔en)
- [next-i18next v16](https://github.com/i18next/next-i18next) — Next.js i18n framework
- [Typesense](https://typesense.org/docs/) — Fast search with Unicode/Bengali support
- [Noto Sans Bengali](https://fonts.google.com/noto/specimen/Noto+Sans+Bengali) — Complete Bengali font
- [GS1 Bangladesh](https://gs1bd.org/) — Official barcode registry
- [PostgreSQL ICU Collation](https://www.postgresql.org/docs/16/collation.html) — Bengali sort order
